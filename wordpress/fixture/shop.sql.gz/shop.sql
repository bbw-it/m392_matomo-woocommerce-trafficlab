/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.5-MariaDB, for Linux (aarch64)
--
-- Host: db    Database: wordpress
-- ------------------------------------------------------
-- Server version	11.4.12-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `wp_actionscheduler_actions`
--

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) NOT NULL,
  `status` varchar(20) NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `priority` tinyint(3) unsigned NOT NULL DEFAULT 10,
  `args` varchar(191) DEFAULT NULL,
  `schedule` longtext DEFAULT NULL,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `extended_args` varchar(8000) DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook_status_scheduled_date_gmt` (`hook`(163),`status`,`scheduled_date_gmt`),
  KEY `status_scheduled_date_gmt` (`status`,`scheduled_date_gmt`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`),
  KEY `claim_id_status_priority_scheduled_date_gmt` (`claim_id`,`status`,`priority`,`scheduled_date_gmt`),
  KEY `status_last_attempt_gmt` (`status`,`last_attempt_gmt`),
  KEY `status_claim_id` (`status`,`claim_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_actionscheduler_actions`
--

LOCK TABLES `wp_actionscheduler_actions` WRITE;
/*!40000 ALTER TABLE `wp_actionscheduler_actions` DISABLE KEYS */;
INSERT INTO `wp_actionscheduler_actions` VALUES
(5,'action_scheduler/migration_hook','pending','2026-06-01 13:49:47','2026-06-01 13:49:47',10,'[]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780321787;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780321787;}',1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(6,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 13:49:00','2026-06-01 13:49:00',10,'[10,1]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780321740;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780321740;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(7,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 13:49:01','2026-06-01 13:49:01',10,'[11,1]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780321741;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780321741;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(8,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 13:49:03','2026-06-01 13:49:03',10,'[12,1]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780321743;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780321743;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(9,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 13:49:05','2026-06-01 13:49:05',10,'[13,1]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780321745;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780321745;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(10,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 13:49:07','2026-06-01 13:49:07',10,'[14,1]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780321747;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780321747;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(11,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 13:49:09','2026-06-01 13:49:09',10,'[15,1]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780321749;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780321749;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(12,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 13:49:11','2026-06-01 13:49:11',10,'[16,1]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780321751;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780321751;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(13,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 13:49:13','2026-06-01 13:49:13',10,'[17,1]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780321753;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780321753;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(14,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 13:49:14','2026-06-01 13:49:14',10,'[18,1]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780321754;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780321754;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(15,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 13:49:16','2026-06-01 13:49:16',10,'[19,1]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780321756;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780321756;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(16,'woocommerce_cleanup_draft_orders','pending','2026-06-01 13:49:38','2026-06-01 13:49:38',10,'[]','O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1780321778;s:18:\"\0*\0first_timestamp\";i:1780321778;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1780321778;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(17,'wc-admin_import_orders','pending','2026-06-01 13:51:43','2026-06-01 13:51:43',10,'[30]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780321903;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780321903;}',4,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(18,'wc-admin_import_orders','pending','2026-06-01 13:54:11','2026-06-01 13:54:11',10,'[31]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780322051;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780322051;}',4,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(19,'wc-admin_import_orders','pending','2026-06-01 13:54:11','2026-06-01 13:54:11',10,'[32]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780322051;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780322051;}',4,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(20,'merchant_weekly_schedule','pending','2026-06-01 14:05:16','2026-06-01 14:05:16',10,'[]','O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1780322716;s:18:\"\0*\0first_timestamp\";i:1780322716;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1780322716;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}',3,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(21,'botiga_send_usage_data','pending','2026-06-01 14:05:49','2026-06-01 14:05:49',10,'[]','O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1780322749;s:18:\"\0*\0first_timestamp\";i:1780322749;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1780322749;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}',5,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(22,'action_scheduler_run_recurring_actions_schedule_hook','pending','2026-06-01 14:06:23','2026-06-01 14:06:23',20,'[]','O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1780322783;s:18:\"\0*\0first_timestamp\";i:1780322783;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1780322783;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',6,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(23,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 15:41:47','2026-06-01 15:41:47',10,'[19,3]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780328507;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780328507;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(24,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 15:41:50','2026-06-01 15:41:50',10,'[18,3]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780328510;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780328510;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(25,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 15:42:51','2026-06-01 15:42:51',10,'[17,3]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780328571;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780328571;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(26,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 15:42:57','2026-06-01 15:42:57',10,'[16,3]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780328577;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780328577;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(27,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 15:42:59','2026-06-01 15:42:59',10,'[15,3]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780328579;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780328579;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(28,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 15:43:04','2026-06-01 15:43:04',10,'[13,3]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780328584;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780328584;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(29,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 15:43:06','2026-06-01 15:43:06',10,'[14,3]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780328586;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780328586;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(30,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 15:43:09','2026-06-01 15:43:09',10,'[12,3]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780328589;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780328589;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(31,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 15:43:11','2026-06-01 15:43:11',10,'[11,3]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780328591;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780328591;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(32,'woocommerce_run_product_attribute_lookup_update_callback','pending','2026-06-01 15:43:13','2026-06-01 15:43:13',10,'[10,3]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780328593;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780328593;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(33,'wc-admin_import_orders','pending','2026-06-02 06:04:19','2026-06-02 06:04:19',10,'[441]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780380259;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780380259;}',4,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(34,'woocommerce_run_product_attribute_lookup_regeneration_callback','pending','2026-06-02 06:35:26','2026-06-02 06:35:26',10,'[]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780382126;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780382126;}',2,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL),
(35,'wc-admin_import_orders','pending','2026-06-02 09:24:20','2026-06-02 09:24:20',10,'[450]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1780392260;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1780392260;}',4,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,NULL);
/*!40000 ALTER TABLE `wp_actionscheduler_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_actionscheduler_claims`
--

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_actionscheduler_claims`
--

LOCK TABLES `wp_actionscheduler_claims` WRITE;
/*!40000 ALTER TABLE `wp_actionscheduler_claims` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_actionscheduler_claims` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_actionscheduler_groups`
--

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_actionscheduler_groups`
--

LOCK TABLES `wp_actionscheduler_groups` WRITE;
/*!40000 ALTER TABLE `wp_actionscheduler_groups` DISABLE KEYS */;
INSERT INTO `wp_actionscheduler_groups` VALUES
(1,'action-scheduler-migration'),
(2,'woocommerce-db-updates'),
(3,''),
(4,'wc-admin-data'),
(5,'botiga'),
(6,'ActionScheduler');
/*!40000 ALTER TABLE `wp_actionscheduler_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_actionscheduler_logs`
--

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_actionscheduler_logs`
--

LOCK TABLES `wp_actionscheduler_logs` WRITE;
/*!40000 ALTER TABLE `wp_actionscheduler_logs` DISABLE KEYS */;
INSERT INTO `wp_actionscheduler_logs` VALUES
(1,5,'action created','2026-06-01 13:48:47','2026-06-01 13:48:47'),
(2,6,'action created','2026-06-01 13:48:59','2026-06-01 13:48:59'),
(3,7,'action created','2026-06-01 13:49:00','2026-06-01 13:49:00'),
(4,8,'action created','2026-06-01 13:49:02','2026-06-01 13:49:02'),
(5,9,'action created','2026-06-01 13:49:04','2026-06-01 13:49:04'),
(6,10,'action created','2026-06-01 13:49:06','2026-06-01 13:49:06'),
(7,11,'action created','2026-06-01 13:49:08','2026-06-01 13:49:08'),
(8,12,'action created','2026-06-01 13:49:10','2026-06-01 13:49:10'),
(9,13,'action created','2026-06-01 13:49:12','2026-06-01 13:49:12'),
(10,14,'action created','2026-06-01 13:49:13','2026-06-01 13:49:13'),
(11,15,'action created','2026-06-01 13:49:15','2026-06-01 13:49:15'),
(12,16,'action created','2026-06-01 13:49:38','2026-06-01 13:49:38'),
(13,17,'action created','2026-06-01 13:51:38','2026-06-01 13:51:38'),
(14,18,'action created','2026-06-01 13:54:06','2026-06-01 13:54:06'),
(15,19,'action created','2026-06-01 13:54:06','2026-06-01 13:54:06'),
(16,20,'Aktion erstellt','2026-06-01 14:05:16','2026-06-01 14:05:16'),
(17,21,'action created','2026-06-01 14:05:49','2026-06-01 14:05:49'),
(18,22,'action created','2026-06-01 14:06:23','2026-06-01 14:06:23'),
(19,23,'action created','2026-06-01 15:41:46','2026-06-01 15:41:46'),
(20,24,'action created','2026-06-01 15:41:49','2026-06-01 15:41:49'),
(21,25,'action created','2026-06-01 15:42:50','2026-06-01 15:42:50'),
(22,26,'action created','2026-06-01 15:42:56','2026-06-01 15:42:56'),
(23,27,'action created','2026-06-01 15:42:58','2026-06-01 15:42:58'),
(24,28,'action created','2026-06-01 15:43:03','2026-06-01 15:43:03'),
(25,29,'action created','2026-06-01 15:43:05','2026-06-01 15:43:05'),
(26,30,'action created','2026-06-01 15:43:08','2026-06-01 15:43:08'),
(27,31,'action created','2026-06-01 15:43:10','2026-06-01 15:43:10'),
(28,32,'action created','2026-06-01 15:43:12','2026-06-01 15:43:12'),
(29,33,'action created','2026-06-02 06:04:14','2026-06-02 06:04:14'),
(30,34,'action created','2026-06-02 06:35:25','2026-06-02 06:35:25'),
(31,35,'action created','2026-06-02 09:24:15','2026-06-02 09:24:15');
/*!40000 ALTER TABLE `wp_actionscheduler_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1479 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_commentmeta`
--

LOCK TABLES `wp_commentmeta` WRITE;
/*!40000 ALTER TABLE `wp_commentmeta` DISABLE KEYS */;
INSERT INTO `wp_commentmeta` VALUES
(1077,546,'rating','5'),
(1078,546,'verified','1'),
(1079,547,'rating','5'),
(1080,547,'verified','1'),
(1081,548,'rating','4'),
(1082,548,'verified','1'),
(1083,549,'rating','2'),
(1084,549,'verified','1'),
(1085,550,'rating','4'),
(1086,550,'verified','1'),
(1087,551,'rating','5'),
(1088,551,'verified','1'),
(1089,552,'rating','3'),
(1090,552,'verified','1'),
(1091,553,'rating','5'),
(1092,553,'verified','1'),
(1093,554,'rating','5'),
(1094,554,'verified','1'),
(1095,555,'rating','5'),
(1096,555,'verified','1'),
(1097,556,'rating','4'),
(1098,556,'verified','1'),
(1099,557,'rating','3'),
(1100,557,'verified','1'),
(1101,558,'rating','4'),
(1102,558,'verified','1'),
(1103,559,'rating','5'),
(1104,559,'verified','1'),
(1105,560,'rating','5'),
(1106,560,'verified','1'),
(1107,561,'rating','5'),
(1108,561,'verified','1'),
(1109,562,'rating','5'),
(1110,562,'verified','1'),
(1111,563,'rating','5'),
(1112,563,'verified','1'),
(1113,564,'rating','4'),
(1114,564,'verified','1'),
(1115,565,'rating','5'),
(1116,565,'verified','1'),
(1117,566,'rating','2'),
(1118,566,'verified','1'),
(1119,567,'rating','4'),
(1120,567,'verified','1'),
(1121,568,'rating','5'),
(1122,568,'verified','1'),
(1123,569,'rating','5'),
(1124,569,'verified','1'),
(1125,570,'rating','5'),
(1126,570,'verified','1'),
(1127,571,'rating','5'),
(1128,571,'verified','1'),
(1129,572,'rating','5'),
(1130,572,'verified','1'),
(1131,573,'rating','5'),
(1132,573,'verified','1'),
(1133,574,'rating','5'),
(1134,574,'verified','1'),
(1135,575,'rating','5'),
(1136,575,'verified','1'),
(1137,576,'rating','4'),
(1138,576,'verified','1'),
(1139,577,'rating','5'),
(1140,577,'verified','1'),
(1141,578,'rating','5'),
(1142,578,'verified','1'),
(1143,579,'rating','5'),
(1144,579,'verified','1'),
(1145,580,'rating','5'),
(1146,580,'verified','1'),
(1147,581,'rating','5'),
(1148,581,'verified','1'),
(1149,582,'rating','5'),
(1150,582,'verified','1'),
(1151,583,'rating','5'),
(1152,583,'verified','1'),
(1153,584,'rating','5'),
(1154,584,'verified','1'),
(1155,585,'rating','5'),
(1156,585,'verified','1'),
(1157,586,'rating','5'),
(1158,586,'verified','1'),
(1159,587,'rating','4'),
(1160,587,'verified','1'),
(1161,588,'rating','5'),
(1162,588,'verified','1'),
(1163,589,'rating','4'),
(1164,589,'verified','1'),
(1165,590,'rating','5'),
(1166,590,'verified','1'),
(1167,591,'rating','5'),
(1168,591,'verified','1'),
(1169,592,'rating','3'),
(1170,592,'verified','1'),
(1171,593,'rating','5'),
(1172,593,'verified','1'),
(1173,594,'rating','5'),
(1174,594,'verified','1'),
(1175,595,'rating','5'),
(1176,595,'verified','1'),
(1177,596,'rating','5'),
(1178,596,'verified','1'),
(1179,597,'rating','5'),
(1180,597,'verified','1'),
(1181,598,'rating','5'),
(1182,598,'verified','1'),
(1183,599,'rating','5'),
(1184,599,'verified','1'),
(1185,600,'rating','5'),
(1186,600,'verified','1'),
(1187,601,'rating','5'),
(1188,601,'verified','1'),
(1189,602,'rating','5'),
(1190,602,'verified','1'),
(1191,603,'rating','5'),
(1192,603,'verified','1'),
(1193,604,'rating','5'),
(1194,604,'verified','1'),
(1195,605,'rating','5'),
(1196,605,'verified','1'),
(1197,606,'rating','5'),
(1198,606,'verified','1'),
(1199,607,'rating','5'),
(1200,607,'verified','1'),
(1201,608,'rating','5'),
(1202,608,'verified','1'),
(1203,609,'rating','5'),
(1204,609,'verified','1'),
(1205,610,'rating','4'),
(1206,610,'verified','1'),
(1207,611,'rating','5'),
(1208,611,'verified','1'),
(1209,612,'rating','5'),
(1210,612,'verified','1'),
(1211,613,'rating','2'),
(1212,613,'verified','1'),
(1213,614,'rating','5'),
(1214,614,'verified','1'),
(1215,615,'rating','5'),
(1216,615,'verified','1'),
(1217,616,'rating','4'),
(1218,616,'verified','1'),
(1219,617,'rating','4'),
(1220,617,'verified','1'),
(1221,618,'rating','5'),
(1222,618,'verified','1'),
(1223,619,'rating','5'),
(1224,619,'verified','1'),
(1225,620,'rating','4'),
(1226,620,'verified','1'),
(1227,621,'rating','4'),
(1228,621,'verified','1'),
(1229,622,'rating','5'),
(1230,622,'verified','1'),
(1231,623,'rating','5'),
(1232,623,'verified','1'),
(1233,624,'rating','4'),
(1234,624,'verified','1'),
(1235,625,'rating','5'),
(1236,625,'verified','1'),
(1237,626,'rating','5'),
(1238,626,'verified','1'),
(1239,627,'rating','5'),
(1240,627,'verified','1'),
(1241,628,'rating','3'),
(1242,628,'verified','1'),
(1243,629,'rating','5'),
(1244,629,'verified','1'),
(1245,630,'rating','4'),
(1246,630,'verified','1'),
(1247,631,'rating','5'),
(1248,631,'verified','1'),
(1249,632,'rating','5'),
(1250,632,'verified','1'),
(1251,633,'rating','5'),
(1252,633,'verified','1'),
(1253,634,'rating','3'),
(1254,634,'verified','1'),
(1255,635,'rating','4'),
(1256,635,'verified','1'),
(1257,636,'rating','4'),
(1258,636,'verified','1'),
(1259,637,'rating','5'),
(1260,637,'verified','1'),
(1261,638,'rating','4'),
(1262,638,'verified','1'),
(1263,639,'rating','5'),
(1264,639,'verified','1'),
(1265,640,'rating','4'),
(1266,640,'verified','1'),
(1267,641,'rating','4'),
(1268,641,'verified','1'),
(1269,642,'rating','4'),
(1270,642,'verified','1'),
(1271,643,'rating','5'),
(1272,643,'verified','1'),
(1273,644,'rating','5'),
(1274,644,'verified','1'),
(1275,645,'rating','5'),
(1276,645,'verified','1'),
(1277,646,'rating','5'),
(1278,646,'verified','1'),
(1279,647,'rating','5'),
(1280,647,'verified','1'),
(1281,648,'rating','5'),
(1282,648,'verified','1'),
(1283,649,'rating','5'),
(1284,649,'verified','1'),
(1285,650,'rating','3'),
(1286,650,'verified','1'),
(1287,651,'rating','5'),
(1288,651,'verified','1'),
(1289,652,'rating','5'),
(1290,652,'verified','1'),
(1291,653,'rating','5'),
(1292,653,'verified','1'),
(1293,654,'rating','1'),
(1294,654,'verified','1'),
(1295,655,'rating','5'),
(1296,655,'verified','1'),
(1297,656,'rating','5'),
(1298,656,'verified','1'),
(1299,657,'rating','5'),
(1300,657,'verified','1'),
(1301,658,'rating','5'),
(1302,658,'verified','1'),
(1303,659,'rating','5'),
(1304,659,'verified','1'),
(1305,660,'rating','5'),
(1306,660,'verified','1'),
(1307,661,'rating','5'),
(1308,661,'verified','1'),
(1309,662,'rating','5'),
(1310,662,'verified','1'),
(1311,663,'rating','4'),
(1312,663,'verified','1'),
(1313,664,'rating','5'),
(1314,664,'verified','1'),
(1315,665,'rating','4'),
(1316,665,'verified','1'),
(1317,666,'rating','5'),
(1318,666,'verified','1'),
(1319,667,'rating','5'),
(1320,667,'verified','1'),
(1321,668,'rating','5'),
(1322,668,'verified','1'),
(1323,669,'rating','5'),
(1324,669,'verified','1'),
(1325,670,'rating','5'),
(1326,670,'verified','1'),
(1327,671,'rating','5'),
(1328,671,'verified','1'),
(1329,672,'rating','5'),
(1330,672,'verified','1'),
(1331,673,'rating','5'),
(1332,673,'verified','1'),
(1333,674,'rating','5'),
(1334,674,'verified','1'),
(1335,675,'rating','4'),
(1336,675,'verified','1'),
(1337,676,'rating','4'),
(1338,676,'verified','1'),
(1339,677,'rating','5'),
(1340,677,'verified','1'),
(1341,678,'rating','5'),
(1342,678,'verified','1'),
(1343,679,'rating','5'),
(1344,679,'verified','1'),
(1345,680,'rating','5'),
(1346,680,'verified','1'),
(1347,681,'rating','5'),
(1348,681,'verified','1'),
(1349,682,'rating','4'),
(1350,682,'verified','1'),
(1351,683,'rating','5'),
(1352,683,'verified','1'),
(1353,684,'rating','5'),
(1354,684,'verified','1'),
(1355,685,'rating','5'),
(1356,685,'verified','1'),
(1357,686,'rating','5'),
(1358,686,'verified','1'),
(1359,687,'rating','3'),
(1360,687,'verified','1'),
(1361,688,'rating','4'),
(1362,688,'verified','1'),
(1363,689,'rating','5'),
(1364,689,'verified','1'),
(1365,690,'rating','5'),
(1366,690,'verified','1'),
(1367,691,'rating','5'),
(1368,691,'verified','1'),
(1369,692,'rating','5'),
(1370,692,'verified','1'),
(1371,693,'rating','4'),
(1372,693,'verified','1'),
(1373,694,'rating','5'),
(1374,694,'verified','1'),
(1375,695,'rating','4'),
(1376,695,'verified','1'),
(1377,696,'rating','5'),
(1378,696,'verified','1'),
(1379,697,'rating','5'),
(1380,697,'verified','1'),
(1381,698,'rating','5'),
(1382,698,'verified','1'),
(1383,699,'rating','5'),
(1384,699,'verified','1'),
(1385,700,'rating','4'),
(1386,700,'verified','1'),
(1387,701,'rating','4'),
(1388,701,'verified','1'),
(1389,702,'rating','5'),
(1390,702,'verified','1'),
(1391,703,'rating','5'),
(1392,703,'verified','1'),
(1393,704,'rating','5'),
(1394,704,'verified','1'),
(1395,705,'rating','5'),
(1396,705,'verified','1'),
(1397,706,'rating','5'),
(1398,706,'verified','1'),
(1399,707,'rating','4'),
(1400,707,'verified','1'),
(1401,708,'rating','5'),
(1402,708,'verified','1'),
(1403,709,'rating','4'),
(1404,709,'verified','1'),
(1405,710,'rating','5'),
(1406,710,'verified','1'),
(1407,711,'rating','5'),
(1408,711,'verified','1'),
(1409,712,'rating','5'),
(1410,712,'verified','1'),
(1411,713,'rating','4'),
(1412,713,'verified','1'),
(1413,714,'rating','5'),
(1414,714,'verified','1'),
(1415,715,'rating','5'),
(1416,715,'verified','1'),
(1417,716,'rating','5'),
(1418,716,'verified','1'),
(1419,717,'rating','5'),
(1420,717,'verified','1'),
(1421,718,'rating','1'),
(1422,718,'verified','1'),
(1423,719,'rating','5'),
(1424,719,'verified','1'),
(1425,720,'rating','2'),
(1426,720,'verified','1'),
(1427,721,'rating','5'),
(1428,721,'verified','1'),
(1429,722,'rating','5'),
(1430,722,'verified','1'),
(1431,723,'rating','5'),
(1432,723,'verified','1'),
(1433,724,'rating','5'),
(1434,724,'verified','1'),
(1435,725,'rating','5'),
(1436,725,'verified','1'),
(1437,726,'rating','5'),
(1438,726,'verified','1'),
(1439,727,'rating','5'),
(1440,727,'verified','1'),
(1441,728,'rating','5'),
(1442,728,'verified','1'),
(1443,729,'rating','5'),
(1444,729,'verified','1'),
(1445,730,'rating','3'),
(1446,730,'verified','1'),
(1447,731,'rating','5'),
(1448,731,'verified','1'),
(1449,732,'rating','2'),
(1450,732,'verified','1'),
(1451,733,'rating','4'),
(1452,733,'verified','1'),
(1453,734,'rating','2'),
(1454,734,'verified','1'),
(1455,735,'rating','5'),
(1456,735,'verified','1'),
(1457,736,'rating','5'),
(1458,736,'verified','1'),
(1459,737,'rating','5'),
(1460,737,'verified','1'),
(1461,738,'rating','5'),
(1462,738,'verified','1'),
(1463,739,'rating','5'),
(1464,739,'verified','1'),
(1465,740,'rating','4'),
(1466,740,'verified','1'),
(1467,741,'rating','5'),
(1468,741,'verified','1'),
(1469,742,'rating','5'),
(1470,742,'verified','1'),
(1471,743,'rating','5'),
(1472,743,'verified','1'),
(1473,744,'rating','5'),
(1474,744,'verified','1'),
(1475,745,'rating','4'),
(1476,745,'verified','1'),
(1477,746,'rating','5'),
(1478,746,'verified','1');
/*!40000 ALTER TABLE `wp_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=749 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_comments`
--

LOCK TABLES `wp_comments` WRITE;
/*!40000 ALTER TABLE `wp_comments` DISABLE KEYS */;
INSERT INTO `wp_comments` VALUES
(2,30,'WooCommerce','woocommerce@noreply.com','','','2026-06-01 13:51:38','2026-06-01 13:51:38','Order status changed from Pending payment to Processing.',0,'1','WooCommerce','order_note',0,0),
(3,30,'WooCommerce','woocommerce@noreply.com','','','2026-06-01 13:51:38','2026-06-01 13:51:38','Test-Kreditkarte akzeptiert (4242).',0,'1','WooCommerce','order_note',0,0),
(4,31,'WooCommerce','woocommerce@noreply.com','','','2026-06-01 13:54:06','2026-06-01 13:54:06','Order status changed from Pending payment to Completed.',0,'1','WooCommerce','order_note',0,0),
(5,31,'WooCommerce','woocommerce@noreply.com','','','2026-06-01 13:54:06','2026-06-01 13:54:06','Test-Kreditkarte akzeptiert (4242).',0,'1','WooCommerce','order_note',0,0),
(6,441,'WooCommerce','','','','2026-06-02 06:04:15','2026-06-02 06:04:15','Status der Bestellung von Zahlung ausstehend auf In Bearbeitung geändert.',0,'1','WooCommerce','order_note',0,0),
(7,441,'WooCommerce','','','','2026-06-02 06:04:15','2026-06-02 06:04:15','TWINT (Test) bestätigt.',0,'1','WooCommerce','order_note',0,0),
(546,97,'Laura V.','laurav@example.com','','','2026-04-05 11:38:34','2026-04-05 11:38:34','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(547,97,'Tobias K.','tobiask@example.com','','','2026-04-20 15:57:56','2026-04-20 15:57:56','Meine empfindliche Haut verträgt es bestens, keine Reizungen. Begeistert!',0,'1','','review',0,0),
(548,97,'Vanessa E.','vanessae@example.com','','','2025-08-28 14:50:10','2025-08-28 14:50:10','Bin zufrieden, die Wirkung ist spürbar. Der Duft könnte etwas dezenter sein.',0,'1','','review',0,0),
(549,97,'Thomas W.','thomasw@example.com','','','2025-11-14 13:33:44','2025-11-14 13:33:44','Bei mir hat es die Haut eher gereizt. Schade, hatte mir mehr erhofft.',0,'1','','review',0,0),
(550,97,'Julia H.','juliah@example.com','','','2025-09-06 17:15:59','2025-09-06 17:15:59','Gutes Produkt, das ich gerne nutze. Der Preis ist etwas hoch, aber die Qualität stimmt.',0,'1','','review',0,0),
(551,97,'Jonas H.','jonash@example.com','','','2025-12-27 08:10:01','2025-12-27 08:10:01','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(552,97,'Marco G.','marcog@example.com','','','2026-04-13 01:43:33','2026-04-13 01:43:33','Ganz okay, aber bei mir hat es nicht den grossen Unterschied gemacht.',0,'1','','review',0,0),
(553,97,'Tobias K.','tobiask@example.com','','','2026-04-20 13:14:47','2026-04-20 13:14:47','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(554,97,'Nicole P.','nicolep@example.com','','','2025-09-14 04:31:29','2025-09-14 04:31:29','Preis-Leistung stimmt absolut. Ich habe es schon mehrfach nachbestellt.',0,'1','','review',0,0),
(555,97,'Sophie K.','sophiek@example.com','','','2026-04-08 14:23:07','2026-04-08 14:23:07','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(556,97,'Stefan T.','stefant@example.com','','','2025-11-23 02:51:47','2025-11-23 02:51:47','Solides Produkt, würde ich weiterempfehlen. Hätte gern eine grössere Packung.',0,'1','','review',0,0),
(557,97,'Stefan T.','stefant@example.com','','','2025-07-06 05:10:43','2025-07-06 05:10:43','Mittelmässig. Für den Preis hätte ich mir etwas mehr erwartet.',0,'1','','review',0,0),
(558,97,'Carla B.','carlab@example.com','','','2026-02-28 14:37:20','2026-02-28 14:37:20','Solides Produkt, würde ich weiterempfehlen. Hätte gern eine grössere Packung.',0,'1','','review',0,0),
(559,97,'Nadia F.','nadiaf@example.com','','','2026-04-03 06:07:07','2026-04-03 06:07:07','Preis-Leistung stimmt absolut. Ich habe es schon mehrfach nachbestellt.',0,'1','','review',0,0),
(560,97,'Pascal Y.','pascaly@example.com','','','2026-03-06 14:34:20','2026-03-06 14:34:20','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(561,96,'David F.','davidf@example.com','','','2026-02-08 03:44:28','2026-02-08 03:44:28','Meine empfindliche Haut verträgt es bestens, keine Reizungen. Begeistert!',0,'1','','review',0,0),
(562,96,'Fabienne U.','fabienneu@example.com','','','2025-10-23 10:17:23','2025-10-23 10:17:23','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(563,96,'Simone R.','simoner@example.com','','','2025-10-13 17:41:46','2025-10-13 17:41:46','Meine empfindliche Haut verträgt es bestens, keine Reizungen. Begeistert!',0,'1','','review',0,0),
(564,96,'Lena S.','lenas@example.com','','','2025-11-20 09:00:39','2025-11-20 09:00:39','Gutes Produkt, das ich gerne nutze. Der Preis ist etwas hoch, aber die Qualität stimmt.',0,'1','','review',0,0),
(565,96,'Daniel C.','danielc@example.com','','','2025-12-30 22:31:05','2025-12-30 22:31:05','Preis-Leistung stimmt absolut. Ich habe es schon mehrfach nachbestellt.',0,'1','','review',0,0),
(566,96,'Laura V.','laurav@example.com','','','2025-12-15 21:10:41','2025-12-15 21:10:41','Bei mir hat es die Haut eher gereizt. Schade, hatte mir mehr erhofft.',0,'1','','review',0,0),
(567,96,'Tobias K.','tobiask@example.com','','','2025-09-16 05:10:26','2025-09-16 05:10:26','Bin zufrieden, die Wirkung ist spürbar. Der Duft könnte etwas dezenter sein.',0,'1','','review',0,0),
(568,96,'David F.','davidf@example.com','','','2026-03-24 16:14:26','2026-03-24 16:14:26','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(569,96,'Patrick Z.','patrickz@example.com','','','2026-05-08 23:38:09','2026-05-08 23:38:09','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(570,96,'Julia H.','juliah@example.com','','','2025-12-15 09:59:01','2025-12-15 09:59:01','Meine empfindliche Haut verträgt es bestens, keine Reizungen. Begeistert!',0,'1','','review',0,0),
(571,96,'Sandro I.','sandroi@example.com','','','2026-05-09 19:13:24','2026-05-09 19:13:24','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(572,96,'Sophie K.','sophiek@example.com','','','2025-10-31 06:29:47','2025-10-31 06:29:47','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(573,96,'Michael R.','michaelr@example.com','','','2025-09-02 01:02:57','2025-09-02 01:02:57','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(574,96,'Nadia F.','nadiaf@example.com','','','2025-06-16 12:20:11','2025-06-16 12:20:11','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(575,96,'Carla B.','carlab@example.com','','','2025-08-04 08:33:40','2025-08-04 08:33:40','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(576,96,'Sophie K.','sophiek@example.com','','','2025-08-06 08:15:35','2025-08-06 08:15:35','Funktioniert gut. Die Lieferung hat etwas länger gedauert als erwartet.',0,'1','','review',0,0),
(577,96,'Andrea N.','andrean@example.com','','','2025-08-10 21:22:29','2025-08-10 21:22:29','Meine empfindliche Haut verträgt es bestens, keine Reizungen. Begeistert!',0,'1','','review',0,0),
(578,96,'Melanie O.','melanieo@example.com','','','2026-05-01 14:31:53','2026-05-01 14:31:53','Meine empfindliche Haut verträgt es bestens, keine Reizungen. Begeistert!',0,'1','','review',0,0),
(579,96,'Daniel C.','danielc@example.com','','','2026-04-13 22:39:05','2026-04-13 22:39:05','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(580,95,'Nadia F.','nadiaf@example.com','','','2025-07-20 23:12:51','2025-07-20 23:12:51','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(581,95,'Sarah L.','sarahl@example.com','','','2025-07-28 04:03:51','2025-07-28 04:03:51','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(582,95,'Simone R.','simoner@example.com','','','2025-09-16 14:57:50','2025-09-16 14:57:50','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(583,95,'Pascal Y.','pascaly@example.com','','','2025-09-18 16:01:44','2025-09-18 16:01:44','Meine empfindliche Haut verträgt es bestens, keine Reizungen. Begeistert!',0,'1','','review',0,0),
(584,95,'Andrea N.','andrean@example.com','','','2025-09-29 01:55:07','2025-09-29 01:55:07','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(585,95,'Jonas H.','jonash@example.com','','','2026-04-28 10:01:34','2026-04-28 10:01:34','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(586,95,'Patrick Z.','patrickz@example.com','','','2026-01-31 01:54:47','2026-01-31 01:54:47','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(587,95,'Pascal Y.','pascaly@example.com','','','2026-04-05 19:35:53','2026-04-05 19:35:53','Gutes Produkt, das ich gerne nutze. Der Preis ist etwas hoch, aber die Qualität stimmt.',0,'1','','review',0,0),
(588,95,'Vanessa E.','vanessae@example.com','','','2025-07-15 22:34:03','2025-07-15 22:34:03','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(589,95,'Christian D.','christiand@example.com','','','2026-03-03 14:28:33','2026-03-03 14:28:33','Macht einen guten Job. Nach ein paar Wochen sehe ich erste Resultate.',0,'1','','review',0,0),
(590,95,'Carla B.','carlab@example.com','','','2026-05-20 15:38:21','2026-05-20 15:38:21','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(591,95,'Corinne J.','corinnej@example.com','','','2026-01-31 14:40:28','2026-01-31 14:40:28','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(592,95,'Michael R.','michaelr@example.com','','','2025-07-31 12:32:05','2025-07-31 12:32:05','Mittelmässig. Für den Preis hätte ich mir etwas mehr erwartet.',0,'1','','review',0,0),
(593,95,'Carla B.','carlab@example.com','','','2025-10-08 19:13:12','2025-10-08 19:13:12','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(594,95,'Fabienne U.','fabienneu@example.com','','','2026-01-13 13:16:23','2026-01-13 13:16:23','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(595,95,'Lukas B.','lukasb@example.com','','','2025-06-25 16:05:14','2025-06-25 16:05:14','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(596,95,'Nadia F.','nadiaf@example.com','','','2025-11-30 00:48:50','2025-11-30 00:48:50','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(597,95,'Lena S.','lenas@example.com','','','2026-02-13 04:05:14','2026-02-13 04:05:14','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(598,95,'Jonas H.','jonash@example.com','','','2025-10-24 00:40:56','2025-10-24 00:40:56','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(599,95,'Laura V.','laurav@example.com','','','2026-01-03 19:46:49','2026-01-03 19:46:49','Preis-Leistung stimmt absolut. Ich habe es schon mehrfach nachbestellt.',0,'1','','review',0,0),
(600,94,'Melanie O.','melanieo@example.com','','','2025-11-11 06:23:21','2025-11-11 06:23:21','Preis-Leistung stimmt absolut. Ich habe es schon mehrfach nachbestellt.',0,'1','','review',0,0),
(601,94,'Jonas H.','jonash@example.com','','','2026-03-01 00:08:47','2026-03-01 00:08:47','Preis-Leistung stimmt absolut. Ich habe es schon mehrfach nachbestellt.',0,'1','','review',0,0),
(602,94,'David F.','davidf@example.com','','','2025-10-21 00:25:00','2025-10-21 00:25:00','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(603,94,'Jonas H.','jonash@example.com','','','2025-08-30 06:09:31','2025-08-30 06:09:31','Genau das, was ich gesucht habe. Spürbarer Unterschied nach wenigen Tagen.',0,'1','','review',0,0),
(604,94,'Lukas B.','lukasb@example.com','','','2025-08-26 00:44:21','2025-08-26 00:44:21','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(605,94,'Melanie O.','melanieo@example.com','','','2025-08-30 14:47:01','2025-08-30 14:47:01','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(606,94,'Simone R.','simoner@example.com','','','2025-08-29 05:20:31','2025-08-29 05:20:31','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(607,94,'Sarah L.','sarahl@example.com','','','2026-02-07 03:20:37','2026-02-07 03:20:37','Genau das, was ich gesucht habe. Spürbarer Unterschied nach wenigen Tagen.',0,'1','','review',0,0),
(608,94,'Andrea N.','andrean@example.com','','','2025-09-02 11:30:34','2025-09-02 11:30:34','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(609,94,'Carla B.','carlab@example.com','','','2025-09-28 22:03:53','2025-09-28 22:03:53','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(610,94,'Sophie K.','sophiek@example.com','','','2026-01-29 03:13:00','2026-01-29 03:13:00','Solides Produkt, würde ich weiterempfehlen. Hätte gern eine grössere Packung.',0,'1','','review',0,0),
(611,94,'Pascal Y.','pascaly@example.com','','','2025-08-22 11:14:11','2025-08-22 11:14:11','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(612,94,'Anna M.','annam@example.com','','','2026-01-11 05:08:01','2026-01-11 05:08:01','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(613,94,'Sophie K.','sophiek@example.com','','','2025-09-15 09:31:40','2025-09-15 09:31:40','Leider hat mich das Produkt nicht überzeugt. Der Duft ist mir zu intensiv.',0,'1','','review',0,0),
(614,94,'Carla B.','carlab@example.com','','','2026-03-24 15:27:03','2026-03-24 15:27:03','Genau das, was ich gesucht habe. Spürbarer Unterschied nach wenigen Tagen.',0,'1','','review',0,0),
(615,94,'Melanie O.','melanieo@example.com','','','2026-01-08 04:40:03','2026-01-08 04:40:03','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(616,94,'Reto A.','retoa@example.com','','','2025-07-03 08:57:11','2025-07-03 08:57:11','Schöne Pflege, zieht gut ein. Einen Stern Abzug, weil die Dosierung etwas knifflig ist.',0,'1','','review',0,0),
(617,94,'Tobias K.','tobiask@example.com','','','2026-04-19 04:55:58','2026-04-19 04:55:58','Funktioniert gut. Die Lieferung hat etwas länger gedauert als erwartet.',0,'1','','review',0,0),
(618,94,'Pascal Y.','pascaly@example.com','','','2025-10-18 18:38:14','2025-10-18 18:38:14','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(619,94,'Pascal Y.','pascaly@example.com','','','2025-07-30 12:40:16','2025-07-30 12:40:16','Preis-Leistung stimmt absolut. Ich habe es schon mehrfach nachbestellt.',0,'1','','review',0,0),
(620,94,'Stefan T.','stefant@example.com','','','2025-10-09 15:27:55','2025-10-09 15:27:55','Solides Produkt, würde ich weiterempfehlen. Hätte gern eine grössere Packung.',0,'1','','review',0,0),
(621,94,'David F.','davidf@example.com','','','2025-06-28 12:03:18','2025-06-28 12:03:18','Macht einen guten Job. Nach ein paar Wochen sehe ich erste Resultate.',0,'1','','review',0,0),
(622,94,'Fabienne U.','fabienneu@example.com','','','2025-08-30 12:07:26','2025-08-30 12:07:26','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(623,94,'Anna M.','annam@example.com','','','2026-05-10 12:12:11','2026-05-10 12:12:11','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(624,94,'Michael R.','michaelr@example.com','','','2026-02-11 12:30:32','2026-02-11 12:30:32','Macht einen guten Job. Nach ein paar Wochen sehe ich erste Resultate.',0,'1','','review',0,0),
(625,94,'Thomas W.','thomasw@example.com','','','2026-05-03 06:35:52','2026-05-03 06:35:52','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(626,94,'Daniel C.','danielc@example.com','','','2026-04-24 22:18:25','2026-04-24 22:18:25','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(627,94,'David F.','davidf@example.com','','','2025-07-15 10:57:03','2025-07-15 10:57:03','Preis-Leistung stimmt absolut. Ich habe es schon mehrfach nachbestellt.',0,'1','','review',0,0),
(628,94,'Nicole P.','nicolep@example.com','','','2025-07-11 21:58:50','2025-07-11 21:58:50','Mittelmässig. Für den Preis hätte ich mir etwas mehr erwartet.',0,'1','','review',0,0),
(629,94,'Nadia F.','nadiaf@example.com','','','2025-06-21 15:56:33','2025-06-21 15:56:33','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(630,94,'Vanessa E.','vanessae@example.com','','','2025-09-19 00:10:13','2025-09-19 00:10:13','Solides Produkt, würde ich weiterempfehlen. Hätte gern eine grössere Packung.',0,'1','','review',0,0),
(631,94,'Thomas W.','thomasw@example.com','','','2026-04-05 02:18:50','2026-04-05 02:18:50','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(632,93,'Lena S.','lenas@example.com','','','2025-10-29 10:31:42','2025-10-29 10:31:42','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(633,93,'Reto A.','retoa@example.com','','','2026-01-09 10:20:15','2026-01-09 10:20:15','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(634,93,'Christian D.','christiand@example.com','','','2025-10-30 00:04:44','2025-10-30 00:04:44','Nicht schlecht, aber auch nicht überragend. Eher durchschnittlich.',0,'1','','review',0,0),
(635,93,'Christian D.','christiand@example.com','','','2025-11-20 16:48:46','2025-11-20 16:48:46','Gutes Produkt, das ich gerne nutze. Der Preis ist etwas hoch, aber die Qualität stimmt.',0,'1','','review',0,0),
(636,93,'Manuela X.','manuelax@example.com','','','2025-12-20 04:20:00','2025-12-20 04:20:00','Funktioniert gut. Die Lieferung hat etwas länger gedauert als erwartet.',0,'1','','review',0,0),
(637,93,'Marco G.','marcog@example.com','','','2025-07-30 18:04:03','2025-07-30 18:04:03','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(638,93,'Nicole P.','nicolep@example.com','','','2026-03-12 08:16:46','2026-03-12 08:16:46','Bin zufrieden, die Wirkung ist spürbar. Der Duft könnte etwas dezenter sein.',0,'1','','review',0,0),
(639,93,'Michael R.','michaelr@example.com','','','2026-03-30 20:35:53','2026-03-30 20:35:53','Genau das, was ich gesucht habe. Spürbarer Unterschied nach wenigen Tagen.',0,'1','','review',0,0),
(640,93,'Nicole P.','nicolep@example.com','','','2026-01-08 06:37:00','2026-01-08 06:37:00','Schöne Pflege, zieht gut ein. Einen Stern Abzug, weil die Dosierung etwas knifflig ist.',0,'1','','review',0,0),
(641,93,'Marco G.','marcog@example.com','','','2025-10-09 00:03:41','2025-10-09 00:03:41','Schöne Pflege, zieht gut ein. Einen Stern Abzug, weil die Dosierung etwas knifflig ist.',0,'1','','review',0,0),
(642,93,'Pascal Y.','pascaly@example.com','','','2025-07-25 07:06:54','2025-07-25 07:06:54','Macht einen guten Job. Nach ein paar Wochen sehe ich erste Resultate.',0,'1','','review',0,0),
(643,93,'Jonas H.','jonash@example.com','','','2025-06-20 12:30:19','2025-06-20 12:30:19','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(644,93,'Lukas B.','lukasb@example.com','','','2025-09-20 14:28:44','2025-09-20 14:28:44','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(645,93,'Nicole P.','nicolep@example.com','','','2026-02-01 02:31:07','2026-02-01 02:31:07','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(646,93,'David F.','davidf@example.com','','','2025-06-24 05:19:22','2025-06-24 05:19:22','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(647,42,'Corinne J.','corinnej@example.com','','','2025-10-05 07:34:30','2025-10-05 07:34:30','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(648,42,'Marco G.','marcog@example.com','','','2025-12-15 19:26:11','2025-12-15 19:26:11','Meine empfindliche Haut verträgt es bestens, keine Reizungen. Begeistert!',0,'1','','review',0,0),
(649,42,'Reto A.','retoa@example.com','','','2026-05-23 20:48:44','2026-05-23 20:48:44','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(650,42,'Vanessa E.','vanessae@example.com','','','2025-08-11 12:11:24','2025-08-11 12:11:24','Ganz okay, aber bei mir hat es nicht den grossen Unterschied gemacht.',0,'1','','review',0,0),
(651,42,'Jonas H.','jonash@example.com','','','2026-05-25 21:28:14','2026-05-25 21:28:14','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(652,42,'Nadia F.','nadiaf@example.com','','','2025-07-16 05:24:33','2025-07-16 05:24:33','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(653,42,'Lukas B.','lukasb@example.com','','','2026-05-28 01:21:31','2026-05-28 01:21:31','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(654,42,'Vanessa E.','vanessae@example.com','','','2026-04-19 04:07:40','2026-04-19 04:07:40','Gar nicht zufrieden. Hat bei mir überhaupt nicht funktioniert.',0,'1','','review',0,0),
(655,42,'Christian D.','christiand@example.com','','','2026-05-04 10:08:28','2026-05-04 10:08:28','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(656,42,'Lukas B.','lukasb@example.com','','','2026-02-06 15:59:13','2026-02-06 15:59:13','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(657,42,'Lukas B.','lukasb@example.com','','','2026-05-28 23:47:13','2026-05-28 23:47:13','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(658,42,'Jonas H.','jonash@example.com','','','2026-03-29 10:26:26','2026-03-29 10:26:26','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(659,42,'Stefan T.','stefant@example.com','','','2025-12-14 13:02:13','2025-12-14 13:02:13','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(660,42,'Fabienne U.','fabienneu@example.com','','','2026-02-02 03:37:47','2026-02-02 03:37:47','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(661,42,'Lena S.','lenas@example.com','','','2026-02-12 16:11:27','2026-02-12 16:11:27','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(662,42,'Vanessa E.','vanessae@example.com','','','2026-03-29 02:02:16','2026-03-29 02:02:16','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(663,42,'Marco G.','marcog@example.com','','','2025-08-14 13:42:54','2025-08-14 13:42:54','Schöne Pflege, zieht gut ein. Einen Stern Abzug, weil die Dosierung etwas knifflig ist.',0,'1','','review',0,0),
(664,42,'Lena S.','lenas@example.com','','','2025-06-28 17:42:59','2025-06-28 17:42:59','Genau das, was ich gesucht habe. Spürbarer Unterschied nach wenigen Tagen.',0,'1','','review',0,0),
(665,42,'Daniel C.','danielc@example.com','','','2025-06-28 23:09:21','2025-06-28 23:09:21','Schöne Pflege, zieht gut ein. Einen Stern Abzug, weil die Dosierung etwas knifflig ist.',0,'1','','review',0,0),
(666,42,'Manuela X.','manuelax@example.com','','','2026-04-12 13:26:58','2026-04-12 13:26:58','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(667,42,'Sophie K.','sophiek@example.com','','','2026-05-27 00:56:59','2026-05-27 00:56:59','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(668,42,'Sophie K.','sophiek@example.com','','','2025-11-28 21:27:12','2025-11-28 21:27:12','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(669,42,'Vanessa E.','vanessae@example.com','','','2025-06-28 13:28:07','2025-06-28 13:28:07','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(670,42,'Nadia F.','nadiaf@example.com','','','2025-06-17 11:49:25','2025-06-17 11:49:25','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(671,42,'Tobias K.','tobiask@example.com','','','2025-11-04 05:28:40','2025-11-04 05:28:40','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(672,42,'Laura V.','laurav@example.com','','','2025-10-18 03:54:10','2025-10-18 03:54:10','Genau das, was ich gesucht habe. Spürbarer Unterschied nach wenigen Tagen.',0,'1','','review',0,0),
(673,42,'Carla B.','carlab@example.com','','','2026-04-24 17:56:55','2026-04-24 17:56:55','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(674,42,'Julia H.','juliah@example.com','','','2026-04-10 21:20:21','2026-04-10 21:20:21','Preis-Leistung stimmt absolut. Ich habe es schon mehrfach nachbestellt.',0,'1','','review',0,0),
(675,42,'Anna M.','annam@example.com','','','2025-08-14 19:11:10','2025-08-14 19:11:10','Bin zufrieden, die Wirkung ist spürbar. Der Duft könnte etwas dezenter sein.',0,'1','','review',0,0),
(676,42,'Anna M.','annam@example.com','','','2025-08-24 14:19:01','2025-08-24 14:19:01','Bin zufrieden, die Wirkung ist spürbar. Der Duft könnte etwas dezenter sein.',0,'1','','review',0,0),
(677,42,'Jonas H.','jonash@example.com','','','2025-10-02 08:43:06','2025-10-02 08:43:06','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(678,40,'Manuela X.','manuelax@example.com','','','2026-05-24 19:19:45','2026-05-24 19:19:45','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(679,40,'Carla B.','carlab@example.com','','','2026-02-28 14:12:39','2026-02-28 14:12:39','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(680,40,'Sandro I.','sandroi@example.com','','','2025-07-28 03:15:02','2025-07-28 03:15:02','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(681,40,'Christian D.','christiand@example.com','','','2025-10-09 04:27:54','2025-10-09 04:27:54','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(682,40,'Patrick Z.','patrickz@example.com','','','2026-03-12 13:33:25','2026-03-12 13:33:25','Bin zufrieden, die Wirkung ist spürbar. Der Duft könnte etwas dezenter sein.',0,'1','','review',0,0),
(683,40,'Thomas W.','thomasw@example.com','','','2025-07-11 03:11:40','2025-07-11 03:11:40','Preis-Leistung stimmt absolut. Ich habe es schon mehrfach nachbestellt.',0,'1','','review',0,0),
(684,40,'Andrea N.','andrean@example.com','','','2025-09-09 22:35:08','2025-09-09 22:35:08','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(685,40,'Michael R.','michaelr@example.com','','','2025-08-19 05:56:45','2025-08-19 05:56:45','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(686,40,'Nadia F.','nadiaf@example.com','','','2025-12-11 02:47:19','2025-12-11 02:47:19','Meine empfindliche Haut verträgt es bestens, keine Reizungen. Begeistert!',0,'1','','review',0,0),
(687,40,'Marco G.','marcog@example.com','','','2025-09-15 05:52:46','2025-09-15 05:52:46','Die Wirkung ist dezent. Vielleicht ist es einfach nicht das Richtige für meinen Hauttyp.',0,'1','','review',0,0),
(688,40,'Lukas B.','lukasb@example.com','','','2026-01-27 16:52:31','2026-01-27 16:52:31','Schöne Pflege, zieht gut ein. Einen Stern Abzug, weil die Dosierung etwas knifflig ist.',0,'1','','review',0,0),
(689,40,'David F.','davidf@example.com','','','2026-02-21 02:12:15','2026-02-21 02:12:15','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(690,40,'Thomas W.','thomasw@example.com','','','2025-12-03 04:45:04','2025-12-03 04:45:04','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(691,40,'Manuela X.','manuelax@example.com','','','2025-09-14 12:52:03','2025-09-14 12:52:03','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(692,40,'Anna M.','annam@example.com','','','2026-03-22 08:21:25','2026-03-22 08:21:25','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(693,40,'Melanie O.','melanieo@example.com','','','2025-06-06 19:50:49','2025-06-06 19:50:49','Funktioniert gut. Die Lieferung hat etwas länger gedauert als erwartet.',0,'1','','review',0,0),
(694,40,'Thomas W.','thomasw@example.com','','','2025-08-06 15:15:36','2025-08-06 15:15:36','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(695,40,'Marco G.','marcog@example.com','','','2025-07-04 21:45:01','2025-07-04 21:45:01','Bin zufrieden, die Wirkung ist spürbar. Der Duft könnte etwas dezenter sein.',0,'1','','review',0,0),
(696,40,'Sarah L.','sarahl@example.com','','','2025-08-08 06:48:23','2025-08-08 06:48:23','Genau das, was ich gesucht habe. Spürbarer Unterschied nach wenigen Tagen.',0,'1','','review',0,0),
(697,40,'Melanie O.','melanieo@example.com','','','2025-07-15 15:36:36','2025-07-15 15:36:36','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(698,40,'Carla B.','carlab@example.com','','','2026-04-07 00:40:37','2026-04-07 00:40:37','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(699,40,'Thomas W.','thomasw@example.com','','','2025-12-08 23:04:06','2025-12-08 23:04:06','Genau das, was ich gesucht habe. Spürbarer Unterschied nach wenigen Tagen.',0,'1','','review',0,0),
(700,40,'Stefan T.','stefant@example.com','','','2025-08-20 03:13:51','2025-08-20 03:13:51','Schöne Pflege, zieht gut ein. Einen Stern Abzug, weil die Dosierung etwas knifflig ist.',0,'1','','review',0,0),
(701,40,'Simone R.','simoner@example.com','','','2025-08-16 23:06:50','2025-08-16 23:06:50','Schöne Pflege, zieht gut ein. Einen Stern Abzug, weil die Dosierung etwas knifflig ist.',0,'1','','review',0,0),
(702,40,'Sophie K.','sophiek@example.com','','','2026-02-20 06:42:31','2026-02-20 06:42:31','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(703,40,'Daniel C.','danielc@example.com','','','2025-11-08 08:21:01','2025-11-08 08:21:01','Meine empfindliche Haut verträgt es bestens, keine Reizungen. Begeistert!',0,'1','','review',0,0),
(704,40,'Nadia F.','nadiaf@example.com','','','2025-11-18 19:51:10','2025-11-18 19:51:10','Preis-Leistung stimmt absolut. Ich habe es schon mehrfach nachbestellt.',0,'1','','review',0,0),
(705,40,'Stefan T.','stefant@example.com','','','2026-04-01 04:47:16','2026-04-01 04:47:16','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(706,40,'Fabienne U.','fabienneu@example.com','','','2025-08-08 12:43:43','2025-08-08 12:43:43','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(707,40,'Simone R.','simoner@example.com','','','2026-05-25 05:09:21','2026-05-25 05:09:21','Funktioniert gut. Die Lieferung hat etwas länger gedauert als erwartet.',0,'1','','review',0,0),
(708,40,'Tobias K.','tobiask@example.com','','','2026-05-05 00:30:25','2026-05-05 00:30:25','Meine empfindliche Haut verträgt es bestens, keine Reizungen. Begeistert!',0,'1','','review',0,0),
(709,40,'Melanie O.','melanieo@example.com','','','2026-01-02 10:48:40','2026-01-02 10:48:40','Solides Produkt, würde ich weiterempfehlen. Hätte gern eine grössere Packung.',0,'1','','review',0,0),
(710,40,'Tobias K.','tobiask@example.com','','','2025-07-03 12:07:29','2025-07-03 12:07:29','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(711,40,'Carla B.','carlab@example.com','','','2025-09-21 03:05:17','2025-09-21 03:05:17','Genau das, was ich gesucht habe. Spürbarer Unterschied nach wenigen Tagen.',0,'1','','review',0,0),
(712,31,'Simone R.','simoner@example.com','','','2026-04-12 02:02:37','2026-04-12 02:02:37','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(713,31,'Nadia F.','nadiaf@example.com','','','2025-07-26 15:17:01','2025-07-26 15:17:01','Gutes Produkt, das ich gerne nutze. Der Preis ist etwas hoch, aber die Qualität stimmt.',0,'1','','review',0,0),
(714,31,'Jonas H.','jonash@example.com','','','2025-08-04 14:52:00','2025-08-04 14:52:00','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(715,31,'Michael R.','michaelr@example.com','','','2025-07-29 15:46:40','2025-07-29 15:46:40','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(716,31,'Melanie O.','melanieo@example.com','','','2026-02-13 06:12:21','2026-02-13 06:12:21','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(717,31,'Marco G.','marcog@example.com','','','2025-08-14 10:24:49','2025-08-14 10:24:49','Preis-Leistung stimmt absolut. Ich habe es schon mehrfach nachbestellt.',0,'1','','review',0,0),
(718,31,'Julia H.','juliah@example.com','','','2026-03-15 12:33:02','2026-03-15 12:33:02','Gar nicht zufrieden. Hat bei mir überhaupt nicht funktioniert.',0,'1','','review',0,0),
(719,31,'Michael R.','michaelr@example.com','','','2025-06-22 14:03:19','2025-06-22 14:03:19','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(720,31,'Carla B.','carlab@example.com','','','2025-06-06 21:43:59','2025-06-06 21:43:59','Leider hat mich das Produkt nicht überzeugt. Der Duft ist mir zu intensiv.',0,'1','','review',0,0),
(721,31,'Pascal Y.','pascaly@example.com','','','2025-09-17 10:40:38','2025-09-17 10:40:38','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(722,31,'Sarah L.','sarahl@example.com','','','2026-02-25 06:54:05','2026-02-25 06:54:05','Meine empfindliche Haut verträgt es bestens, keine Reizungen. Begeistert!',0,'1','','review',0,0),
(723,31,'Lena S.','lenas@example.com','','','2025-10-21 17:00:37','2025-10-21 17:00:37','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(724,31,'Stefan T.','stefant@example.com','','','2025-10-07 06:32:16','2025-10-07 06:32:16','Meine empfindliche Haut verträgt es bestens, keine Reizungen. Begeistert!',0,'1','','review',0,0),
(725,31,'Laura V.','laurav@example.com','','','2026-05-13 20:10:32','2026-05-13 20:10:32','Absolut begeistert! Meine Haut fühlt sich seit der ersten Anwendung viel weicher an.',0,'1','','review',0,0),
(726,31,'Pascal Y.','pascaly@example.com','','','2025-12-29 02:51:35','2025-12-29 02:51:35','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(727,31,'Sophie K.','sophiek@example.com','','','2026-05-23 01:23:23','2026-05-23 01:23:23','Schöne Verpackung, tolles Produkt und freundlicher Kundenservice.',0,'1','','review',0,0),
(728,31,'Tobias K.','tobiask@example.com','','','2025-07-29 11:44:08','2025-07-29 11:44:08','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(729,31,'Sarah L.','sarahl@example.com','','','2025-07-04 00:54:49','2025-07-04 00:54:49','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(730,31,'Stefan T.','stefant@example.com','','','2025-06-11 22:35:36','2025-06-11 22:35:36','Mittelmässig. Für den Preis hätte ich mir etwas mehr erwartet.',0,'1','','review',0,0),
(731,31,'Carla B.','carlab@example.com','','','2025-10-28 00:15:36','2025-10-28 00:15:36','Preis-Leistung stimmt absolut. Ich habe es schon mehrfach nachbestellt.',0,'1','','review',0,0),
(732,31,'Simone R.','simoner@example.com','','','2025-07-08 13:47:45','2025-07-08 13:47:45','Bei mir hat es die Haut eher gereizt. Schade, hatte mir mehr erhofft.',0,'1','','review',0,0),
(733,31,'Simone R.','simoner@example.com','','','2025-07-22 22:51:05','2025-07-22 22:51:05','Schöne Pflege, zieht gut ein. Einen Stern Abzug, weil die Dosierung etwas knifflig ist.',0,'1','','review',0,0),
(734,31,'Marco G.','marcog@example.com','','','2026-04-04 20:44:08','2026-04-04 20:44:08','Die Konsistenz gefällt mir nicht und es zieht nur langsam ein.',0,'1','','review',0,0),
(735,31,'Manuela X.','manuelax@example.com','','','2026-04-18 06:37:32','2026-04-18 06:37:32','Sehr hochwertige Pflege und mittlerweile Teil meiner täglichen Routine.',0,'1','','review',0,0),
(736,31,'Thomas W.','thomasw@example.com','','','2025-12-12 23:04:27','2025-12-12 23:04:27','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(737,31,'Carla B.','carlab@example.com','','','2026-01-04 19:38:33','2026-01-04 19:38:33','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(738,31,'Anna M.','annam@example.com','','','2025-08-24 18:01:30','2025-08-24 18:01:30','Endlich ein Produkt, das hält, was es verspricht. Bin rundum zufrieden.',0,'1','','review',0,0),
(739,31,'Tobias K.','tobiask@example.com','','','2025-11-09 10:24:14','2025-11-09 10:24:14','Top Qualität und schnelle Lieferung. Klare Empfehlung!',0,'1','','review',0,0),
(740,31,'David F.','davidf@example.com','','','2025-09-01 20:37:51','2025-09-01 20:37:51','Solides Produkt, würde ich weiterempfehlen. Hätte gern eine grössere Packung.',0,'1','','review',0,0),
(741,31,'Julia H.','juliah@example.com','','','2026-02-22 17:13:40','2026-02-22 17:13:40','Hautverträglich und ergiebig – ein bisschen reicht weit. Sehr empfehlenswert.',0,'1','','review',0,0),
(742,31,'Lena S.','lenas@example.com','','','2025-08-19 02:57:52','2025-08-19 02:57:52','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(743,31,'Simone R.','simoner@example.com','','','2026-04-07 05:40:44','2026-04-07 05:40:44','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(744,31,'Vanessa E.','vanessae@example.com','','','2026-02-15 06:50:00','2026-02-15 06:50:00','Genau das, was ich gesucht habe. Spürbarer Unterschied nach wenigen Tagen.',0,'1','','review',0,0),
(745,31,'Vanessa E.','vanessae@example.com','','','2026-01-28 15:47:33','2026-01-28 15:47:33','Schöne Pflege, zieht gut ein. Einen Stern Abzug, weil die Dosierung etwas knifflig ist.',0,'1','','review',0,0),
(746,31,'Julia H.','juliah@example.com','','','2026-05-11 09:14:48','2026-05-11 09:14:48','Riecht angenehm dezent und zieht super ein. Kaufe ich definitiv wieder.',0,'1','','review',0,0),
(747,450,'WooCommerce','','','','2026-06-02 09:24:15','2026-06-02 09:24:15','Status der Bestellung von Zahlung ausstehend auf In Bearbeitung geändert.',0,'1','WooCommerce','order_note',0,0),
(748,450,'WooCommerce','','','','2026-06-02 09:24:15','2026-06-02 09:24:15','TWINT (Test) bestätigt.',0,'1','WooCommerce','order_note',0,0);
/*!40000 ALTER TABLE `wp_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_e_events`
--

DROP TABLE IF EXISTS `wp_e_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_e_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_data` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created_at_index` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_e_events`
--

LOCK TABLES `wp_e_events` WRITE;
/*!40000 ALTER TABLE `wp_e_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_e_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_links`
--

LOCK TABLES `wp_links` WRITE;
/*!40000 ALTER TABLE `wp_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_merchant_modules_analytics`
--

DROP TABLE IF EXISTS `wp_merchant_modules_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_merchant_modules_analytics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `source_product_id` bigint(20) unsigned DEFAULT NULL,
  `event_type` varchar(200) DEFAULT NULL,
  `customer_id` varchar(400) DEFAULT NULL,
  `related_event_id` bigint(20) unsigned DEFAULT NULL,
  `module_id` varchar(200) DEFAULT NULL,
  `campaign_id` varchar(200) DEFAULT NULL,
  `campaign_cost` decimal(12,4) DEFAULT NULL,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `order_subtotal` decimal(12,4) DEFAULT NULL,
  `order_total` decimal(12,4) DEFAULT NULL,
  `meta_data` longtext DEFAULT NULL,
  `meta_data_2` longtext DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `event_type` (`event_type`),
  KEY `event_type_2` (`event_type`,`timestamp`),
  KEY `event_type_3` (`event_type`,`timestamp`,`module_id`,`campaign_id`),
  KEY `module_id` (`module_id`),
  KEY `campaign_id` (`campaign_id`),
  KEY `order_id` (`order_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_merchant_modules_analytics`
--

LOCK TABLES `wp_merchant_modules_analytics` WRITE;
/*!40000 ALTER TABLE `wp_merchant_modules_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_merchant_modules_analytics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_merchant_sales_notifications`
--

DROP TABLE IF EXISTS `wp_merchant_sales_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_merchant_sales_notifications` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_type` varchar(255) NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `customer_id` varchar(255) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `product_event_type_idx` (`product_id`,`event_type`),
  KEY `product_event_type_customer_idx` (`product_id`,`event_type`,`customer_id`),
  KEY `timestamp_idx` (`timestamp`),
  CONSTRAINT `fk_product_id` FOREIGN KEY (`product_id`) REFERENCES `wp_posts` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_merchant_sales_notifications`
--

LOCK TABLES `wp_merchant_sales_notifications` WRITE;
/*!40000 ALTER TABLE `wp_merchant_sales_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_merchant_sales_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_merchant_sales_notifications_shown`
--

DROP TABLE IF EXISTS `wp_merchant_sales_notifications_shown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_merchant_sales_notifications_shown` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL,
  `customer_id` varchar(255) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `event_id_customer_idx` (`event_id`,`customer_id`),
  CONSTRAINT `fk_event_id` FOREIGN KEY (`event_id`) REFERENCES `wp_merchant_sales_notifications` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_merchant_sales_notifications_shown`
--

LOCK TABLES `wp_merchant_sales_notifications_shown` WRITE;
/*!40000 ALTER TABLE `wp_merchant_sales_notifications_shown` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_merchant_sales_notifications_shown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=4864 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_options`
--

LOCK TABLES `wp_options` WRITE;
/*!40000 ALTER TABLE `wp_options` DISABLE KEYS */;
INSERT INTO `wp_options` VALUES
(1,'cron','a:27:{i:1780321716;a:2:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1780321717;a:1:{s:30:\"wp_delete_temp_updater_backups\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1780321718;a:1:{s:21:\"wp_update_user_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1780321726;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"0d04ed39571b55704c122d726248bbac\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:1:{i:0;s:7:\"WP Cron\";}s:8:\"interval\";i:60;}}}i:1780321727;a:4:{s:14:\"wc_admin_daily\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:20:\"jetpack_clean_nonces\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}s:20:\"jetpack_v2_heartbeat\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:33:\"wc_admin_process_orders_milestone\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1780321737;a:1:{s:30:\"generate_category_lookup_table\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1780321778;a:1:{s:28:\"wp_update_comment_type_batch\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1780321783;a:1:{s:29:\"wc_admin_unsnooze_admin_notes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1780322509;a:1:{s:45:\"woocommerce_marketplace_cron_fetch_promotions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1780322527;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1780322528;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1780322749;a:1:{s:8:\"do_pings\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1780322758;a:1:{s:19:\"delete_fonts_folder\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2635200;}}}i:1780322958;a:1:{s:30:\"wp_1_wc_regenerate_images_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:39:\"wp_1_wc_regenerate_images_cron_interval\";s:4:\"args\";a:0:{}s:8:\"interval\";i:300;}}}i:1780325316;a:1:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1780327116;a:1:{s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1780328916;a:1:{s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1780395799;a:1:{s:28:\"elementor/tracker/send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1780395803;a:2:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1780395853;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:11:\"fifteendays\";s:4:\"args\";a:0:{}s:8:\"interval\";i:1296000;}}}i:1780399393;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1780406593;a:2:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:31:\"woocommerce_cleanup_rate_limits\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1780408116;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1780417393;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1780444800;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1780876800;a:2:{s:28:\"wpforms_email_summaries_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}s:33:\"wpforms_weekly_entries_count_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}s:7:\"version\";i:2;}','on'),
(2,'siteurl','http://localhost:8090','on'),
(3,'home','http://localhost:8090','on'),
(4,'blogname','Cocolo Demo Shop','on'),
(5,'blogdescription','','on'),
(6,'users_can_register','0','on'),
(7,'admin_email','admin@example.com','on'),
(8,'start_of_week','1','on'),
(9,'use_balanceTags','0','on'),
(10,'use_smilies','1','on'),
(11,'require_name_email','1','on'),
(12,'comments_notify','1','on'),
(13,'posts_per_rss','10','on'),
(14,'rss_use_excerpt','0','on'),
(15,'mailserver_url','mail.example.com','on'),
(16,'mailserver_login','login@example.com','on'),
(17,'mailserver_pass','','on'),
(18,'mailserver_port','110','on'),
(19,'default_category','1','on'),
(20,'default_comment_status','open','on'),
(21,'default_ping_status','open','on'),
(22,'default_pingback_flag','1','on'),
(23,'posts_per_page','10','on'),
(24,'date_format','F j, Y','on'),
(25,'time_format','g:i a','on'),
(26,'links_updated_date_format','F j, Y g:i a','on'),
(27,'comment_moderation','0','on'),
(28,'moderation_notify','1','on'),
(29,'permalink_structure','/%postname%/','on'),
(30,'rewrite_rules','a:251:{s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:21:\"^wc/file/transient/?$\";s:33:\"index.php?wc-transient-file-name=\";s:24:\"^wc/file/transient/(.+)$\";s:44:\"index.php?wc-transient-file-name=$matches[1]\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:7:\"shop/?$\";s:27:\"index.php?post_type=product\";s:37:\"shop/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:32:\"shop/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:24:\"shop/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:43:\"category/(.+?)/wc/file/transient(/(.*))?/?$\";s:65:\"index.php?category_name=$matches[1]&wc/file/transient=$matches[3]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:40:\"tag/([^/]+)/wc/file/transient(/(.*))?/?$\";s:55:\"index.php?tag=$matches[1]&wc/file/transient=$matches[3]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:46:\"e-floating-buttons/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:56:\"e-floating-buttons/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:76:\"e-floating-buttons/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:71:\"e-floating-buttons/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:71:\"e-floating-buttons/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:52:\"e-floating-buttons/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:35:\"e-floating-buttons/([^/]+)/embed/?$\";s:51:\"index.php?e-floating-buttons=$matches[1]&embed=true\";s:39:\"e-floating-buttons/([^/]+)/trackback/?$\";s:45:\"index.php?e-floating-buttons=$matches[1]&tb=1\";s:47:\"e-floating-buttons/([^/]+)/page/?([0-9]{1,})/?$\";s:58:\"index.php?e-floating-buttons=$matches[1]&paged=$matches[2]\";s:54:\"e-floating-buttons/([^/]+)/comment-page-([0-9]{1,})/?$\";s:58:\"index.php?e-floating-buttons=$matches[1]&cpage=$matches[2]\";s:55:\"e-floating-buttons/([^/]+)/wc/file/transient(/(.*))?/?$\";s:70:\"index.php?e-floating-buttons=$matches[1]&wc/file/transient=$matches[3]\";s:44:\"e-floating-buttons/([^/]+)/wc-api(/(.*))?/?$\";s:59:\"index.php?e-floating-buttons=$matches[1]&wc-api=$matches[3]\";s:61:\"e-floating-buttons/[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$\";s:62:\"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]\";s:72:\"e-floating-buttons/[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$\";s:62:\"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]\";s:50:\"e-floating-buttons/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:61:\"e-floating-buttons/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:43:\"e-floating-buttons/([^/]+)(?:/([0-9]+))?/?$\";s:57:\"index.php?e-floating-buttons=$matches[1]&page=$matches[2]\";s:35:\"e-floating-buttons/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"e-floating-buttons/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"e-floating-buttons/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"e-floating-buttons/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"e-floating-buttons/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"e-floating-buttons/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:47:\"elementor_component/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"elementor_component/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"elementor_component/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"elementor_component/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"elementor_component/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"elementor_component/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:36:\"elementor_component/([^/]+)/embed/?$\";s:52:\"index.php?elementor_component=$matches[1]&embed=true\";s:40:\"elementor_component/([^/]+)/trackback/?$\";s:46:\"index.php?elementor_component=$matches[1]&tb=1\";s:48:\"elementor_component/([^/]+)/page/?([0-9]{1,})/?$\";s:59:\"index.php?elementor_component=$matches[1]&paged=$matches[2]\";s:55:\"elementor_component/([^/]+)/comment-page-([0-9]{1,})/?$\";s:59:\"index.php?elementor_component=$matches[1]&cpage=$matches[2]\";s:56:\"elementor_component/([^/]+)/wc/file/transient(/(.*))?/?$\";s:71:\"index.php?elementor_component=$matches[1]&wc/file/transient=$matches[3]\";s:45:\"elementor_component/([^/]+)/wc-api(/(.*))?/?$\";s:60:\"index.php?elementor_component=$matches[1]&wc-api=$matches[3]\";s:62:\"elementor_component/[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$\";s:62:\"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]\";s:73:\"elementor_component/[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$\";s:62:\"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]\";s:51:\"elementor_component/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:62:\"elementor_component/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:44:\"elementor_component/([^/]+)(?:/([0-9]+))?/?$\";s:58:\"index.php?elementor_component=$matches[1]&page=$matches[2]\";s:36:\"elementor_component/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"elementor_component/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"elementor_component/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"elementor_component/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"elementor_component/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"elementor_component/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:44:\"product/([^/]+)/wc/file/transient(/(.*))?/?$\";s:59:\"index.php?product=$matches[1]&wc/file/transient=$matches[3]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$\";s:62:\"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]\";s:61:\"product/[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$\";s:62:\"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:42:\"e_global_class/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:52:\"e_global_class/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:72:\"e_global_class/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"e_global_class/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"e_global_class/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:48:\"e_global_class/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:31:\"e_global_class/([^/]+)/embed/?$\";s:47:\"index.php?e_global_class=$matches[1]&embed=true\";s:35:\"e_global_class/([^/]+)/trackback/?$\";s:41:\"index.php?e_global_class=$matches[1]&tb=1\";s:43:\"e_global_class/([^/]+)/page/?([0-9]{1,})/?$\";s:54:\"index.php?e_global_class=$matches[1]&paged=$matches[2]\";s:50:\"e_global_class/([^/]+)/comment-page-([0-9]{1,})/?$\";s:54:\"index.php?e_global_class=$matches[1]&cpage=$matches[2]\";s:51:\"e_global_class/([^/]+)/wc/file/transient(/(.*))?/?$\";s:66:\"index.php?e_global_class=$matches[1]&wc/file/transient=$matches[3]\";s:40:\"e_global_class/([^/]+)/wc-api(/(.*))?/?$\";s:55:\"index.php?e_global_class=$matches[1]&wc-api=$matches[3]\";s:57:\"e_global_class/[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$\";s:62:\"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]\";s:68:\"e_global_class/[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$\";s:62:\"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]\";s:46:\"e_global_class/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:57:\"e_global_class/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:39:\"e_global_class/([^/]+)(?:/([0-9]+))?/?$\";s:53:\"index.php?e_global_class=$matches[1]&page=$matches[2]\";s:31:\"e_global_class/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\"e_global_class/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\"e_global_class/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"e_global_class/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"e_global_class/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\"e_global_class/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:12:\"sitemap\\.xml\";s:24:\"index.php??sitemap=index\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:40:\"index.php?&page_id=391&cpage=$matches[1]\";s:28:\"wc/file/transient(/(.*))?/?$\";s:40:\"index.php?&wc/file/transient=$matches[2]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:37:\"comments/wc/file/transient(/(.*))?/?$\";s:40:\"index.php?&wc/file/transient=$matches[2]\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:40:\"search/(.+)/wc/file/transient(/(.*))?/?$\";s:53:\"index.php?s=$matches[1]&wc/file/transient=$matches[3]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:43:\"author/([^/]+)/wc/file/transient(/(.*))?/?$\";s:63:\"index.php?author_name=$matches[1]&wc/file/transient=$matches[3]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc/file/transient(/(.*))?/?$\";s:93:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc/file/transient=$matches[5]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:52:\"([0-9]{4})/([0-9]{1,2})/wc/file/transient(/(.*))?/?$\";s:77:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc/file/transient=$matches[4]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:39:\"([0-9]{4})/wc/file/transient(/(.*))?/?$\";s:56:\"index.php?year=$matches[1]&wc/file/transient=$matches[3]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:36:\"(.?.+?)/wc/file/transient(/(.*))?/?$\";s:60:\"index.php?pagename=$matches[1]&wc/file/transient=$matches[3]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:42:\".?.+?/([^/]+)/wc/file/transient(/(.*))?/?$\";s:62:\"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]\";s:53:\".?.+?/attachment/([^/]+)/wc/file/transient(/(.*))?/?$\";s:62:\"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:36:\"([^/]+)/wc/file/transient(/(.*))?/?$\";s:56:\"index.php?name=$matches[1]&wc/file/transient=$matches[3]\";s:25:\"([^/]+)/wc-api(/(.*))?/?$\";s:45:\"index.php?name=$matches[1]&wc-api=$matches[3]\";s:42:\"[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$\";s:62:\"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]\";s:53:\"[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$\";s:62:\"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]\";s:31:\"[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}','on'),
(31,'hack_file','0','on'),
(32,'blog_charset','UTF-8','on'),
(33,'moderation_keys','','off'),
(34,'active_plugins','a:6:{i:0;s:62:\"athemes-addons-for-elementor-lite/athemes-addons-elementor.php\";i:1;s:47:\"athemes-starter-sites/athemes-starter-sites.php\";i:2;s:23:\"elementor/elementor.php\";i:3;s:21:\"merchant/merchant.php\";i:4;s:27:\"woocommerce/woocommerce.php\";i:5;s:24:\"wpforms-lite/wpforms.php\";}','on'),
(35,'category_base','','on'),
(36,'ping_sites','http://rpc.pingomatic.com/','on'),
(37,'comment_max_links','2','on'),
(38,'gmt_offset','0','on'),
(39,'default_email_category','1','on'),
(40,'recently_edited','','off'),
(41,'template','botiga','on'),
(42,'stylesheet','botiga','on'),
(43,'comment_registration','0','on'),
(44,'html_type','text/html','on'),
(45,'use_trackback','0','on'),
(46,'default_role','subscriber','on'),
(47,'db_version','58975','on'),
(48,'uploads_use_yearmonth_folders','1','on'),
(49,'upload_path','','on'),
(50,'blog_public','1','on'),
(51,'default_link_category','2','on'),
(52,'show_on_front','page','on'),
(53,'tag_base','','on'),
(54,'show_avatars','1','on'),
(55,'avatar_rating','G','on'),
(56,'upload_url_path','','on'),
(57,'thumbnail_size_w','150','on'),
(58,'thumbnail_size_h','150','on'),
(59,'thumbnail_crop','1','on'),
(60,'medium_size_w','300','on'),
(61,'medium_size_h','300','on'),
(62,'avatar_default','mystery','on'),
(63,'large_size_w','1024','on'),
(64,'large_size_h','1024','on'),
(65,'image_default_link_type','none','on'),
(66,'image_default_size','','on'),
(67,'image_default_align','','on'),
(68,'close_comments_for_old_posts','0','on'),
(69,'close_comments_days_old','14','on'),
(70,'thread_comments','1','on'),
(71,'thread_comments_depth','5','on'),
(72,'page_comments','0','on'),
(73,'comments_per_page','50','on'),
(74,'default_comments_page','newest','on'),
(75,'comment_order','asc','on'),
(76,'sticky_posts','a:0:{}','on'),
(77,'widget_categories','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','auto'),
(78,'widget_text','a:3:{i:1;a:4:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:258:\"<img class=\"alignnone size-full wp-image-83\" style=\"margin-bottom: 12px; display: inline-block;\" src=\"//localhost:8090/wp-content/uploads/sites/125/2021/07/BOTIGA.svg\" alt=\"\" width=\"105\" height=\"18\" />\r\nEntdecke unsere Kollektion natürlicher Pflegeprodukte.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:2;a:4:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:258:\"<img class=\"alignnone size-full wp-image-83\" style=\"margin-bottom: 12px; display: inline-block;\" src=\"//localhost:8090/wp-content/uploads/sites/125/2021/07/BOTIGA.svg\" alt=\"\" width=\"105\" height=\"18\" />\r\nEntdecke unsere Kollektion natürlicher Pflegeprodukte.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}','on'),
(79,'widget_rss','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','auto'),
(80,'uninstall_plugins','a:1:{s:23:\"elementor/elementor.php\";a:2:{i:0;s:21:\"Elementor\\Maintenance\";i:1;s:9:\"uninstall\";}}','off'),
(81,'timezone_string','','on'),
(82,'page_for_posts','393','on'),
(83,'page_on_front','391','on'),
(84,'default_post_format','0','on'),
(85,'link_manager_enabled','0','on'),
(86,'finished_splitting_shared_terms','1','on'),
(88,'medium_large_size_w','768','on'),
(89,'medium_large_size_h','0','on'),
(91,'show_comments_cookies_opt_in','1','on'),
(92,'admin_email_lifespan','1795873716','on'),
(93,'disallowed_keys','','off'),
(94,'comment_previously_approved','1','on'),
(95,'auto_plugin_theme_update_emails','a:0:{}','off'),
(96,'auto_update_core_dev','enabled','on'),
(97,'auto_update_core_minor','enabled','on'),
(98,'auto_update_core_major','enabled','on'),
(99,'wp_force_deactivated_plugins','a:0:{}','on'),
(100,'wp_attachment_pages_enabled','0','on'),
(101,'initial_db_version','58975','on'),
(102,'wp_user_roles','a:7:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:119:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:42:\"elementor_atomic_widgets_access_styles_tab\";b:1;s:45:\"elementor_atomic_widgets_edit_local_css_class\";b:1;s:37:\"elementor_global_classes_update_class\";b:1;s:37:\"elementor_global_classes_remove_class\";b:1;s:36:\"elementor_global_classes_apply_class\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:38:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:42:\"elementor_atomic_widgets_access_styles_tab\";b:1;s:45:\"elementor_atomic_widgets_edit_local_css_class\";b:1;s:37:\"elementor_global_classes_remove_class\";b:1;s:36:\"elementor_global_classes_apply_class\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:14:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:42:\"elementor_atomic_widgets_access_styles_tab\";b:1;s:45:\"elementor_atomic_widgets_edit_local_css_class\";b:1;s:37:\"elementor_global_classes_remove_class\";b:1;s:36:\"elementor_global_classes_apply_class\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:9:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:42:\"elementor_atomic_widgets_access_styles_tab\";b:1;s:45:\"elementor_atomic_widgets_edit_local_css_class\";b:1;s:37:\"elementor_global_classes_remove_class\";b:1;s:36:\"elementor_global_classes_apply_class\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:96:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:42:\"elementor_atomic_widgets_access_styles_tab\";b:1;s:45:\"elementor_atomic_widgets_edit_local_css_class\";b:1;s:37:\"elementor_global_classes_remove_class\";b:1;s:36:\"elementor_global_classes_apply_class\";b:1;}}}','on'),
(103,'fresh_site','0','off'),
(104,'user_count','1','off'),
(105,'widget_block','a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:154:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:227:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:146:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:150:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}','auto'),
(106,'sidebars_widgets','a:7:{s:19:\"wp_inactive_widgets\";a:17:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";i:5;s:32:\"woocommerce_product_categories-1\";i:6;s:26:\"woocommerce_price_filter-1\";i:7;s:31:\"woocommerce_product_tag_cloud-1\";i:8;s:25:\"woocommerce_layered_nav-1\";i:9;s:27:\"woocommerce_rating_filter-1\";i:10;s:32:\"woocommerce_top_rated_products-1\";i:11;s:22:\"woocommerce_products-1\";i:12;s:28:\"woocommerce_recent_reviews-1\";i:13;s:28:\"woocommerce_product_search-1\";i:14;s:6:\"text-1\";i:15;s:10:\"nav_menu-1\";i:16;s:10:\"nav_menu-2\";}s:9:\"sidebar-1\";a:9:{i:0;s:32:\"woocommerce_product_categories-2\";i:1;s:26:\"woocommerce_price_filter-2\";i:2;s:31:\"woocommerce_product_tag_cloud-2\";i:3;s:25:\"woocommerce_layered_nav-2\";i:4;s:27:\"woocommerce_rating_filter-2\";i:5;s:32:\"woocommerce_top_rated_products-2\";i:6;s:22:\"woocommerce_products-2\";i:7;s:28:\"woocommerce_recent_reviews-2\";i:8;s:28:\"woocommerce_product_search-2\";}s:8:\"footer-1\";a:1:{i:0;s:6:\"text-2\";}s:8:\"footer-2\";a:1:{i:0;s:10:\"nav_menu-3\";}s:8:\"footer-3\";a:1:{i:0;s:10:\"nav_menu-4\";}s:8:\"footer-4\";a:0:{}s:13:\"array_version\";i:3;}','auto'),
(107,'widget_pages','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(108,'widget_calendar','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(109,'widget_archives','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(110,'widget_media_audio','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(111,'widget_media_image','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(112,'widget_media_gallery','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(113,'widget_media_video','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(114,'widget_meta','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(115,'widget_search','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(116,'widget_recent-posts','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(117,'widget_recent-comments','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(118,'widget_tag_cloud','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(119,'widget_nav_menu','a:5:{i:1;a:2:{s:5:\"title\";s:12:\"Schnelllinks\";s:8:\"nav_menu\";i:21;}i:2;a:2:{s:5:\"title\";s:9:\"Über uns\";s:8:\"nav_menu\";i:22;}i:3;a:2:{s:5:\"title\";s:12:\"Schnelllinks\";s:8:\"nav_menu\";i:21;}i:4;a:2:{s:5:\"title\";s:9:\"Über uns\";s:8:\"nav_menu\";i:22;}s:12:\"_multiwidget\";i:1;}','auto'),
(120,'widget_custom_html','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(125,'WPLANG','de_CH','auto'),
(132,'action_scheduler_hybrid_store_demarkation','4','auto'),
(133,'schema-ActionScheduler_StoreSchema','8.0.1780322730','auto'),
(134,'schema-ActionScheduler_LoggerSchema','3.0.1780321726','auto'),
(139,'woocommerce_newly_installed','no','auto'),
(140,'woocommerce_schema_version','920','auto'),
(141,'woocommerce_store_address','Friedrichstraße 100','on'),
(142,'woocommerce_store_address_2','','on'),
(143,'woocommerce_store_city','Berlin','on'),
(144,'woocommerce_default_country','DE:BE','on'),
(145,'woocommerce_store_postcode','10117','on'),
(146,'woocommerce_allowed_countries','all','on'),
(147,'woocommerce_all_except_countries','','on'),
(148,'woocommerce_specific_allowed_countries','','on'),
(149,'woocommerce_ship_to_countries','','on'),
(150,'woocommerce_specific_ship_to_countries','','on'),
(151,'woocommerce_default_customer_address','base','on'),
(152,'woocommerce_calc_taxes','no','on'),
(153,'woocommerce_enable_coupons','yes','on'),
(154,'woocommerce_calc_discounts_sequentially','no','off'),
(155,'woocommerce_currency','EUR','on'),
(156,'woocommerce_currency_pos','right_space','on'),
(157,'woocommerce_price_thousand_sep','.','on'),
(158,'woocommerce_price_decimal_sep',',','on'),
(159,'woocommerce_price_num_decimals','2','on'),
(160,'woocommerce_shop_page_id','387','on'),
(161,'woocommerce_cart_redirect_after_add','no','on'),
(162,'woocommerce_enable_ajax_add_to_cart','yes','on'),
(163,'woocommerce_placeholder_image','4','on'),
(164,'woocommerce_weight_unit','kg','on'),
(165,'woocommerce_dimension_unit','cm','on'),
(166,'woocommerce_enable_reviews','yes','on'),
(167,'woocommerce_review_rating_verification_label','yes','off'),
(168,'woocommerce_review_rating_verification_required','no','off'),
(169,'woocommerce_enable_review_rating','yes','on'),
(170,'woocommerce_review_rating_required','yes','off'),
(171,'woocommerce_manage_stock','yes','on'),
(172,'woocommerce_hold_stock_minutes','60','off'),
(173,'woocommerce_notify_low_stock','yes','off'),
(174,'woocommerce_notify_no_stock','yes','off'),
(175,'woocommerce_stock_email_recipient','admin@example.com','off'),
(176,'woocommerce_notify_low_stock_amount','2','off'),
(177,'woocommerce_notify_no_stock_amount','0','on'),
(178,'woocommerce_hide_out_of_stock_items','no','on'),
(179,'woocommerce_stock_format','','on'),
(180,'woocommerce_file_download_method','force','off'),
(181,'woocommerce_downloads_redirect_fallback_allowed','no','off'),
(182,'woocommerce_downloads_require_login','no','off'),
(183,'woocommerce_downloads_grant_access_after_payment','yes','off'),
(184,'woocommerce_downloads_deliver_inline','','off'),
(185,'woocommerce_downloads_add_hash_to_filename','yes','on'),
(186,'woocommerce_downloads_count_partial','yes','on'),
(188,'woocommerce_attribute_lookup_direct_updates','no','on'),
(189,'woocommerce_attribute_lookup_optimized_updates','no','on'),
(190,'woocommerce_product_match_featured_image_by_sku','no','on'),
(191,'woocommerce_prices_include_tax','no','on'),
(192,'woocommerce_tax_based_on','shipping','on'),
(193,'woocommerce_shipping_tax_class','inherit','on'),
(194,'woocommerce_tax_round_at_subtotal','no','on'),
(195,'woocommerce_tax_classes','','on'),
(196,'woocommerce_tax_display_shop','excl','on'),
(197,'woocommerce_tax_display_cart','excl','on'),
(198,'woocommerce_price_display_suffix','','on'),
(199,'woocommerce_tax_total_display','itemized','off'),
(200,'woocommerce_enable_shipping_calc','yes','off'),
(201,'woocommerce_shipping_cost_requires_address','no','on'),
(202,'woocommerce_ship_to_destination','billing','off'),
(203,'woocommerce_shipping_debug_mode','no','on'),
(204,'woocommerce_enable_guest_checkout','yes','off'),
(205,'woocommerce_enable_checkout_login_reminder','no','off'),
(206,'woocommerce_enable_signup_and_login_from_checkout','no','off'),
(207,'woocommerce_enable_delayed_account_creation','no','off'),
(208,'woocommerce_enable_myaccount_registration','no','off'),
(209,'woocommerce_registration_generate_password','yes','off'),
(210,'woocommerce_registration_generate_username','yes','off'),
(211,'woocommerce_erasure_request_removes_order_data','no','off'),
(212,'woocommerce_erasure_request_removes_download_data','no','off'),
(213,'woocommerce_allow_bulk_remove_personal_data','no','off'),
(214,'woocommerce_registration_privacy_policy_text','Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].','on'),
(216,'woocommerce_delete_inactive_accounts','a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}','off'),
(217,'woocommerce_trash_pending_orders','','off'),
(218,'woocommerce_trash_failed_orders','','off'),
(219,'woocommerce_trash_cancelled_orders','','off'),
(220,'woocommerce_anonymize_completed_orders','a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}','off'),
(221,'woocommerce_email_from_name','Demo-Shop M392','off'),
(222,'woocommerce_email_from_address','admin@example.com','off'),
(223,'woocommerce_email_header_image','','off'),
(224,'woocommerce_email_base_color','#7f54b3','off'),
(225,'woocommerce_email_background_color','#f7f7f7','off'),
(226,'woocommerce_email_body_background_color','#ffffff','off'),
(227,'woocommerce_email_text_color','#3c3c3c','off'),
(228,'woocommerce_email_footer_text','{site_title} &mdash; Built with {WooCommerce}','off'),
(229,'woocommerce_email_footer_text_color','#3c3c3c','off'),
(230,'woocommerce_merchant_email_notifications','no','off'),
(231,'woocommerce_cart_page_id','388','off'),
(232,'woocommerce_checkout_page_id','389','off'),
(233,'woocommerce_myaccount_page_id','390','off'),
(235,'woocommerce_force_ssl_checkout','no','on'),
(236,'woocommerce_unforce_ssl_checkout','no','on'),
(237,'woocommerce_checkout_pay_endpoint','order-pay','on'),
(238,'woocommerce_checkout_order_received_endpoint','order-received','on'),
(239,'woocommerce_myaccount_add_payment_method_endpoint','add-payment-method','on'),
(240,'woocommerce_myaccount_delete_payment_method_endpoint','delete-payment-method','on'),
(241,'woocommerce_myaccount_set_default_payment_method_endpoint','set-default-payment-method','on'),
(242,'woocommerce_myaccount_orders_endpoint','orders','on'),
(243,'woocommerce_myaccount_view_order_endpoint','view-order','on'),
(244,'woocommerce_myaccount_downloads_endpoint','downloads','on'),
(245,'woocommerce_myaccount_edit_account_endpoint','edit-account','on'),
(246,'woocommerce_myaccount_edit_address_endpoint','edit-address','on'),
(247,'woocommerce_myaccount_payment_methods_endpoint','payment-methods','on'),
(248,'woocommerce_myaccount_lost_password_endpoint','lost-password','on'),
(249,'woocommerce_logout_endpoint','customer-logout','on'),
(250,'woocommerce_api_enabled','no','on'),
(251,'woocommerce_allow_tracking','no','on'),
(252,'woocommerce_show_marketplace_suggestions','yes','off'),
(253,'woocommerce_custom_orders_table_enabled','yes','on'),
(254,'woocommerce_analytics_enabled','yes','on'),
(255,'woocommerce_feature_order_attribution_enabled','yes','on'),
(256,'woocommerce_feature_site_visibility_badge_enabled','yes','on'),
(257,'woocommerce_feature_product_block_editor_enabled','no','on'),
(258,'woocommerce_hpos_fts_index_enabled','no','on'),
(259,'woocommerce_feature_cost_of_goods_sold_enabled','no','on'),
(260,'woocommerce_single_image_width','600','on'),
(261,'woocommerce_thumbnail_image_width','300','on'),
(264,'wc_downloads_approved_directories_mode','enabled','auto'),
(265,'woocommerce_permalinks','a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}','auto'),
(266,'current_theme_supports_woocommerce','yes','auto'),
(267,'woocommerce_queue_flush_rewrite_rules','no','auto'),
(272,'default_product_cat','15','auto'),
(274,'woocommerce_refund_returns_page_id','9','auto'),
(277,'woocommerce_paypal_settings','a:23:{s:7:\"enabled\";s:2:\"no\";s:5:\"title\";s:6:\"PayPal\";s:11:\"description\";s:85:\"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.\";s:5:\"email\";s:17:\"admin@example.com\";s:8:\"advanced\";s:0:\"\";s:8:\"testmode\";s:2:\"no\";s:5:\"debug\";s:2:\"no\";s:16:\"ipn_notification\";s:3:\"yes\";s:14:\"receiver_email\";s:17:\"admin@example.com\";s:14:\"identity_token\";s:0:\"\";s:14:\"invoice_prefix\";s:3:\"WC-\";s:13:\"send_shipping\";s:3:\"yes\";s:16:\"address_override\";s:2:\"no\";s:13:\"paymentaction\";s:4:\"sale\";s:9:\"image_url\";s:0:\"\";s:11:\"api_details\";s:0:\"\";s:12:\"api_username\";s:0:\"\";s:12:\"api_password\";s:0:\"\";s:13:\"api_signature\";s:0:\"\";s:20:\"sandbox_api_username\";s:0:\"\";s:20:\"sandbox_api_password\";s:0:\"\";s:21:\"sandbox_api_signature\";s:0:\"\";s:12:\"_should_load\";s:2:\"no\";}','on'),
(278,'woocommerce_version','9.5.1','auto'),
(279,'woocommerce_db_version','9.5.1','auto'),
(280,'woocommerce_store_id','c18d3bf7-1835-411b-9c8f-71319c5aaa8d','auto'),
(281,'woocommerce_admin_install_timestamp','1780321727','auto'),
(282,'woocommerce_inbox_variant_assignment','4','auto'),
(283,'woocommerce_remote_variant_assignment','70','auto'),
(289,'woocommerce_admin_notices','a:2:{i:0;s:20:\"no_secure_connection\";i:1;s:14:\"template_files\";}','auto'),
(290,'wc_blocks_version','11.8.0-dev','auto'),
(291,'woocommerce_maxmind_geolocation_settings','a:1:{s:15:\"database_prefix\";s:32:\"WS04oR5kXMKEWUpDVcSv8GNtC9PdhIEJ\";}','on'),
(293,'widget_woocommerce_widget_cart','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(294,'widget_woocommerce_layered_nav_filters','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(295,'widget_woocommerce_layered_nav','a:3:{i:1;a:4:{s:5:\"title\";s:9:\"Filter by\";s:9:\"attribute\";s:0:\"\";s:12:\"display_type\";s:4:\"list\";s:10:\"query_type\";s:3:\"and\";}i:2;a:4:{s:5:\"title\";s:9:\"Filter by\";s:9:\"attribute\";s:0:\"\";s:12:\"display_type\";s:4:\"list\";s:10:\"query_type\";s:3:\"and\";}s:12:\"_multiwidget\";i:1;}','auto'),
(296,'widget_woocommerce_price_filter','a:3:{i:1;a:1:{s:5:\"title\";s:15:\"Filter by price\";}i:2;a:1:{s:5:\"title\";s:15:\"Filter by price\";}s:12:\"_multiwidget\";i:1;}','auto'),
(297,'widget_woocommerce_product_categories','a:3:{i:1;a:8:{s:5:\"title\";s:18:\"Product categories\";s:7:\"orderby\";s:4:\"name\";s:8:\"dropdown\";i:0;s:5:\"count\";i:0;s:12:\"hierarchical\";i:1;s:18:\"show_children_only\";i:0;s:10:\"hide_empty\";i:0;s:9:\"max_depth\";s:0:\"\";}i:2;a:8:{s:5:\"title\";s:18:\"Product categories\";s:7:\"orderby\";s:4:\"name\";s:8:\"dropdown\";i:0;s:5:\"count\";i:0;s:12:\"hierarchical\";i:1;s:18:\"show_children_only\";i:0;s:10:\"hide_empty\";i:0;s:9:\"max_depth\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','auto'),
(298,'widget_woocommerce_product_search','a:3:{i:1;a:1:{s:5:\"title\";s:0:\"\";}i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','auto'),
(299,'widget_woocommerce_product_tag_cloud','a:3:{i:1;a:1:{s:5:\"title\";s:12:\"Product tags\";}i:2;a:1:{s:5:\"title\";s:12:\"Product tags\";}s:12:\"_multiwidget\";i:1;}','auto'),
(300,'widget_woocommerce_products','a:3:{i:1;a:7:{s:5:\"title\";s:8:\"Products\";s:6:\"number\";i:5;s:4:\"show\";s:0:\"\";s:7:\"orderby\";s:4:\"date\";s:5:\"order\";s:4:\"desc\";s:9:\"hide_free\";i:0;s:11:\"show_hidden\";i:0;}i:2;a:7:{s:5:\"title\";s:8:\"Products\";s:6:\"number\";i:5;s:4:\"show\";s:0:\"\";s:7:\"orderby\";s:4:\"date\";s:5:\"order\";s:4:\"desc\";s:9:\"hide_free\";i:0;s:11:\"show_hidden\";i:0;}s:12:\"_multiwidget\";i:1;}','auto'),
(301,'widget_woocommerce_recently_viewed_products','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(302,'widget_woocommerce_top_rated_products','a:3:{i:1;a:2:{s:5:\"title\";s:18:\"Top rated products\";s:6:\"number\";i:5;}i:2;a:2:{s:5:\"title\";s:18:\"Top rated products\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','auto'),
(303,'widget_woocommerce_recent_reviews','a:3:{i:1;a:2:{s:5:\"title\";s:14:\"Recent reviews\";s:6:\"number\";i:10;}i:2;a:2:{s:5:\"title\";s:14:\"Recent reviews\";s:6:\"number\";i:10;}s:12:\"_multiwidget\";i:1;}','auto'),
(304,'widget_woocommerce_rating_filter','a:3:{i:1;a:1:{s:5:\"title\";s:14:\"Average rating\";}i:2;a:1:{s:5:\"title\";s:14:\"Average rating\";}s:12:\"_multiwidget\";i:1;}','auto'),
(305,'_site_transient_timeout_woocommerce_blocks_patterns','1782913727','off'),
(306,'_site_transient_woocommerce_blocks_patterns','a:2:{s:7:\"version\";s:5:\"9.5.1\";s:8:\"patterns\";a:38:{i:0;a:11:{s:5:\"title\";s:6:\"Banner\";s:4:\"slug\";s:25:\"woocommerce-blocks/banner\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:29:\"WooCommerce, featured-selling\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:64:\"/var/www/html/wp-content/plugins/woocommerce/patterns/banner.php\";}i:1;a:11:{s:5:\"title\";s:23:\"Coming Soon Entire Site\";s:4:\"slug\";s:35:\"woocommerce/coming-soon-entire-site\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:5:\"false\";s:11:\"featureFlag\";s:17:\"launch-your-store\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:81:\"/var/www/html/wp-content/plugins/woocommerce/patterns/coming-soon-entire-site.php\";}i:2;a:11:{s:5:\"title\";s:22:\"Coming Soon Store Only\";s:4:\"slug\";s:34:\"woocommerce/coming-soon-store-only\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:5:\"false\";s:11:\"featureFlag\";s:17:\"launch-your-store\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:80:\"/var/www/html/wp-content/plugins/woocommerce/patterns/coming-soon-store-only.php\";}i:3;a:11:{s:5:\"title\";s:11:\"Coming Soon\";s:4:\"slug\";s:23:\"woocommerce/coming-soon\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:5:\"false\";s:11:\"featureFlag\";s:17:\"launch-your-store\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:69:\"/var/www/html/wp-content/plugins/woocommerce/patterns/coming-soon.php\";}i:4;a:11:{s:5:\"title\";s:29:\"Content right with image left\";s:4:\"slug\";s:48:\"woocommerce-blocks/content-right-with-image-left\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:18:\"WooCommerce, About\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:82:\"/var/www/html/wp-content/plugins/woocommerce/patterns/content-right-image-left.php\";}i:5;a:11:{s:5:\"title\";s:30:\"Empfohlen Category Cover Image\";s:4:\"slug\";s:48:\"woocommerce-blocks/featured-category-cover-image\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:18:\"WooCommerce, Intro\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:87:\"/var/www/html/wp-content/plugins/woocommerce/patterns/featured-category-cover-image.php\";}i:6;a:11:{s:5:\"title\";s:25:\"Empfohlen Category Triple\";s:4:\"slug\";s:43:\"woocommerce-blocks/featured-category-triple\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:29:\"WooCommerce, featured-selling\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:82:\"/var/www/html/wp-content/plugins/woocommerce/patterns/featured-category-triple.php\";}i:7;a:11:{s:5:\"title\";s:15:\"Product Filters\";s:4:\"slug\";s:34:\"woocommerce-blocks/product-filters\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:108:\"woocommerce/active-filters, woocommerce/price-filter, woocommerce/attribute-filter, woocommerce/stock-filter\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:65:\"/var/www/html/wp-content/plugins/woocommerce/patterns/filters.php\";}i:8;a:11:{s:5:\"title\";s:12:\"Large Footer\";s:4:\"slug\";s:31:\"woocommerce-blocks/footer-large\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:25:\"core/template-part/footer\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:70:\"/var/www/html/wp-content/plugins/woocommerce/patterns/footer-large.php\";}i:9;a:11:{s:5:\"title\";s:23:\"Footer with Simple Menu\";s:4:\"slug\";s:37:\"woocommerce-blocks/footer-simple-menu\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:25:\"core/template-part/footer\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:76:\"/var/www/html/wp-content/plugins/woocommerce/patterns/footer-simple-menu.php\";}i:10;a:11:{s:5:\"title\";s:17:\"Footer with menus\";s:4:\"slug\";s:38:\"woocommerce-blocks/footer-with-3-menus\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:25:\"core/template-part/footer\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:77:\"/var/www/html/wp-content/plugins/woocommerce/patterns/footer-with-3-menus.php\";}i:11;a:11:{s:5:\"title\";s:28:\"Four Image Grid Content Left\";s:4:\"slug\";s:47:\"woocommerce-blocks/form-image-grid-content-left\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:18:\"WooCommerce, About\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:86:\"/var/www/html/wp-content/plugins/woocommerce/patterns/four-image-grid-content-left.php\";}i:12;a:11:{s:5:\"title\";s:20:\"Centered Header Menu\";s:4:\"slug\";s:39:\"woocommerce-blocks/header-centered-menu\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:25:\"core/template-part/header\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:81:\"/var/www/html/wp-content/plugins/woocommerce/patterns/header-centered-pattern.php\";}i:13;a:11:{s:5:\"title\";s:23:\"Distraction Free Header\";s:4:\"slug\";s:42:\"woocommerce-blocks/header-distraction-free\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:25:\"core/template-part/header\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:81:\"/var/www/html/wp-content/plugins/woocommerce/patterns/header-distraction-free.php\";}i:14;a:11:{s:5:\"title\";s:16:\"Essential Header\";s:4:\"slug\";s:35:\"woocommerce-blocks/header-essential\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:25:\"core/template-part/header\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:74:\"/var/www/html/wp-content/plugins/woocommerce/patterns/header-essential.php\";}i:15;a:11:{s:5:\"title\";s:12:\"Large Header\";s:4:\"slug\";s:31:\"woocommerce-blocks/header-large\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:25:\"core/template-part/header\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:70:\"/var/www/html/wp-content/plugins/woocommerce/patterns/header-large.php\";}i:16;a:11:{s:5:\"title\";s:14:\"Minimal Header\";s:4:\"slug\";s:33:\"woocommerce-blocks/header-minimal\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:25:\"core/template-part/header\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:72:\"/var/www/html/wp-content/plugins/woocommerce/patterns/header-minimal.php\";}i:17;a:11:{s:5:\"title\";s:47:\"Heading with three columns of content with link\";s:4:\"slug\";s:66:\"woocommerce-blocks/heading-with-three-columns-of-content-with-link\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:21:\"WooCommerce, Services\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:105:\"/var/www/html/wp-content/plugins/woocommerce/patterns/heading-with-three-columns-of-content-with-link.php\";}i:18;a:11:{s:5:\"title\";s:20:\"Hero Product 3 Split\";s:4:\"slug\";s:39:\"woocommerce-blocks/hero-product-3-split\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:29:\"WooCommerce, featured-selling\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:78:\"/var/www/html/wp-content/plugins/woocommerce/patterns/hero-product-3-split.php\";}i:19;a:11:{s:5:\"title\";s:23:\"Hero Product Chessboard\";s:4:\"slug\";s:42:\"woocommerce-blocks/hero-product-chessboard\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:29:\"WooCommerce, featured-selling\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:81:\"/var/www/html/wp-content/plugins/woocommerce/patterns/hero-product-chessboard.php\";}i:20;a:11:{s:5:\"title\";s:18:\"Hero Product Split\";s:4:\"slug\";s:37:\"woocommerce-blocks/hero-product-split\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:18:\"WooCommerce, Intro\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:76:\"/var/www/html/wp-content/plugins/woocommerce/patterns/hero-product-split.php\";}i:21;a:11:{s:5:\"title\";s:33:\"Centered content with image below\";s:4:\"slug\";s:52:\"woocommerce-blocks/centered-content-with-image-below\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:18:\"WooCommerce, Intro\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:97:\"/var/www/html/wp-content/plugins/woocommerce/patterns/intro-centered-content-with-image-below.php\";}i:22;a:11:{s:5:\"title\";s:22:\"Just Arrived Full Hero\";s:4:\"slug\";s:41:\"woocommerce-blocks/just-arrived-full-hero\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:18:\"WooCommerce, Intro\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:80:\"/var/www/html/wp-content/plugins/woocommerce/patterns/just-arrived-full-hero.php\";}i:23;a:11:{s:5:\"title\";s:33:\"No Products Found - Clear Filters\";s:4:\"slug\";s:43:\"woocommerce/no-products-found-clear-filters\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:2:\"no\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:83:\"/var/www/html/wp-content/plugins/woocommerce/patterns/no-products-found-filters.php\";}i:24;a:11:{s:5:\"title\";s:17:\"No Products Found\";s:4:\"slug\";s:29:\"woocommerce/no-products-found\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:2:\"no\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:75:\"/var/www/html/wp-content/plugins/woocommerce/patterns/no-products-found.php\";}i:25;a:11:{s:5:\"title\";s:19:\"Default Coming Soon\";s:4:\"slug\";s:36:\"woocommerce/page-coming-soon-default\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:5:\"false\";s:11:\"featureFlag\";s:31:\"coming-soon-newsletter-template\";s:13:\"templateTypes\";s:11:\"coming-soon\";s:6:\"source\";s:82:\"/var/www/html/wp-content/plugins/woocommerce/patterns/page-coming-soon-default.php\";}i:26;a:11:{s:5:\"title\";s:34:\"Coming Soon With Header and Footer\";s:4:\"slug\";s:47:\"woocommerce/page-coming-soon-with-header-footer\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:5:\"false\";s:11:\"featureFlag\";s:31:\"coming-soon-newsletter-template\";s:13:\"templateTypes\";s:11:\"coming-soon\";s:6:\"source\";s:93:\"/var/www/html/wp-content/plugins/woocommerce/patterns/page-coming-soon-with-header-footer.php\";}i:27;a:11:{s:5:\"title\";s:28:\"Product Collection 3 Columns\";s:4:\"slug\";s:47:\"woocommerce-blocks/product-collection-3-columns\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:86:\"/var/www/html/wp-content/plugins/woocommerce/patterns/product-collection-3-columns.php\";}i:28;a:11:{s:5:\"title\";s:28:\"Product Collection 4 Columns\";s:4:\"slug\";s:47:\"woocommerce-blocks/product-collection-4-columns\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:29:\"WooCommerce, featured-selling\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:86:\"/var/www/html/wp-content/plugins/woocommerce/patterns/product-collection-4-columns.php\";}i:29;a:11:{s:5:\"title\";s:28:\"Product Collection 5 Columns\";s:4:\"slug\";s:47:\"woocommerce-blocks/product-collection-5-columns\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:29:\"WooCommerce, featured-selling\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:86:\"/var/www/html/wp-content/plugins/woocommerce/patterns/product-collection-5-columns.php\";}i:30;a:11:{s:5:\"title\";s:48:\"Product Collection: Empfohlen Products 5 Columns\";s:4:\"slug\";s:65:\"woocommerce-blocks/product-collection-featured-products-5-columns\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:29:\"WooCommerce, featured-selling\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:104:\"/var/www/html/wp-content/plugins/woocommerce/patterns/product-collection-featured-products-5-columns.php\";}i:31;a:11:{s:5:\"title\";s:15:\"Product Gallery\";s:4:\"slug\";s:48:\"woocommerce-blocks/product-query-product-gallery\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:29:\"WooCommerce, featured-selling\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:36:\"core/query/woocommerce/product-query\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:87:\"/var/www/html/wp-content/plugins/woocommerce/patterns/product-query-product-gallery.php\";}i:32;a:11:{s:5:\"title\";s:14:\"Product Search\";s:4:\"slug\";s:31:\"woocommerce/product-search-form\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:2:\"no\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:77:\"/var/www/html/wp-content/plugins/woocommerce/patterns/product-search-form.php\";}i:33;a:11:{s:5:\"title\";s:16:\"Related Products\";s:4:\"slug\";s:35:\"woocommerce-blocks/related-products\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:11:\"WooCommerce\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:5:\"false\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:74:\"/var/www/html/wp-content/plugins/woocommerce/patterns/related-products.php\";}i:34;a:11:{s:5:\"title\";s:33:\"Social: Follow us on social media\";s:4:\"slug\";s:51:\"woocommerce-blocks/social-follow-us-in-social-media\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:25:\"WooCommerce, social-media\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:90:\"/var/www/html/wp-content/plugins/woocommerce/patterns/social-follow-us-in-social-media.php\";}i:35;a:11:{s:5:\"title\";s:22:\"Testimonials 3 Columns\";s:4:\"slug\";s:41:\"woocommerce-blocks/testimonials-3-columns\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:20:\"WooCommerce, Reviews\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:80:\"/var/www/html/wp-content/plugins/woocommerce/patterns/testimonials-3-columns.php\";}i:36;a:11:{s:5:\"title\";s:19:\"Testimonials Single\";s:4:\"slug\";s:38:\"woocommerce-blocks/testimonials-single\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:20:\"WooCommerce, Reviews\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:77:\"/var/www/html/wp-content/plugins/woocommerce/patterns/testimonials-single.php\";}i:37;a:11:{s:5:\"title\";s:37:\"Three columns with images and content\";s:4:\"slug\";s:56:\"woocommerce-blocks/three-columns-with-images-and-content\";s:11:\"description\";s:0:\"\";s:13:\"viewportWidth\";s:0:\"\";s:10:\"categories\";s:21:\"WooCommerce, Services\";s:8:\"keywords\";s:0:\"\";s:10:\"blockTypes\";s:0:\"\";s:8:\"inserter\";s:0:\"\";s:11:\"featureFlag\";s:0:\"\";s:13:\"templateTypes\";s:0:\"\";s:6:\"source\";s:95:\"/var/www/html/wp-content/plugins/woocommerce/patterns/three-columns-with-images-and-content.php\";}}}','off'),
(315,'woocommerce_onboarding_profile','a:2:{s:9:\"completed\";b:1;s:7:\"skipped\";b:1;}','auto'),
(320,'woocommerce_default_homepage_layout','two_columns','auto'),
(321,'woocommerce_task_list_hidden_lists','a:1:{i:0;s:5:\"setup\";}','auto'),
(388,'m392_shop_seeded','1','auto'),
(391,'theme_mods_twentytwentyfive','a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1780321763;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}','off'),
(392,'current_theme','Botiga','auto'),
(393,'theme_switched','','auto'),
(394,'botiga-theme-version','2.4.5','auto'),
(395,'botiga_theme_installed_time','1780321763','auto'),
(397,'botiga-legacy_templates_builder_migrated','1','auto'),
(398,'botiga_templates_builder_v3','yes','auto'),
(402,'elementor_onboarded','1','auto'),
(403,'botiga-update-hf','1','auto'),
(404,'botiga-modules','a:3:{s:10:\"hf-builder\";b:1;s:13:\"adobe-typekit\";b:1;s:18:\"local-google-fonts\";b:1;}','auto'),
(405,'woocommerce_catalog_rows','3','auto'),
(406,'woocommerce_catalog_columns','3','auto'),
(407,'woocommerce_maybe_regenerate_images_hash','1285a5ff7740406c73c1187cae2ddf9e','auto'),
(409,'woocommerce_custom_orders_table_created','yes','auto'),
(410,'woocommerce_coming_soon','no','auto'),
(411,'woocommerce_initial_installed_version','9.5.1','off'),
(412,'wc_blocks_db_schema_version','260','auto'),
(413,'wc_remote_inbox_notifications_stored_state','O:8:\"stdClass\":2:{s:22:\"there_were_no_products\";b:0;s:22:\"there_are_now_products\";b:1;}','off'),
(414,'action_scheduler_lock_async-request-runner','6a1e7c6722be56.54333625|1780382883','no'),
(432,'wcpay_was_in_use','no','auto'),
(435,'_site_transient_timeout_browser_562dfcd5b68c64c48b5e26801777ec72','1780927328','off'),
(436,'_site_transient_browser_562dfcd5b68c64c48b5e26801777ec72','a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:9:\"147.0.0.0\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}','off'),
(437,'_site_transient_timeout_php_check_9c9455a4a3a9b8b637e3ca09603c559b','1780927328','off'),
(438,'_site_transient_php_check_9c9455a4a3a9b8b637e3ca09603c559b','a:5:{s:19:\"recommended_version\";s:3:\"8.3\";s:15:\"minimum_version\";s:3:\"7.4\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}','off'),
(457,'can_compress_scripts','0','on'),
(477,'jetpack_connection_active_plugins','a:1:{s:11:\"woocommerce\";a:1:{s:4:\"name\";s:11:\"WooCommerce\";}}','auto'),
(485,'merchant_pre_orders_migrated','1','auto'),
(486,'merchant_pre-orders_ex_fields','1','auto'),
(487,'merchant_floating_mini_cart_merged_with_side_cart','1','auto'),
(488,'merchant_wp_merchant_sales_notifications_version','1','auto'),
(489,'merchant_wp_merchant_sales_notifications_shown_version','1','auto'),
(490,'merchant_wp_merchant_modules_analytics_version','1','auto'),
(491,'merchant_db_version','1.1.0','off'),
(492,'merchant_plugin_installed_time','1780322716','auto'),
(495,'elementor_landing_pages_activation','0','auto'),
(496,'_elementor_pro_free_trial_data','a:2:{s:7:\"timeout\";i:1780386707;s:5:\"value\";s:575:\"[{\"status\":\"inactive\",\"heading\":\"You\\u2019ve come this far. Why stop here?\",\"subheading\":\"Elementor Pro Free Trial\",\"introduction\":\"Take your site beyond the basics with a free 7-day Elementor Pro trial with no strings attached:\",\"listItems\":[\"100+ widgets\",\"Theme Builder\",\"Advanced design controls\",\"Custom CSS for pixel-perfect sites - and more\"],\"ctaText\":\"Unlock my free trial\",\"ctaUrl\":\"https:\\/\\/go.elementor.com\\/go-pro-free-trial-popup\\/\",\"secondaryAction\":\"Not now\",\"image\":\"https:\\/\\/assets.elementor.com\\/pro-free-trial-popup\\/v1\\/images\\/free_trial_banner.png\"}]\";}','off'),
(497,'elementor_checklist','{\"last_opened_timestamp\":null,\"first_closed_checklist_in_editor\":false,\"is_popup_minimized\":false,\"steps\":{\"add_logo\":{\"is_marked_completed\":false,\"is_immutable_completed\":false},\"set_fonts_and_colors\":{\"is_marked_completed\":false,\"is_immutable_completed\":false},\"create_pages\":{\"is_marked_completed\":false,\"is_immutable_completed\":false},\"setup_header\":{\"is_marked_completed\":false,\"is_immutable_completed\":false},\"assign_homepage\":{\"is_marked_completed\":false,\"is_immutable_completed\":false}},\"should_open_in_editor\":false}','auto'),
(498,'elementor_version','4.1.1','auto'),
(499,'elementor_install_history','a:1:{s:5:\"4.1.1\";i:1780322723;}','auto'),
(500,'elementor_events_db_version','1.0.0','off'),
(501,'elementor_atomic_widgets_db_version','1','auto'),
(502,'elementor_global_classes_db_version','3','auto'),
(505,'wpforms_versions_lite','a:16:{s:5:\"1.5.9\";i:1780322729;s:7:\"1.6.7.2\";i:1780322729;s:5:\"1.6.8\";i:1780322729;s:5:\"1.7.5\";i:1780322729;s:7:\"1.7.5.1\";i:1780322729;s:5:\"1.7.7\";i:1780322729;s:5:\"1.8.2\";i:1780322729;s:5:\"1.8.3\";i:-1;s:5:\"1.8.4\";i:-1;s:5:\"1.8.6\";i:-1;s:5:\"1.8.7\";i:-1;s:5:\"1.9.1\";i:1780322729;s:5:\"1.9.2\";i:-1;s:5:\"1.9.7\";i:1780322729;s:7:\"1.9.8.6\";i:1780322729;s:6:\"1.10.1\";i:1780322729;}','auto'),
(508,'wpforms_process_font_awesome_upgrade_status','in_progress','auto'),
(509,'wpforms_process_webhooks_auto_configuration_status','in_progress','auto'),
(510,'wpforms_process_domain_auto_registration_status','in_progress','auto'),
(511,'_wpforms_transient_timeout_templates.json','1781002351','off'),
(512,'_wpforms_transient_templates.json','1780397551','off'),
(513,'wpforms_process_stripe_link_subscriptions_status','in_progress','auto'),
(514,'_wpforms_transient_timeout_splash.json','1780927529','off'),
(515,'_wpforms_transient_splash.json','1780322729','off'),
(516,'wpforms_rotation_activated_plugins','a:0:{}','auto'),
(517,'wpforms_constant_contact_version','3','auto'),
(518,'widget_wpforms-widget','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(521,'wpforms_settings','a:3:{s:13:\"modern-markup\";b:0;s:20:\"modern-markup-is-set\";b:1;s:26:\"modern-markup-hide-setting\";b:1;}','auto'),
(522,'wpforms_admin_notices','a:1:{s:14:\"review_request\";a:2:{s:4:\"time\";i:1780322730;s:9:\"dismissed\";b:0;}}','auto'),
(527,'_wpforms_transient_upload_htaccess_file','a:3:{s:4:\"size\";i:763;s:5:\"mtime\";i:1780397552;s:5:\"ctime\";i:1780397552;}','on'),
(528,'_wpforms_transient_wpforms_/var/www/html/wp-content/uploads/wpforms/cache/.htaccess_file','a:3:{s:4:\"size\";i:472;s:5:\"mtime\";i:1780397552;s:5:\"ctime\";i:1780397552;}','on'),
(532,'athemes_addons_installed_time','1780322733','auto'),
(535,'elementor_active_kit','386','auto'),
(536,'wp_calendar_block_has_published_posts','1','auto'),
(540,'elementor_log','a:1:{s:32:\"49c070f79c9fc675ba37a788ff29569a\";O:31:\"Elementor\\Core\\Logger\\Items\\PHP\":9:{s:7:\"\0*\0date\";s:19:\"2026-06-01 14:05:49\";s:7:\"\0*\0type\";s:7:\"warning\";s:10:\"\0*\0message\";s:139:\"simplexml_load_file(): I/O warning : failed to load external entity &quot;http://localhost:8090/wp-content/uploads/2021/07/BOTIGA.svg&quot;\";s:7:\"\0*\0meta\";a:1:{s:5:\"trace\";a:1:{i:0;a:3:{s:8:\"function\";s:8:\"shutdown\";s:5:\"class\";s:29:\"Elementor\\Core\\Logger\\Manager\";s:4:\"type\";s:2:\"->\";}}}s:8:\"\0*\0times\";i:1;s:14:\"\0*\0times_dates\";a:1:{i:0;s:19:\"2026-06-01 14:05:49\";}s:7:\"\0*\0args\";a:5:{s:4:\"type\";s:7:\"warning\";s:7:\"message\";s:129:\"simplexml_load_file(): I/O warning : failed to load external entity \"http://localhost:8090/wp-content/uploads/2021/07/BOTIGA.svg\"\";s:4:\"file\";s:72:\"/var/www/html/wp-content/plugins/elementor/core/files/file-types/svg.php\";s:4:\"line\";i:161;s:5:\"trace\";b:1;}s:7:\"\0*\0file\";s:72:\"/var/www/html/wp-content/plugins/elementor/core/files/file-types/svg.php\";s:7:\"\0*\0line\";i:161;}}','off'),
(563,'botiga-usage-tracking-enabled','1','auto'),
(566,'merchant-modules','a:3:{s:20:\"inactive-tab-message\";b:1;s:23:\"agree-to-terms-checkbox\";b:1;s:13:\"payment-logos\";b:1;}','auto'),
(567,'atss_current_starter','beauty','auto'),
(568,'elementor_connect_site_key','caa3185f4ec149b3a3375e88906db826','auto'),
(569,'elementor_remote_info_feed_data','a:3:{i:0;a:5:{s:5:\"title\";s:43:\"Introducing Angie: Agentic AI for WordPress\";s:7:\"excerpt\";s:365:\"Meet Angie, agentic AI purpose-built for WordPress. Angie understands your site, connects to your tools, and takes real actions on your behalf. Its first capability, Angie Code, lets you describe any WordPress feature you can imagine and have it built for you in minutes. Production-ready, fully integrated with your site, and safe to test before it ever goes live.\";s:7:\"created\";i:1774270910;s:5:\"badge\";s:3:\"NEW\";s:3:\"url\";s:142:\"https://elementor.com/blog/introducing-angie-agentic-ai-for-wordpress/?utm_source=wp-overview-widget&utm_medium=wp-dash&utm_campaign=news-feed\";}i:1;a:5:{s:5:\"title\";s:59:\"The atomic foundation of version 4 is ready for real sites!\";s:7:\"excerpt\";s:296:\"The alpha phase is complete. Version 4 is now in beta, and the atomic foundation is ready to be used on real sites! This is the final step before the official release of version 4.0, activating the new features automatically on new sites, and becoming the default editing experience in Elementor.\";s:7:\"created\";i:1770651621;s:5:\"badge\";s:3:\"NEW\";s:3:\"url\";s:113:\"https://elementor.com/blog/editor-4-beta/?utm_source=wp-overview-widget&utm_medium=wp-dash&utm_campaign=news-feed\";}i:2;a:5:{s:5:\"title\";s:79:\"Introducing Elementor 3.33: Variables Manager, Custom CSS, Blend Modes, & more!\";s:7:\"excerpt\";s:340:\"Elementor 3.33 builds on the foundation of Editor V4, continuing our mission to create a faster, more scalable, and more intuitive design experience for Web Creators. With the addition of the Variables Manager, element-level Custom CSS, Background Clipping, and Blend Modes, designers have more creative precision and consistency than ever.\";s:7:\"created\";i:1762944115;s:5:\"badge\";s:3:\"NEW\";s:3:\"url\";s:145:\"https://elementor.com/blog/elementor-333-v4-variables-manager-custom-css/?utm_source=wp-overview-widget&utm_medium=wp-dash&utm_campaign=news-feed\";}}','off'),
(572,'downloaded_font_files','a:14:{s:108:\"https://fonts.gstatic.com/s/playfairdisplay/v40/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvXDTbtPY_Q.woff2\";s:109:\"/var/www/html/wp-content//fonts/playfair-display/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvXDTbtPY_Q.woff2\";s:108:\"https://fonts.gstatic.com/s/playfairdisplay/v40/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvXDYbtPY_Q.woff2\";s:109:\"/var/www/html/wp-content//fonts/playfair-display/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvXDYbtPY_Q.woff2\";s:108:\"https://fonts.gstatic.com/s/playfairdisplay/v40/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvXDZbtPY_Q.woff2\";s:109:\"/var/www/html/wp-content//fonts/playfair-display/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvXDZbtPY_Q.woff2\";s:105:\"https://fonts.gstatic.com/s/playfairdisplay/v40/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvXDXbtM.woff2\";s:106:\"/var/www/html/wp-content//fonts/playfair-display/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvXDXbtM.woff2\";s:87:\"https://fonts.gstatic.com/s/sourcesanspro/v23/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNa7lqDY.woff2\";s:89:\"/var/www/html/wp-content//fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNa7lqDY.woff2\";s:87:\"https://fonts.gstatic.com/s/sourcesanspro/v23/6xK3dSBYKcSV-LCoeQqfX1RYOo3qPK7lqDY.woff2\";s:89:\"/var/www/html/wp-content//fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qPK7lqDY.woff2\";s:87:\"https://fonts.gstatic.com/s/sourcesanspro/v23/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNK7lqDY.woff2\";s:89:\"/var/www/html/wp-content//fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNK7lqDY.woff2\";s:87:\"https://fonts.gstatic.com/s/sourcesanspro/v23/6xK3dSBYKcSV-LCoeQqfX1RYOo3qO67lqDY.woff2\";s:89:\"/var/www/html/wp-content//fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qO67lqDY.woff2\";s:87:\"https://fonts.gstatic.com/s/sourcesanspro/v23/6xK3dSBYKcSV-LCoeQqfX1RYOo3qN67lqDY.woff2\";s:89:\"/var/www/html/wp-content//fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qN67lqDY.woff2\";s:87:\"https://fonts.gstatic.com/s/sourcesanspro/v23/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNq7lqDY.woff2\";s:89:\"/var/www/html/wp-content//fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNq7lqDY.woff2\";s:84:\"https://fonts.gstatic.com/s/sourcesanspro/v23/6xK3dSBYKcSV-LCoeQqfX1RYOo3qOK7l.woff2\";s:86:\"/var/www/html/wp-content//fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qOK7l.woff2\";s:68:\"https://fonts.gstatic.com/s/sumana/v12/4UaDrE5TqRBjGj-29hLj36w.woff2\";s:68:\"/var/www/html/wp-content//fonts/sumana/4UaDrE5TqRBjGj-29hLj36w.woff2\";s:68:\"https://fonts.gstatic.com/s/sumana/v12/4UaDrE5TqRBjGj-2-RLj36w.woff2\";s:68:\"/var/www/html/wp-content//fonts/sumana/4UaDrE5TqRBjGj-2-RLj36w.woff2\";s:65:\"https://fonts.gstatic.com/s/sumana/v12/4UaDrE5TqRBjGj-29xLj.woff2\";s:65:\"/var/www/html/wp-content//fonts/sumana/4UaDrE5TqRBjGj-29xLj.woff2\";}','off'),
(580,'_elementor_element_cache_unique_id','092918d9a5eb55fd11f59f61ce549a0d','auto'),
(595,'wpforms_splash_version','1.8.6','auto'),
(596,'_elementor_installed_time','1780322783','auto'),
(601,'_elementor_home_screen_data','a:2:{s:7:\"timeout\";i:1780326389;s:5:\"value\";s:13520:\"{\"top_with_licences\":[{\"license\":[\"free\"],\"title_small\":\"Hi!\",\"title\":\"Unleash your imagination with Elementor\",\"description\":\"Start building your website with Elementor\'s no code drag & drop editor.\",\"button_create_page_title\":\"Create a Page\",\"button_watch_title\":\"Watch a guide\",\"button_watch_url\":\"https:\\/\\/www.youtube.com\\/watch?v=le72grP_Q6k&t=1s\",\"youtube_embed_id\":\"le72grP_Q6k?si=g2akyWNODL6usu6u\"},{\"license\":[\"pro\"],\"title_small\":\"Hi!\",\"title\":\"Unleash your imagination with Elementor\",\"description\":\"Now you\'ve got all the tools to start creating professional, high-performing websites - and that journey begins by creating your first page.\",\"button_create_page_title\":\"Create a Page\",\"button_watch_title\":\"Watch a guide\",\"button_watch_url\":\"https:\\/\\/www.youtube.com\\/watch?v=QdkDGrS8ZZs\",\"youtube_embed_id\":\"QdkDGrS8ZZs?si=s_VjZCQR6Fh1jgB5\"},{\"license\":[\"one\"],\"title_small\":\"Hi!\",\"title\":\"Unleash your imagination with Elementor\",\"description\":\"Now you\'ve got all the tools to start creating professional, high-performing websites - and that journey begins by creating your first page.\",\"button_create_page_title\":\"Create a Page\",\"button_watch_title\":\"Watch a guide\",\"button_watch_url\":\"https:\\/\\/www.youtube.com\\/watch?v=QdkDGrS8ZZs\",\"youtube_embed_id\":\"QdkDGrS8ZZs?si=s_VjZCQR6Fh1jgB5\"}],\"get_started\":[{\"license\":[\"free\"],\"header\":{\"title\":\"Jumpstart your web-creation\",\"description\":\"These quick actions will get your site airborne with a customized design.\"},\"repeater\":[{\"title\":\"Site Settings\",\"title_small\":\"Customize\",\"url\":\"\",\"is_relative_url\":false,\"title_small_color\":\"text.tertiary\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/site-settings.svg\"},{\"title\":\"Site Logo\",\"title_small\":\"Customize\",\"url\":\"\",\"is_relative_url\":false,\"title_small_color\":\"text.tertiary\",\"tab_id\":\"settings-site-identity\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/site-logo.svg\"},{\"title\":\"Global Colors\",\"title_small\":\"Customize\",\"url\":\"\",\"is_relative_url\":false,\"title_small_color\":\"text.tertiary\",\"tab_id\":\"global-colors\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/global-colors.svg\"},{\"title\":\"Global Fonts\",\"title_small\":\"Customize\",\"url\":\"\",\"is_relative_url\":false,\"title_small_color\":\"text.tertiary\",\"tab_id\":\"global-typography\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/global-fonts.svg\"},{\"title\":\"Theme Builder\",\"title_small\":\"Customize\",\"url\":\"admin.php?page=elementor-app\",\"is_relative_url\":false,\"title_small_color\":\"text.tertiary\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/theme-builder.svg\"},{\"title\":\"Popups\",\"title_small\":\"Customize\",\"url\":\"edit.php?post_type=elementor_library&page=popup_templates\",\"is_relative_url\":true,\"title_small_color\":\"text.tertiary\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/popups.svg\"},{\"title\":\"Custom Icons\",\"title_small\":\"Customize\",\"url\":\"admin.php?page=elementor_custom_icons\",\"is_relative_url\":false,\"title_small_color\":\"text.tertiary\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/custom-icons.svg\"},{\"title\":\"Custom Fonts\",\"title_small\":\"Customize\",\"url\":\"admin.php?page=elementor_custom_fonts\",\"is_relative_url\":true,\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/custom-fonts.svg\",\"title_small_color\":\"text.tertiary\"}]},{\"license\":[\"pro\"],\"header\":{\"title\":\"Jumpstart your web-creation\",\"description\":\"These quick actions will get your site airborne with a customized design.\"},\"repeater\":[{\"title\":\"Site Settings\",\"title_small\":\"Customize\",\"url\":\"\",\"is_relative_url\":false,\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/site-settings.svg\"},{\"title\":\"Site Logo\",\"title_small\":\"Customize\",\"url\":\"\",\"is_relative_url\":false,\"tab_id\":\"settings-site-identity\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/site-logo.svg\"},{\"title\":\"Global Colors\",\"title_small\":\"Customize\",\"url\":\"\",\"is_relative_url\":false,\"tab_id\":\"global-colors\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/global-colors.svg\"},{\"title\":\"Global Fonts\",\"title_small\":\"Customize\",\"url\":\"\",\"is_relative_url\":false,\"tab_id\":\"global-typography\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/global-fonts.svg\"},{\"title\":\"Theme Builder\",\"title_small\":\"Customize\",\"url\":\"admin.php?page=elementor-app\",\"is_relative_url\":false,\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/theme-builder.svg\"},{\"title\":\"Popups\",\"title_small\":\"Customize\",\"url\":\"edit.php?post_type=elementor_library&tabs_group=popup&elementor_library_type=popup\",\"is_relative_url\":true,\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/popups.svg\"},{\"title\":\"Custom Icons\",\"title_small\":\"Customize\",\"url\":\"admin.php?page=elementor_custom_icons\",\"is_relative_url\":false,\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/custom-icons.svg\"},{\"title\":\"Custom Fonts\",\"title_small\":\"Customize\",\"url\":\"admin.php?page=elementor_custom_fonts\",\"is_relative_url\":true,\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/custom-fonts.svg\"}]},{\"license\":[\"one\"],\"header\":{\"title\":\"Jumpstart your web-creation\",\"description\":\"These quick actions will get your site airborne with a customized design.\"},\"repeater\":[{\"title\":\"Site Settings\",\"title_small\":\"Customize\",\"url\":\"\",\"is_relative_url\":false,\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/site-settings.svg\"},{\"title\":\"Site Logo\",\"title_small\":\"Customize\",\"url\":\"\",\"is_relative_url\":false,\"tab_id\":\"settings-site-identity\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/site-logo.svg\"},{\"title\":\"Global Colors\",\"title_small\":\"Customize\",\"url\":\"\",\"is_relative_url\":false,\"tab_id\":\"global-colors\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/global-colors.svg\"},{\"title\":\"Global Fonts\",\"title_small\":\"Customize\",\"url\":\"\",\"is_relative_url\":false,\"tab_id\":\"global-typography\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/global-fonts.svg\"},{\"title\":\"Theme Builder\",\"title_small\":\"Customize\",\"url\":\"admin.php?page=elementor-app\",\"is_relative_url\":false,\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/theme-builder.svg\"},{\"title\":\"Popups\",\"title_small\":\"Customize\",\"url\":\"edit.php?post_type=elementor_library&tabs_group=popup&elementor_library_type=popup\",\"is_relative_url\":true,\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/popups.svg\"},{\"title\":\"Custom Icons\",\"title_small\":\"Customize\",\"url\":\"admin.php?page=elementor_custom_icons\",\"is_relative_url\":false,\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/custom-icons.svg\"},{\"title\":\"Custom Fonts\",\"title_small\":\"Customize\",\"url\":\"admin.php?page=elementor_custom_fonts\",\"is_relative_url\":true,\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/custom-fonts.svg\"}]}],\"add_ons\":{\"hide_section\":[\"free\",\"essential\",\"pro\",\"one\"],\"header\":{\"title\":\"Expand your design toolkit\",\"description\":\"These plugins, add-ons, and tools, have been selected to streamline your workflow and maximize your creativity.\"},\"repeater\":[{\"file_path\":\"pojo-accessibility\\/pojo-accessibility.php\",\"title\":\"Ally - Web Accessibility. Simplified.\",\"url\":\"\",\"description\":\"Make your website more accessible with powerful tools to detect and fix issues, enhance usability, and create a better experience for all visitors.\",\"button_label\":\"Install\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/ally_logo.svg\",\"type\":\"wporg\"},{\"file_path\":\"site-mailer\\/site-mailer.php\",\"title\":\"Site Mailer\",\"url\":\"\",\"description\":\"Keep your WordPress emails out of the spam folder with improved deliverability and an easy setup\\u2014no need for an SMTP plugin or complicated configurations.\",\"button_label\":\"Install\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/site-mailer.svg\",\"type\":\"wporg\"},{\"file_path\":\"image-optimization\\/image-optimization.php\",\"title\":\"Image Optimizer\",\"url\":\"https:\\/\\/go.elementor.com\\/wp-dash-apps-author-uri-elementor-io\\/\",\"description\":\"Check out this incredibly useful plugin that will compress and optimize your images, giving you leaner, faster websites.\",\"button_label\":\"Install\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/image-optimizer.svg\",\"type\":\"wporg\"},{\"title\":\"Elementor AI\",\"url\":\"https:\\/\\/go.elementor.com\\/wp-dash-apps-author-uri-elementor-ai\\/\",\"description\":\"Boost creativity with Elementor AI. Craft & enhance copy, create custom CSS & Code, and generate images to elevate your website.\",\"button_label\":\"Let\'s go\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/elementor.svg\",\"type\":\"link\",\"condition\":{\"key\":\"introduction_meta\",\"value\":\"ai_get_started\"}}],\"footer\":{\"label\":\"Explore more add-ons\",\"file_path\":\"wp-admin\\/admin.php?page=elementor-apps\"}},\"sidebar_promotion_variants\":[{\"license\":[\"essential\"],\"is_enabled\":\"true\",\"type\":\"banner\",\"data\":{\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/essential-upgrade.svg\",\"link\":\"https:\\/\\/go.elementor.com\\/go-pro-advanced-home-sidebar-upgrade\\/\"}},{\"license\":[\"free\"],\"is_enabled\":\"true\",\"type\":\"banner\",\"data\":{\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/upgrade-free.svg\",\"link\":\"https:\\/\\/go.elementor.com\\/go-pro-home-sidebar-upgrade\\/\"}},{\"license\":[\"expired\"],\"is_enabled\":\"true\",\"type\":\"banner\",\"data\":{\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/upgrade-free.svg\",\"link\":\"https:\\/\\/go.elementor.com\\/go-pro-home-sidebar-expired\\/\"}},{\"license\":[\"free\"],\"is_enabled\":\"false\",\"type\":\"default\",\"data\":{\"header\":{\"title\":\"Bring your vision to life\",\"description\":\"Get complete design flexibility for your website with Elementor Pro\'s advanced tools and premium features.\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/update-sidebar.svg\"},\"cta\":{\"label\":\"Upgrade Now\",\"url\":\"https:\\/\\/go.elementor.com\\/go-pro-home-sidebar-upgrade\\/\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/icon-crown.svg\"},\"repeater\":[{\"title\":\"Popup Builder\"},{\"title\":\"Custom Code & CSS\"},{\"title\":\"E-commerce Features\"},{\"title\":\"Collaborative Notes\"},{\"title\":\"Form Submission\"},{\"title\":\"Form Integrations\"},{\"title\":\"Custom Attributes\"},{\"title\":\"Role Manager\"}]}},{\"license\":[\"pro\"],\"is_enabled\":\"false\",\"type\":\"default\",\"data\":{\"header\":{\"title\":\"Bring your vision to life\",\"description\":\"Get complete design flexibility for your website with Elementor Pro\'s advanced tools and premium features.\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/update-sidebar.svg\"},\"cta\":{\"label\":\"Upgrade Now\",\"url\":\"https:\\/\\/go.elementor.com\\/go-pro-home-sidebar-upgrade\\/\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/icon-crown.svg\"},\"repeater\":[{\"title\":\"Popup Builder\"},{\"title\":\"Custom Code & CSS\"},{\"title\":\"E-commerce Features\"},{\"title\":\"Collaborative Notes\"},{\"title\":\"Form Submission\"},{\"title\":\"Form Integrations\"},{\"title\":\"Custom Attributes\"},{\"title\":\"Role Manager\"}]}},{\"license\":[\"one\"],\"is_enabled\":\"false\",\"type\":\"default\",\"data\":{\"header\":{\"title\":\"Bring your vision to life\",\"description\":\"Get complete design flexibility for your website with Elementor Pro\'s advanced tools and premium features.\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/update-sidebar.svg\"},\"cta\":{\"label\":\"Upgrade Now\",\"url\":\"https:\\/\\/go.elementor.com\\/go-pro-home-sidebar-upgrade\\/\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/icon-crown.svg\"},\"repeater\":[{\"title\":\"Popup Builder\"},{\"title\":\"Custom Code & CSS\"},{\"title\":\"E-commerce Features\"},{\"title\":\"Collaborative Notes\"},{\"title\":\"Form Submission\"},{\"title\":\"Form Integrations\"},{\"title\":\"Custom Attributes\"},{\"title\":\"Role Manager\"}]}}],\"external_links\":[{\"label\":\"Help Center\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/icon-question-mark.svg\",\"url\":\"https:\\/\\/elementor.com\\/help\\/\"},{\"label\":\"Youtube\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/icon-youtube.svg\",\"url\":\"https:\\/\\/www.youtube.com\\/@Elementor\"},{\"label\":\"Facebook Community\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/icon-community.svg\",\"url\":\"https:\\/\\/www.facebook.com\\/groups\\/Elementors\"},{\"label\":\"Blog\",\"image\":\"https:\\/\\/assets.elementor.com\\/home-screen\\/v1\\/images\\/icon-academic-hat.svg\",\"url\":\"https:\\/\\/elementor.com\\/blog\\/\"}],\"site_builder\":[{\"hasInput\":true,\"title\":\"From idea to website in minutes\",\"placeholder\":\"What site do you want to build?\",\"buttonLabel\":\"Create my site\"},{\"hasInput\":false,\"title\":\"From idea to website in minutes\",\"text\":\"Review your brief and generate your website\",\"buttonLabel\":\"Create site\"},{\"hasInput\":false,\"title\":\"Let\'s turn your sitemap into a design\",\"text\":\"Your sitemap is waiting for you to continue.\",\"buttonLabel\":\"Visit sitemap\"},{\"hasInput\":false,\"title\":\"Your site design is waiting\",\"text\":\"Jump back in to review, edit, and add to Elementor.\",\"buttonLabel\":\"Review design\"},{\"hasInput\":false,\"title\":\"Your site design is ready to go live\",\"text\":\"Review and publish your site to continue editing in Elementor.\",\"buttonLabel\":\"Review & publish\"},{\"hasInput\":true,\"title\":\"Expand your site with Elementor AI\",\"placeholder\":\"Which page do you want to create?\",\"buttonLabel\":\"Create page\"},{\"hasInput\":true,\"title\":\"Expand your site with Elementor AI\",\"placeholder\":\"Which page do you want to create?\",\"buttonLabel\":\"Create page\"}]}\";}','off'),
(617,'wpforms_crypto_secret_key','H9b7SC9hMV6uXfI7JbTP+s/njsQKhX6KzrP4saWdqaQ=','auto'),
(653,'elementor_library_category_children','a:0:{}','auto'),
(657,'_athemes_sites_imported_widgets','a:7:{s:19:\"wp_inactive_widgets\";a:17:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";i:5;s:32:\"woocommerce_product_categories-1\";i:6;s:26:\"woocommerce_price_filter-1\";i:7;s:31:\"woocommerce_product_tag_cloud-1\";i:8;s:25:\"woocommerce_layered_nav-1\";i:9;s:27:\"woocommerce_rating_filter-1\";i:10;s:32:\"woocommerce_top_rated_products-1\";i:11;s:22:\"woocommerce_products-1\";i:12;s:28:\"woocommerce_recent_reviews-1\";i:13;s:28:\"woocommerce_product_search-1\";i:14;s:6:\"text-1\";i:15;s:10:\"nav_menu-1\";i:16;s:10:\"nav_menu-2\";}s:9:\"sidebar-1\";a:9:{i:0;s:32:\"woocommerce_product_categories-2\";i:1;s:26:\"woocommerce_price_filter-2\";i:2;s:31:\"woocommerce_product_tag_cloud-2\";i:3;s:25:\"woocommerce_layered_nav-2\";i:4;s:27:\"woocommerce_rating_filter-2\";i:5;s:32:\"woocommerce_top_rated_products-2\";i:6;s:22:\"woocommerce_products-2\";i:7;s:28:\"woocommerce_recent_reviews-2\";i:8;s:28:\"woocommerce_product_search-2\";}s:8:\"footer-1\";a:1:{i:0;s:6:\"text-2\";}s:8:\"footer-2\";a:1:{i:0;s:10:\"nav_menu-3\";}s:8:\"footer-3\";a:1:{i:0;s:10:\"nav_menu-4\";}s:8:\"footer-4\";a:0:{}s:13:\"array_version\";i:3;}','off'),
(660,'woocommerce_demo_store','no','on'),
(661,'woocommerce_demo_store_notice','This is a demo store for testing purposes &mdash; no orders shall be fulfilled.','on'),
(662,'woocommerce_shop_page_display','','on'),
(663,'woocommerce_category_archive_display','','on'),
(664,'woocommerce_default_catalog_orderby','menu_order','on'),
(665,'woocommerce_thumbnail_cropping','uncropped','on'),
(666,'woocommerce_thumbnail_cropping_custom_width','4','on'),
(667,'woocommerce_thumbnail_cropping_custom_height','3','on'),
(668,'woocommerce_checkout_company_field','optional','on'),
(669,'woocommerce_checkout_address_2_field','optional','on'),
(670,'woocommerce_checkout_phone_field','required','on'),
(671,'woocommerce_checkout_highlight_required_fields','yes','on'),
(672,'woocommerce_checkout_terms_and_conditions_checkbox_text','I have read and agree to the website [terms]','on'),
(673,'woocommerce_checkout_privacy_policy_text','Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].','on'),
(674,'wp_page_for_privacy_policy','0','on'),
(675,'woocommerce_terms_page_id','','on'),
(676,'site_icon','385','on'),
(677,'nav_menus_created_posts','a:0:{}','on'),
(678,'theme_mods_botiga','a:89:{i:0;b:0;s:18:\"custom_css_post_id\";i:387;s:40:\"shop_woocommerce_catalog_columns_desktop\";s:1:\"3\";s:29:\"shop_woocommerce_catalog_rows\";s:1:\"3\";s:48:\"botiga_migrate_woo_catalog_columns_and_rows_flag\";b:1;s:24:\"header_components_mobile\";a:2:{i:0;s:6:\"search\";i:1;s:24:\"mobile_woocommerce_icons\";}s:27:\"header_components_offcanvas\";a:2:{i:0;s:6:\"search\";i:1;s:34:\"mobile_offcanvas_woocommerce_icons\";}s:39:\"botiga_migrate_header_mobile_icons_flag\";b:1;s:29:\"scrolltop_side_offset_desktop\";i:30;s:31:\"scrolltop_bottom_offset_desktop\";i:30;s:29:\"header_transparent_display_on\";s:55:\"[{\"type\":\"include\",\"condition\":\"front-page\",\"id\":null}]\";s:31:\"header_image_display_conditions\";s:48:\"[{\"type\":\"include\",\"condition\":\"all\",\"id\":null}]\";s:33:\"botiga_migrate_1_2_1_options_flag\";b:1;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:23;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1626532111;s:4:\"data\";a:6:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}}}s:14:\"footer_widgets\";s:12:\"col3-bigleft\";s:16:\"header_textcolor\";s:6:\"000000\";s:22:\"social_profiles_footer\";s:62:\"https://facebook.com,https://twitter.com,https://instagram.com\";s:16:\"enable_scrolltop\";i:1;s:11:\"custom_logo\";i:163;s:22:\"single_product_gallery\";s:16:\"gallery-vertical\";s:20:\"shop_archive_sidebar\";s:10:\"no-sidebar\";s:29:\"shop_product_quickview_layout\";s:7:\"layout2\";s:18:\"shop_card_elements\";a:2:{i:0;s:39:\"woocommerce_template_loop_product_title\";i:1;s:31:\"woocommerce_template_loop_price\";}s:31:\"shop_product_add_to_cart_layout\";s:7:\"layout2\";s:16:\"botiga_body_font\";s:72:\"{\"font\":\"Source Sans Pro\",\"regularweight\":\"400\",\"category\":\"sans-serif\"}\";s:20:\"botiga_headings_font\";s:73:\"{\"font\":\"Playfair Display\",\"regularweight\":\"400\",\"category\":\"sans-serif\"}\";s:17:\"topbar_visibility\";s:3:\"all\";s:23:\"topbar_components_right\";a:0:{}s:14:\"enable_top_bar\";i:1;s:16:\"topbar_container\";s:15:\"container-fluid\";s:22:\"topbar_components_left\";a:1:{i:0;s:4:\"text\";}s:20:\"topbar_divider_width\";s:9:\"fullwidth\";s:11:\"topbar_text\";s:51:\"Free shipping on orders over $100 with free returns\";s:23:\"center_top_bar_contents\";i:1;s:16:\"shop_breadcrumbs\";s:0:\"\";s:20:\"header_layout_mobile\";s:22:\"header_mobile_layout_3\";s:20:\"shop_checkout_layout\";s:7:\"layout1\";s:34:\"botiga_header_row__main_header_row\";s:106:\"{\"desktop\":[[\"menu\"],[\"logo\"],[\"search\",\"woo_icons\"]],\"mobile\":[[\"search\"],[\"logo\"],[\"mobile_hamburger\"]]}\";s:41:\"botiga_header_row__mobile_main_header_row\";s:17:\"0.598990341759337\";s:35:\"botiga_footer_row__below_footer_row\";s:58:\"{\"desktop\":[[\"social\"],[\"copyright\"]],\"mobile\":[[],[],[]]}\";s:50:\"botiga_footer_row__below_footer_row_height_desktop\";i:64;s:51:\"botiga_footer_row__below_footer_row_columns_desktop\";s:1:\"2\";s:58:\"botiga_footer_row__below_footer_row_columns_layout_desktop\";s:10:\"2col-equal\";s:54:\"botiga_footer_row__below_footer_row_border_top_desktop\";i:1;s:70:\"botiga_footer_row__below_footer_row_column1_vertical_alignment_desktop\";s:3:\"top\";s:72:\"botiga_footer_row__below_footer_row_column1_horizontal_alignment_desktop\";s:5:\"start\";s:70:\"botiga_footer_row__below_footer_row_column2_vertical_alignment_desktop\";s:6:\"middle\";s:72:\"botiga_footer_row__below_footer_row_column2_horizontal_alignment_desktop\";s:3:\"end\";s:35:\"botiga_footer_row__above_footer_row\";s:66:\"{\"desktop\":[[],[],[]],\"mobile\":[[],[],[]],\"mobile_offcanvas\":[[]]}\";s:34:\"botiga_footer_row__main_footer_row\";s:69:\"{\"desktop\":[[\"widget1\"],[\"widget2\"],[\"widget3\"]],\"mobile\":[[],[],[]]}\";s:48:\"botiga_footer_row__main_footer_row_height_tablet\";i:551;s:48:\"botiga_footer_row__main_footer_row_height_mobile\";i:568;s:36:\"botiga_templates_builder_new_ui_flag\";b:1;s:33:\"botiga_migrate_2_0_5_options_flag\";b:1;s:33:\"botiga_migrate_2_0_7_options_flag\";b:1;s:52:\"botiga_single_product_elements_merchant_modules_flag\";b:1;s:18:\"accordion_to_lists\";i:0;s:32:\"accordion_to_lists_initial_state\";s:8:\"expanded\";s:46:\"botiga_migrate_accordion_style_to_wdigets_flag\";b:1;s:39:\"botiga_enable_templates_builder_v3_flag\";b:1;s:33:\"botiga_migrate_2_0_0_modules_flag\";b:1;s:33:\"botiga_migrate_2_1_0_options_flag\";b:1;s:15:\"logo_site_title\";i:1;s:16:\"background_color\";s:7:\"#FFFFFF\";s:15:\"color_body_text\";s:7:\"#202833\";s:24:\"content_cards_background\";s:7:\"#E9F3F2\";s:18:\"color_link_default\";s:7:\"#0AA99D\";s:16:\"color_link_hover\";s:7:\"#066B63\";s:15:\"color_heading_1\";s:7:\"#0B0C0F\";s:15:\"color_heading_2\";s:7:\"#0B0C0F\";s:15:\"color_heading_3\";s:7:\"#0B0C0F\";s:15:\"color_heading_4\";s:7:\"#0B0C0F\";s:15:\"color_heading_5\";s:7:\"#0B0C0F\";s:15:\"color_heading_6\";s:7:\"#0B0C0F\";s:16:\"color_forms_text\";s:7:\"#0B0C0F\";s:22:\"color_forms_background\";s:7:\"#FFFFFF\";s:19:\"color_forms_borders\";s:7:\"#C5C7C8\";s:23:\"color_forms_placeholder\";s:7:\"#202833\";s:23:\"button_background_color\";s:7:\"#0AA99D\";s:29:\"button_background_color_hover\";s:7:\"#066B63\";s:19:\"button_border_color\";s:7:\"#0AA99D\";s:25:\"button_border_color_hover\";s:7:\"#066B63\";s:12:\"button_color\";s:7:\"#FFFFFF\";s:18:\"button_color_hover\";s:7:\"#FFFFFF\";s:14:\"color_palettes\";s:8:\"palette8\";s:21:\"custom_palette_toggle\";b:0;s:23:\"botiga_header_menu_font\";s:58:\"{\"font\":\"Sumana\",\"regularweight\":\"400\",\"category\":\"serif\"}\";s:14:\"footer_credits\";s:72:\"{copyright} {year} {site_title} – WooCommerce-Lehrumgebung (Modul 392)\";}','auto'),
(679,'site_logo','163','auto'),
(680,'_athemes_sites_imported_customizer_mods','a:53:{i:0;b:0;s:18:\"custom_css_post_id\";i:387;s:40:\"shop_woocommerce_catalog_columns_desktop\";s:1:\"3\";s:29:\"shop_woocommerce_catalog_rows\";s:1:\"3\";s:48:\"botiga_migrate_woo_catalog_columns_and_rows_flag\";b:1;s:24:\"header_components_mobile\";a:2:{i:0;s:6:\"search\";i:1;s:24:\"mobile_woocommerce_icons\";}s:27:\"header_components_offcanvas\";a:2:{i:0;s:6:\"search\";i:1;s:34:\"mobile_offcanvas_woocommerce_icons\";}s:39:\"botiga_migrate_header_mobile_icons_flag\";b:1;s:29:\"scrolltop_side_offset_desktop\";i:30;s:31:\"scrolltop_bottom_offset_desktop\";i:30;s:29:\"header_transparent_display_on\";s:55:\"[{\"type\":\"include\",\"condition\":\"front-page\",\"id\":null}]\";s:31:\"header_image_display_conditions\";s:48:\"[{\"type\":\"include\",\"condition\":\"all\",\"id\":null}]\";s:33:\"botiga_migrate_1_2_1_options_flag\";b:1;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:18;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1626532111;s:4:\"data\";a:6:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}}}s:14:\"footer_widgets\";s:12:\"col3-bigleft\";s:16:\"header_textcolor\";s:5:\"blank\";s:22:\"social_profiles_footer\";s:62:\"https://facebook.com,https://twitter.com,https://instagram.com\";s:16:\"enable_scrolltop\";i:1;s:11:\"custom_logo\";i:163;s:22:\"single_product_gallery\";s:16:\"gallery-vertical\";s:20:\"shop_archive_sidebar\";s:10:\"no-sidebar\";s:29:\"shop_product_quickview_layout\";s:7:\"layout2\";s:18:\"shop_card_elements\";a:2:{i:0;s:39:\"woocommerce_template_loop_product_title\";i:1;s:31:\"woocommerce_template_loop_price\";}s:31:\"shop_product_add_to_cart_layout\";s:7:\"layout2\";s:16:\"botiga_body_font\";s:62:\"{\"font\":\"Inter\",\"regularweight\":\"400\",\"category\":\"sans-serif\"}\";s:20:\"botiga_headings_font\";s:62:\"{\"font\":\"Inter\",\"regularweight\":\"400\",\"category\":\"sans-serif\"}\";s:17:\"topbar_visibility\";s:3:\"all\";s:23:\"topbar_components_right\";a:0:{}s:14:\"enable_top_bar\";i:1;s:16:\"topbar_container\";s:15:\"container-fluid\";s:22:\"topbar_components_left\";a:1:{i:0;s:4:\"text\";}s:20:\"topbar_divider_width\";s:9:\"fullwidth\";s:11:\"topbar_text\";s:51:\"Free shipping on orders over $100 with free returns\";s:23:\"center_top_bar_contents\";i:1;s:16:\"shop_breadcrumbs\";s:0:\"\";s:20:\"header_layout_mobile\";s:22:\"header_mobile_layout_3\";s:20:\"shop_checkout_layout\";s:7:\"layout1\";s:34:\"botiga_header_row__main_header_row\";s:106:\"{\"desktop\":[[\"menu\"],[\"logo\"],[\"search\",\"woo_icons\"]],\"mobile\":[[\"search\"],[\"logo\"],[\"mobile_hamburger\"]]}\";s:41:\"botiga_header_row__mobile_main_header_row\";s:17:\"0.598990341759337\";s:35:\"botiga_footer_row__below_footer_row\";s:58:\"{\"desktop\":[[\"social\"],[\"copyright\"]],\"mobile\":[[],[],[]]}\";s:50:\"botiga_footer_row__below_footer_row_height_desktop\";i:64;s:51:\"botiga_footer_row__below_footer_row_columns_desktop\";s:1:\"2\";s:58:\"botiga_footer_row__below_footer_row_columns_layout_desktop\";s:10:\"2col-equal\";s:54:\"botiga_footer_row__below_footer_row_border_top_desktop\";i:1;s:70:\"botiga_footer_row__below_footer_row_column1_vertical_alignment_desktop\";s:3:\"top\";s:72:\"botiga_footer_row__below_footer_row_column1_horizontal_alignment_desktop\";s:5:\"start\";s:70:\"botiga_footer_row__below_footer_row_column2_vertical_alignment_desktop\";s:6:\"middle\";s:72:\"botiga_footer_row__below_footer_row_column2_horizontal_alignment_desktop\";s:3:\"end\";s:35:\"botiga_footer_row__above_footer_row\";s:66:\"{\"desktop\":[[],[],[]],\"mobile\":[[],[],[]],\"mobile_offcanvas\":[[]]}\";s:34:\"botiga_footer_row__main_footer_row\";s:69:\"{\"desktop\":[[\"widget1\"],[\"widget2\"],[\"widget3\"]],\"mobile\":[[],[],[]]}\";s:48:\"botiga_footer_row__main_footer_row_height_tablet\";i:551;s:48:\"botiga_footer_row__main_footer_row_height_mobile\";i:568;}','auto'),
(681,'_athemes_sites_imported_customizer_options','a:18:{s:22:\"woocommerce_demo_store\";s:2:\"no\";s:29:\"woocommerce_demo_store_notice\";s:79:\"This is a demo store for testing purposes &mdash; no orders shall be fulfilled.\";s:29:\"woocommerce_shop_page_display\";s:0:\"\";s:36:\"woocommerce_category_archive_display\";s:0:\"\";s:35:\"woocommerce_default_catalog_orderby\";s:10:\"menu_order\";s:30:\"woocommerce_thumbnail_cropping\";s:9:\"uncropped\";s:43:\"woocommerce_thumbnail_cropping_custom_width\";s:1:\"4\";s:44:\"woocommerce_thumbnail_cropping_custom_height\";s:1:\"3\";s:34:\"woocommerce_checkout_company_field\";s:8:\"optional\";s:36:\"woocommerce_checkout_address_2_field\";s:8:\"optional\";s:32:\"woocommerce_checkout_phone_field\";s:8:\"required\";s:46:\"woocommerce_checkout_highlight_required_fields\";s:3:\"yes\";s:55:\"woocommerce_checkout_terms_and_conditions_checkbox_text\";s:44:\"I have read and agree to the website [terms]\";s:40:\"woocommerce_checkout_privacy_policy_text\";s:161:\"Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].\";s:26:\"wp_page_for_privacy_policy\";s:1:\"0\";s:25:\"woocommerce_terms_page_id\";s:0:\"\";s:9:\"site_icon\";s:3:\"385\";s:23:\"nav_menus_created_posts\";a:0:{}}','auto'),
(714,'woocommerce_admin_customize_store_completed','yes','auto'),
(715,'wp_1_wc_regenerate_images_batch_edf0ba10ae8fc1d84ee676d87e1f2fea','a:51:{i:0;a:1:{s:13:\"attachment_id\";s:3:\"385\";}i:1;a:1:{s:13:\"attachment_id\";s:3:\"353\";}i:2;a:1:{s:13:\"attachment_id\";s:3:\"327\";}i:3;a:1:{s:13:\"attachment_id\";s:3:\"326\";}i:4;a:1:{s:13:\"attachment_id\";s:3:\"325\";}i:5;a:1:{s:13:\"attachment_id\";s:3:\"323\";}i:6;a:1:{s:13:\"attachment_id\";s:3:\"320\";}i:7;a:1:{s:13:\"attachment_id\";s:3:\"319\";}i:8;a:1:{s:13:\"attachment_id\";s:3:\"318\";}i:9;a:1:{s:13:\"attachment_id\";s:3:\"317\";}i:10;a:1:{s:13:\"attachment_id\";s:3:\"316\";}i:11;a:1:{s:13:\"attachment_id\";s:3:\"315\";}i:12;a:1:{s:13:\"attachment_id\";s:3:\"311\";}i:13;a:1:{s:13:\"attachment_id\";s:3:\"310\";}i:14;a:1:{s:13:\"attachment_id\";s:3:\"305\";}i:15;a:1:{s:13:\"attachment_id\";s:3:\"258\";}i:16;a:1:{s:13:\"attachment_id\";s:3:\"255\";}i:17;a:1:{s:13:\"attachment_id\";s:3:\"253\";}i:18;a:1:{s:13:\"attachment_id\";s:3:\"249\";}i:19;a:1:{s:13:\"attachment_id\";s:3:\"243\";}i:20;a:1:{s:13:\"attachment_id\";s:3:\"242\";}i:21;a:1:{s:13:\"attachment_id\";s:3:\"190\";}i:22;a:1:{s:13:\"attachment_id\";s:3:\"189\";}i:23;a:1:{s:13:\"attachment_id\";s:3:\"184\";}i:24;a:1:{s:13:\"attachment_id\";s:3:\"172\";}i:25;a:1:{s:13:\"attachment_id\";s:3:\"171\";}i:26;a:1:{s:13:\"attachment_id\";s:3:\"163\";}i:27;a:1:{s:13:\"attachment_id\";s:3:\"146\";}i:28;a:1:{s:13:\"attachment_id\";s:3:\"145\";}i:29;a:1:{s:13:\"attachment_id\";s:3:\"143\";}i:30;a:1:{s:13:\"attachment_id\";s:3:\"141\";}i:31;a:1:{s:13:\"attachment_id\";s:3:\"138\";}i:32;a:1:{s:13:\"attachment_id\";s:3:\"136\";}i:33;a:1:{s:13:\"attachment_id\";s:3:\"134\";}i:34;a:1:{s:13:\"attachment_id\";s:3:\"132\";}i:35;a:1:{s:13:\"attachment_id\";s:3:\"130\";}i:36;a:1:{s:13:\"attachment_id\";s:2:\"88\";}i:37;a:1:{s:13:\"attachment_id\";s:2:\"49\";}i:38;a:1:{s:13:\"attachment_id\";s:2:\"35\";}i:39;a:1:{s:13:\"attachment_id\";s:2:\"34\";}i:40;a:1:{s:13:\"attachment_id\";s:2:\"29\";}i:41;a:1:{s:13:\"attachment_id\";s:2:\"28\";}i:42;a:1:{s:13:\"attachment_id\";s:2:\"27\";}i:43;a:1:{s:13:\"attachment_id\";s:2:\"26\";}i:44;a:1:{s:13:\"attachment_id\";s:2:\"25\";}i:45;a:1:{s:13:\"attachment_id\";s:2:\"24\";}i:46;a:1:{s:13:\"attachment_id\";s:2:\"23\";}i:47;a:1:{s:13:\"attachment_id\";s:2:\"22\";}i:48;a:1:{s:13:\"attachment_id\";s:2:\"21\";}i:49;a:1:{s:13:\"attachment_id\";s:2:\"20\";}i:50;a:1:{s:13:\"attachment_id\";s:1:\"4\";}}','off'),
(1047,'woocommerce_attribute_lookup_last_product_id_to_process','97','auto'),
(1048,'woocommerce_attribute_lookup_processed_count','0','auto'),
(1049,'woocommerce_attribute_lookup_regeneration_in_progress','yes','auto'),
(1060,'athemes-addons-modules','a:69:{s:10:\"posts-list\";b:1;s:14:\"call-to-action\";b:1;s:8:\"flip-box\";b:0;s:12:\"dual-buttons\";b:0;s:6:\"slider\";b:0;s:7:\"gallery\";b:1;s:13:\"pricing-table\";b:0;s:11:\"team-member\";b:1;s:14:\"posts-carousel\";b:0;s:15:\"advanced-button\";b:0;s:13:\"advanced-tabs\";b:0;s:17:\"advanced-carousel\";b:0;s:12:\"testimonials\";b:1;s:16:\"animated-heading\";b:0;s:12:\"dual-heading\";b:0;s:16:\"advanced-heading\";b:0;s:15:\"creative-button\";b:0;s:13:\"whatsapp-chat\";b:0;s:13:\"telegram-chat\";b:0;s:14:\"google-reviews\";b:0;s:8:\"template\";b:0;s:20:\"advanced-google-maps\";b:0;s:14:\"image-hotspots\";b:0;s:10:\"image-card\";b:0;s:12:\"social-proof\";b:0;s:5:\"modal\";b:0;s:13:\"click-to-call\";b:0;s:11:\"service-box\";b:0;s:13:\"service-group\";b:0;s:13:\"contact-form7\";b:0;s:11:\"ninja-forms\";b:0;s:7:\"wpforms\";b:0;s:13:\"gravity-forms\";b:0;s:7:\"weforms\";b:0;s:9:\"mailchimp\";b:0;s:16:\"content-switcher\";b:0;s:14:\"business-hours\";b:1;s:18:\"before-after-image\";b:0;s:13:\"team-carousel\";b:0;s:14:\"content-reveal\";b:0;s:9:\"countdown\";b:0;s:9:\"offcanvas\";b:0;s:12:\"image-scroll\";b:0;s:8:\"timeline\";b:0;s:13:\"video-gallery\";b:0;s:14:\"video-playlist\";b:0;s:14:\"video-carousel\";b:0;s:6:\"lottie\";b:0;s:12:\"pricing-list\";b:0;s:9:\"food-menu\";b:0;s:9:\"page-list\";b:0;s:15:\"image-accordion\";b:0;s:15:\"advanced-social\";b:0;s:16:\"woo-product-grid\";b:0;s:13:\"logo-carousel\";b:0;s:5:\"table\";b:0;s:10:\"pdf-viewer\";b:0;s:11:\"coupon-code\";b:0;s:6:\"charts\";b:0;s:12:\"progress-bar\";b:0;s:9:\"step-flow\";b:0;s:15:\"events-calendar\";b:0;s:14:\"posts-timeline\";b:0;s:11:\"news-ticker\";b:0;s:11:\"video-popup\";b:0;s:18:\"content-protection\";b:0;s:14:\"taxonomy-terms\";b:0;s:12:\"audio-player\";b:0;s:17:\"table-of-contents\";b:0;}','auto'),
(1069,'wpforms_version','1.10.1','auto'),
(1070,'wpforms_version_lite','1.10.1','auto'),
(1071,'wpforms_activated','a:1:{s:4:\"lite\";i:1780382142;}','auto'),
(1098,'m392_fixture_restored','1','auto'),
(1231,'category_children','a:0:{}','auto'),
(4214,'_site_transient_update_core','O:8:\"stdClass\":4:{s:7:\"updates\";a:6:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:63:\"https://downloads.wordpress.org/release/de_CH/wordpress-7.0.zip\";s:6:\"locale\";s:5:\"de_CH\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:63:\"https://downloads.wordpress.org/release/de_CH/wordpress-7.0.zip\";s:10:\"no_content\";s:0:\"\";s:11:\"new_bundled\";s:0:\"\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:3:\"7.0\";s:7:\"version\";s:3:\"7.0\";s:11:\"php_version\";s:3:\"7.4\";s:13:\"mysql_version\";s:5:\"5.5.5\";s:11:\"new_bundled\";s:3:\"6.7\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:57:\"https://downloads.wordpress.org/release/wordpress-7.0.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:57:\"https://downloads.wordpress.org/release/wordpress-7.0.zip\";s:10:\"no_content\";s:68:\"https://downloads.wordpress.org/release/wordpress-7.0-no-content.zip\";s:11:\"new_bundled\";s:69:\"https://downloads.wordpress.org/release/wordpress-7.0-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:3:\"7.0\";s:7:\"version\";s:3:\"7.0\";s:11:\"php_version\";s:3:\"7.4\";s:13:\"mysql_version\";s:5:\"5.5.5\";s:11:\"new_bundled\";s:3:\"6.7\";s:15:\"partial_version\";s:0:\"\";}i:2;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:49:\"https://downloads.w.org/release/wordpress-7.0.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:49:\"https://downloads.w.org/release/wordpress-7.0.zip\";s:10:\"no_content\";s:60:\"https://downloads.w.org/release/wordpress-7.0-no-content.zip\";s:11:\"new_bundled\";s:61:\"https://downloads.w.org/release/wordpress-7.0-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:3:\"7.0\";s:7:\"version\";s:3:\"7.0\";s:11:\"php_version\";s:3:\"7.4\";s:13:\"mysql_version\";s:5:\"5.5.5\";s:11:\"new_bundled\";s:3:\"6.7\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:3;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:51:\"https://downloads.w.org/release/wordpress-6.9.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:51:\"https://downloads.w.org/release/wordpress-6.9.4.zip\";s:10:\"no_content\";s:62:\"https://downloads.w.org/release/wordpress-6.9.4-no-content.zip\";s:11:\"new_bundled\";s:63:\"https://downloads.w.org/release/wordpress-6.9.4-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"6.9.4\";s:7:\"version\";s:5:\"6.9.4\";s:11:\"php_version\";s:6:\"7.2.24\";s:13:\"mysql_version\";s:5:\"5.5.5\";s:11:\"new_bundled\";s:3:\"6.7\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:4;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:51:\"https://downloads.w.org/release/wordpress-6.8.5.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:51:\"https://downloads.w.org/release/wordpress-6.8.5.zip\";s:10:\"no_content\";s:62:\"https://downloads.w.org/release/wordpress-6.8.5-no-content.zip\";s:11:\"new_bundled\";s:63:\"https://downloads.w.org/release/wordpress-6.8.5-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"6.8.5\";s:7:\"version\";s:5:\"6.8.5\";s:11:\"php_version\";s:6:\"7.2.24\";s:13:\"mysql_version\";s:5:\"5.5.5\";s:11:\"new_bundled\";s:3:\"6.7\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:5;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:51:\"https://downloads.w.org/release/wordpress-6.7.5.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:51:\"https://downloads.w.org/release/wordpress-6.7.5.zip\";s:10:\"no_content\";s:62:\"https://downloads.w.org/release/wordpress-6.7.5-no-content.zip\";s:11:\"new_bundled\";s:63:\"https://downloads.w.org/release/wordpress-6.7.5-new-bundled.zip\";s:7:\"partial\";s:61:\"https://downloads.w.org/release/wordpress-6.7.5-partial-2.zip\";s:8:\"rollback\";s:62:\"https://downloads.w.org/release/wordpress-6.7.5-rollback-2.zip\";}s:7:\"current\";s:5:\"6.7.5\";s:7:\"version\";s:5:\"6.7.5\";s:11:\"php_version\";s:6:\"7.2.24\";s:13:\"mysql_version\";s:5:\"5.5.5\";s:11:\"new_bundled\";s:3:\"6.7\";s:15:\"partial_version\";s:5:\"6.7.2\";s:9:\"new_files\";s:0:\"\";}}s:12:\"last_checked\";i:1780395786;s:15:\"version_checked\";s:5:\"6.7.2\";s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:4:\"core\";s:4:\"slug\";s:7:\"default\";s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"6.7.2\";s:7:\"updated\";s:19:\"2025-04-24 21:46:12\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.7.2/de_CH.zip\";s:10:\"autoupdate\";b:1;}}}','off'),
(4675,'product_cat_children','a:0:{}','auto'),
(4687,'_site_transient_timeout_theme_roots','1780397585','off'),
(4688,'_site_transient_theme_roots','a:4:{s:6:\"botiga\";s:7:\"/themes\";s:16:\"twentytwentyfive\";s:7:\"/themes\";s:16:\"twentytwentyfour\";s:7:\"/themes\";s:17:\"twentytwentythree\";s:7:\"/themes\";}','off'),
(4696,'_site_transient_update_themes','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1780395818;s:7:\"checked\";a:4:{s:6:\"botiga\";s:5:\"2.4.5\";s:16:\"twentytwentyfive\";s:3:\"1.0\";s:16:\"twentytwentyfour\";s:3:\"1.3\";s:17:\"twentytwentythree\";s:3:\"1.6\";}s:8:\"response\";a:2:{s:16:\"twentytwentyfive\";a:6:{s:5:\"theme\";s:16:\"twentytwentyfive\";s:11:\"new_version\";s:3:\"1.5\";s:3:\"url\";s:46:\"https://wordpress.org/themes/twentytwentyfive/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/theme/twentytwentyfive.1.5.zip\";s:8:\"requires\";s:3:\"6.7\";s:12:\"requires_php\";s:3:\"7.2\";}s:16:\"twentytwentyfour\";a:6:{s:5:\"theme\";s:16:\"twentytwentyfour\";s:11:\"new_version\";s:3:\"1.5\";s:3:\"url\";s:46:\"https://wordpress.org/themes/twentytwentyfour/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/theme/twentytwentyfour.1.5.zip\";s:8:\"requires\";s:3:\"6.4\";s:12:\"requires_php\";s:3:\"7.0\";}}s:9:\"no_update\";a:2:{s:6:\"botiga\";a:6:{s:5:\"theme\";s:6:\"botiga\";s:11:\"new_version\";s:5:\"2.4.5\";s:3:\"url\";s:36:\"https://wordpress.org/themes/botiga/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/theme/botiga.2.4.5.zip\";s:8:\"requires\";b:0;s:12:\"requires_php\";s:3:\"7.0\";}s:17:\"twentytwentythree\";a:6:{s:5:\"theme\";s:17:\"twentytwentythree\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:47:\"https://wordpress.org/themes/twentytwentythree/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/theme/twentytwentythree.1.6.zip\";s:8:\"requires\";s:3:\"6.1\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}','off'),
(4760,'_site_transient_update_plugins','O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1780395848;s:8:\"response\";a:1:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"5.7\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:53:\"http://downloads.wordpress.org/plugin/akismet.5.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:60:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=2818463\";s:2:\"1x\";s:60:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=2818463\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/akismet/assets/banner-1544x500.png?rev=2900731\";s:2:\"1x\";s:62:\"https://ps.w.org/akismet/assets/banner-772x250.png?rev=2900731\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.8\";s:6:\"tested\";s:3:\"7.0\";s:12:\"requires_php\";s:3:\"7.2\";s:16:\"requires_plugins\";a:0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:7:{s:62:\"athemes-addons-for-elementor-lite/athemes-addons-elementor.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:47:\"w.org/plugins/athemes-addons-for-elementor-lite\";s:4:\"slug\";s:33:\"athemes-addons-for-elementor-lite\";s:6:\"plugin\";s:62:\"athemes-addons-for-elementor-lite/athemes-addons-elementor.php\";s:11:\"new_version\";s:5:\"1.1.9\";s:3:\"url\";s:64:\"https://wordpress.org/plugins/athemes-addons-for-elementor-lite/\";s:7:\"package\";s:81:\"http://downloads.wordpress.org/plugin/athemes-addons-for-elementor-lite.1.1.9.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:86:\"https://ps.w.org/athemes-addons-for-elementor-lite/assets/icon-256x256.gif?rev=3064467\";s:2:\"1x\";s:86:\"https://ps.w.org/athemes-addons-for-elementor-lite/assets/icon-128x128.gif?rev=3064467\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:89:\"https://ps.w.org/athemes-addons-for-elementor-lite/assets/banner-1544x500.png?rev=3064467\";s:2:\"1x\";s:88:\"https://ps.w.org/athemes-addons-for-elementor-lite/assets/banner-772x250.png?rev=3064467\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.5\";}s:47:\"athemes-starter-sites/athemes-starter-sites.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:35:\"w.org/plugins/athemes-starter-sites\";s:4:\"slug\";s:21:\"athemes-starter-sites\";s:6:\"plugin\";s:47:\"athemes-starter-sites/athemes-starter-sites.php\";s:11:\"new_version\";s:5:\"1.1.9\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/athemes-starter-sites/\";s:7:\"package\";s:69:\"http://downloads.wordpress.org/plugin/athemes-starter-sites.1.1.9.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:74:\"https://ps.w.org/athemes-starter-sites/assets/icon-256x256.png?rev=3045781\";s:2:\"1x\";s:74:\"https://ps.w.org/athemes-starter-sites/assets/icon-128x128.png?rev=3045781\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/athemes-starter-sites/assets/banner-1544x500.png?rev=3045781\";s:2:\"1x\";s:76:\"https://ps.w.org/athemes-starter-sites/assets/banner-772x250.png?rev=3045781\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.0\";}s:23:\"elementor/elementor.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:23:\"w.org/plugins/elementor\";s:4:\"slug\";s:9:\"elementor\";s:6:\"plugin\";s:23:\"elementor/elementor.php\";s:11:\"new_version\";s:5:\"4.1.1\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/elementor/\";s:7:\"package\";s:57:\"http://downloads.wordpress.org/plugin/elementor.4.1.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:62:\"https://ps.w.org/elementor/assets/icon-256x256.gif?rev=3444228\";s:2:\"1x\";s:62:\"https://ps.w.org/elementor/assets/icon-128x128.gif?rev=3444228\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/elementor/assets/banner-1544x500.png?rev=3443226\";s:2:\"1x\";s:64:\"https://ps.w.org/elementor/assets/banner-772x250.png?rev=3443226\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"6.6\";}s:9:\"hello.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:59:\"http://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/hello-dolly/assets/banner-1544x500.jpg?rev=2645582\";s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.6\";}s:21:\"merchant/merchant.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:22:\"w.org/plugins/merchant\";s:4:\"slug\";s:8:\"merchant\";s:6:\"plugin\";s:21:\"merchant/merchant.php\";s:11:\"new_version\";s:5:\"2.2.7\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/merchant/\";s:7:\"package\";s:56:\"http://downloads.wordpress.org/plugin/merchant.2.2.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:61:\"https://ps.w.org/merchant/assets/icon-256x256.gif?rev=3293700\";s:2:\"1x\";s:61:\"https://ps.w.org/merchant/assets/icon-128x128.gif?rev=3293700\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/merchant/assets/banner-1544x500.png?rev=3003939\";s:2:\"1x\";s:63:\"https://ps.w.org/merchant/assets/banner-772x250.png?rev=3003939\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"6.4\";}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:6:\"10.8.1\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"http://downloads.wordpress.org/plugin/woocommerce.10.8.1.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:56:\"https://ps.w.org/woocommerce/assets/icon.svg?rev=3234504\";s:3:\"svg\";s:56:\"https://ps.w.org/woocommerce/assets/icon.svg?rev=3234504\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=3234504\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=3234504\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"6.9\";s:6:\"tested\";s:3:\"7.0\";s:12:\"requires_php\";s:3:\"7.4\";s:16:\"requires_plugins\";a:0:{}}s:24:\"wpforms-lite/wpforms.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:26:\"w.org/plugins/wpforms-lite\";s:4:\"slug\";s:12:\"wpforms-lite\";s:6:\"plugin\";s:24:\"wpforms-lite/wpforms.php\";s:11:\"new_version\";s:6:\"1.10.1\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/wpforms-lite/\";s:7:\"package\";s:61:\"http://downloads.wordpress.org/plugin/wpforms-lite.1.10.1.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:57:\"https://ps.w.org/wpforms-lite/assets/icon.svg?rev=3254748\";s:3:\"svg\";s:57:\"https://ps.w.org/wpforms-lite/assets/icon.svg?rev=3254748\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/wpforms-lite/assets/banner-1544x500.png?rev=3091364\";s:2:\"1x\";s:67:\"https://ps.w.org/wpforms-lite/assets/banner-772x250.png?rev=3091364\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/wpforms-lite/assets/banner-1544x500-rtl.png?rev=3254748\";s:2:\"1x\";s:71:\"https://ps.w.org/wpforms-lite/assets/banner-772x250-rtl.png?rev=3254748\";}s:8:\"requires\";s:3:\"5.5\";}}}','off'),
(4808,'elementor_atomic_cache_validity__component-styles-related-posts','a:2:{s:5:\"state\";b:0;s:8:\"children\";a:2:{i:391;a:2:{s:5:\"state\";b:1;s:4:\"meta\";a:0:{}}i:394;a:2:{s:5:\"state\";b:1;s:4:\"meta\";a:0:{}}}}','off'),
(4809,'elementor_atomic_cache_validity__base','a:3:{s:5:\"state\";b:1;s:4:\"meta\";s:13:\"6a1eafd5aacf0\";s:8:\"children\";a:3:{s:7:\"desktop\";b:1;s:6:\"tablet\";b:1;s:6:\"mobile\";b:1;}}','off'),
(4810,'elementor_atomic_cache_validity__global','a:2:{s:5:\"state\";b:0;s:8:\"children\";a:2:{i:391;a:2:{s:5:\"state\";b:0;s:8:\"children\";a:1:{s:8:\"frontend\";a:3:{s:5:\"state\";b:1;s:4:\"meta\";s:13:\"6a1eafd5aae81\";s:8:\"children\";a:3:{s:7:\"desktop\";b:1;s:6:\"tablet\";b:1;s:6:\"mobile\";b:1;}}}}i:394;a:2:{s:5:\"state\";b:0;s:8:\"children\";a:1:{s:8:\"frontend\";a:3:{s:5:\"state\";b:1;s:4:\"meta\";s:13:\"6a1eafdd87e1a\";s:8:\"children\";a:3:{s:7:\"desktop\";b:1;s:6:\"tablet\";b:1;s:6:\"mobile\";b:1;}}}}}}','off'),
(4811,'elementor_atomic_cache_validity__local','a:2:{s:5:\"state\";b:0;s:8:\"children\";a:2:{i:391;a:2:{s:5:\"state\";b:0;s:8:\"children\";a:1:{s:8:\"frontend\";a:3:{s:5:\"state\";b:1;s:4:\"meta\";s:13:\"6a1eafd5aafb1\";s:8:\"children\";a:3:{s:7:\"desktop\";b:1;s:6:\"tablet\";b:1;s:6:\"mobile\";b:1;}}}}i:394;a:2:{s:5:\"state\";b:0;s:8:\"children\";a:1:{s:8:\"frontend\";a:3:{s:5:\"state\";b:1;s:4:\"meta\";s:13:\"6a1eafdd87ff7\";s:8:\"children\";a:3:{s:7:\"desktop\";b:1;s:6:\"tablet\";b:1;s:6:\"mobile\";b:1;}}}}}}','off'),
(4850,'_site_transient_timeout_wp_theme_files_patterns-e138c8f8a81d2683adb1b704bdb1de45','1780399440','off'),
(4851,'_site_transient_wp_theme_files_patterns-e138c8f8a81d2683adb1b704bdb1de45','a:2:{s:7:\"version\";s:5:\"2.4.5\";s:8:\"patterns\";a:0:{}}','off'),
(4853,'_elementor_design_system_sync_css_meta','a:2:{s:4:\"time\";i:1780397666;i:0;b:0;}','auto'),
(4862,'_wpforms_transient_timeout_existing_tables','1781002606','off'),
(4863,'_wpforms_transient_existing_tables','a:2:{s:12:\"wp_wpforms_%\";a:4:{i:0;s:15:\"wp_wpforms_logs\";i:1;s:23:\"wp_wpforms_payment_meta\";i:2;s:19:\"wp_wpforms_payments\";i:3;s:21:\"wp_wpforms_tasks_meta\";}s:15:\"wp_wpforms_logs\";a:1:{i:0;s:15:\"wp_wpforms_logs\";}}','off');
/*!40000 ALTER TABLE `wp_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1093 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_postmeta`
--

LOCK TABLES `wp_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_postmeta` DISABLE KEYS */;
INSERT INTO `wp_postmeta` VALUES
(2,3,'_wp_page_template','default'),
(3,4,'_wp_attached_file','woocommerce-placeholder.png'),
(4,4,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:27:\"woocommerce-placeholder.png\";s:8:\"filesize\";i:48149;s:5:\"sizes\";a:4:{s:6:\"medium\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:12321;}s:5:\"large\";a:5:{s:4:\"file\";s:37:\"woocommerce-placeholder-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:90808;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:4209;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:56643;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(5,10,'_sku','TS-001'),
(6,10,'_regular_price','29.9'),
(7,10,'total_sales','0'),
(8,10,'_tax_status','taxable'),
(9,10,'_tax_class',''),
(10,10,'_manage_stock','no'),
(11,10,'_backorders','no'),
(12,10,'_sold_individually','no'),
(13,10,'_virtual','no'),
(14,10,'_downloadable','no'),
(15,10,'_download_limit','-1'),
(16,10,'_download_expiry','-1'),
(17,10,'_stock',NULL),
(18,10,'_stock_status','instock'),
(19,10,'_wc_average_rating','0'),
(20,10,'_wc_review_count','0'),
(21,10,'_product_version','9.5.1'),
(22,10,'_price','29.9'),
(23,11,'_sku','HD-002'),
(24,11,'_regular_price','69'),
(25,11,'total_sales','0'),
(26,11,'_tax_status','taxable'),
(27,11,'_tax_class',''),
(28,11,'_manage_stock','no'),
(29,11,'_backorders','no'),
(30,11,'_sold_individually','no'),
(31,11,'_virtual','no'),
(32,11,'_downloadable','no'),
(33,11,'_download_limit','-1'),
(34,11,'_download_expiry','-1'),
(35,11,'_stock',NULL),
(36,11,'_stock_status','instock'),
(37,11,'_wc_average_rating','0'),
(38,11,'_wc_review_count','0'),
(39,11,'_product_version','9.5.1'),
(40,11,'_price','69'),
(41,12,'_sku','CAP-003'),
(42,12,'_regular_price','24.5'),
(43,12,'total_sales','0'),
(44,12,'_tax_status','taxable'),
(45,12,'_tax_class',''),
(46,12,'_manage_stock','no'),
(47,12,'_backorders','no'),
(48,12,'_sold_individually','no'),
(49,12,'_virtual','no'),
(50,12,'_downloadable','no'),
(51,12,'_download_limit','-1'),
(52,12,'_download_expiry','-1'),
(53,12,'_stock',NULL),
(54,12,'_stock_status','instock'),
(55,12,'_wc_average_rating','0'),
(56,12,'_wc_review_count','0'),
(57,12,'_product_version','9.5.1'),
(58,12,'_price','24.5'),
(59,13,'_sku','BAG-004'),
(60,13,'_regular_price','49.9'),
(61,13,'total_sales','0'),
(62,13,'_tax_status','taxable'),
(63,13,'_tax_class',''),
(64,13,'_manage_stock','no'),
(65,13,'_backorders','no'),
(66,13,'_sold_individually','no'),
(67,13,'_virtual','no'),
(68,13,'_downloadable','no'),
(69,13,'_download_limit','-1'),
(70,13,'_download_expiry','-1'),
(71,13,'_stock',NULL),
(72,13,'_stock_status','instock'),
(73,13,'_wc_average_rating','0'),
(74,13,'_wc_review_count','0'),
(75,13,'_product_version','9.5.1'),
(76,13,'_price','49.9'),
(77,14,'_sku','MUG-005'),
(78,14,'_regular_price','14.5'),
(79,14,'total_sales','0'),
(80,14,'_tax_status','taxable'),
(81,14,'_tax_class',''),
(82,14,'_manage_stock','no'),
(83,14,'_backorders','no'),
(84,14,'_sold_individually','no'),
(85,14,'_virtual','no'),
(86,14,'_downloadable','no'),
(87,14,'_download_limit','-1'),
(88,14,'_download_expiry','-1'),
(89,14,'_stock',NULL),
(90,14,'_stock_status','instock'),
(91,14,'_wc_average_rating','0'),
(92,14,'_wc_review_count','0'),
(93,14,'_product_version','9.5.1'),
(94,14,'_price','14.5'),
(95,15,'_sku','BTL-006'),
(96,15,'_regular_price','27.9'),
(97,15,'total_sales','0'),
(98,15,'_tax_status','taxable'),
(99,15,'_tax_class',''),
(100,15,'_manage_stock','no'),
(101,15,'_backorders','no'),
(102,15,'_sold_individually','no'),
(103,15,'_virtual','no'),
(104,15,'_downloadable','no'),
(105,15,'_download_limit','-1'),
(106,15,'_download_expiry','-1'),
(107,15,'_stock',NULL),
(108,15,'_stock_status','instock'),
(109,15,'_wc_average_rating','0'),
(110,15,'_wc_review_count','0'),
(111,15,'_product_version','9.5.1'),
(112,15,'_price','27.9'),
(113,16,'_sku','CDL-007'),
(114,16,'_regular_price','18'),
(115,16,'total_sales','0'),
(116,16,'_tax_status','taxable'),
(117,16,'_tax_class',''),
(118,16,'_manage_stock','no'),
(119,16,'_backorders','no'),
(120,16,'_sold_individually','no'),
(121,16,'_virtual','no'),
(122,16,'_downloadable','no'),
(123,16,'_download_limit','-1'),
(124,16,'_download_expiry','-1'),
(125,16,'_stock',NULL),
(126,16,'_stock_status','instock'),
(127,16,'_wc_average_rating','0'),
(128,16,'_wc_review_count','0'),
(129,16,'_product_version','9.5.1'),
(130,16,'_price','18'),
(131,17,'_sku','EAR-008'),
(132,17,'_regular_price','89'),
(133,17,'total_sales','0'),
(134,17,'_tax_status','taxable'),
(135,17,'_tax_class',''),
(136,17,'_manage_stock','no'),
(137,17,'_backorders','no'),
(138,17,'_sold_individually','no'),
(139,17,'_virtual','no'),
(140,17,'_downloadable','no'),
(141,17,'_download_limit','-1'),
(142,17,'_download_expiry','-1'),
(143,17,'_stock',NULL),
(144,17,'_stock_status','instock'),
(145,17,'_wc_average_rating','0'),
(146,17,'_wc_review_count','0'),
(147,17,'_product_version','9.5.1'),
(148,17,'_price','89'),
(149,18,'_sku','CHG-009'),
(150,18,'_regular_price','34.9'),
(151,18,'total_sales','0'),
(152,18,'_tax_status','taxable'),
(153,18,'_tax_class',''),
(154,18,'_manage_stock','no'),
(155,18,'_backorders','no'),
(156,18,'_sold_individually','no'),
(157,18,'_virtual','no'),
(158,18,'_downloadable','no'),
(159,18,'_download_limit','-1'),
(160,18,'_download_expiry','-1'),
(161,18,'_stock',NULL),
(162,18,'_stock_status','instock'),
(163,18,'_wc_average_rating','0'),
(164,18,'_wc_review_count','0'),
(165,18,'_product_version','9.5.1'),
(166,18,'_price','34.9'),
(167,19,'_sku','PWR-010'),
(168,19,'_regular_price','39.9'),
(169,19,'total_sales','0'),
(170,19,'_tax_status','taxable'),
(171,19,'_tax_class',''),
(172,19,'_manage_stock','no'),
(173,19,'_backorders','no'),
(174,19,'_sold_individually','no'),
(175,19,'_virtual','no'),
(176,19,'_downloadable','no'),
(177,19,'_download_limit','-1'),
(178,19,'_download_expiry','-1'),
(179,19,'_stock',NULL),
(180,19,'_stock_status','instock'),
(181,19,'_wc_average_rating','0'),
(182,19,'_wc_review_count','0'),
(183,19,'_product_version','9.5.1'),
(184,19,'_price','39.9'),
(185,20,'_wp_attached_file','2026/06/img_TS-001.jpg'),
(186,20,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:22:\"2026/06/img_TS-001.jpg\";s:8:\"filesize\";i:104879;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:22:\"img_TS-001-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23983;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:22:\"img_TS-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7844;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:22:\"img_TS-001-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:107892;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:22:\"img_TS-001-575x575.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:575;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:68646;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:22:\"img_TS-001-380x380.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:380;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:34990;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:22:\"img_TS-001-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:41483;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:22:\"img_TS-001-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4255;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(187,10,'_thumbnail_id','20'),
(188,21,'_wp_attached_file','2026/06/img_HD-002.jpg'),
(189,21,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:22:\"2026/06/img_HD-002.jpg\";s:8:\"filesize\";i:146670;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:22:\"img_HD-002-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23817;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:22:\"img_HD-002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7232;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:22:\"img_HD-002-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:137649;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:22:\"img_HD-002-575x575.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:575;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:80820;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:22:\"img_HD-002-380x380.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:380;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:37054;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:22:\"img_HD-002-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:45027;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:22:\"img_HD-002-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4017;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(190,11,'_thumbnail_id','21'),
(191,22,'_wp_attached_file','2026/06/img_CAP-003.jpg'),
(192,22,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:23:\"2026/06/img_CAP-003.jpg\";s:8:\"filesize\";i:56467;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"img_CAP-003-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16972;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"img_CAP-003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6366;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:23:\"img_CAP-003-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:62454;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:23:\"img_CAP-003-575x575.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:575;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:41752;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:23:\"img_CAP-003-380x380.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:380;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23569;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:23:\"img_CAP-003-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:27276;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:23:\"img_CAP-003-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3737;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(193,12,'_thumbnail_id','22'),
(194,23,'_wp_attached_file','2026/06/img_BAG-004.jpg'),
(195,23,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:23:\"2026/06/img_BAG-004.jpg\";s:8:\"filesize\";i:96142;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"img_BAG-004-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23772;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"img_BAG-004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7891;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:23:\"img_BAG-004-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:99944;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:23:\"img_BAG-004-575x575.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:575;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:65280;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:23:\"img_BAG-004-380x380.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:380;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:34620;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:23:\"img_BAG-004-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:40547;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:23:\"img_BAG-004-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4397;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(196,13,'_thumbnail_id','23'),
(197,24,'_wp_attached_file','2026/06/img_MUG-005.jpg'),
(198,24,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:23:\"2026/06/img_MUG-005.jpg\";s:8:\"filesize\";i:125405;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"img_MUG-005-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:24642;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"img_MUG-005-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7183;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:23:\"img_MUG-005-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:125228;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:23:\"img_MUG-005-575x575.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:575;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:77308;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:23:\"img_MUG-005-380x380.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:380;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:37444;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:23:\"img_MUG-005-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:45052;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:23:\"img_MUG-005-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3871;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(199,14,'_thumbnail_id','24'),
(200,25,'_wp_attached_file','2026/06/img_BTL-006.jpg'),
(201,25,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:23:\"2026/06/img_BTL-006.jpg\";s:8:\"filesize\";i:38709;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"img_BTL-006-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:11371;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"img_BTL-006-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4758;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:23:\"img_BTL-006-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:41266;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:23:\"img_BTL-006-575x575.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:575;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:27450;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:23:\"img_BTL-006-380x380.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:380;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15561;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:23:\"img_BTL-006-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:17993;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:23:\"img_BTL-006-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3137;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(202,15,'_thumbnail_id','25'),
(203,26,'_wp_attached_file','2026/06/img_CDL-007.jpg'),
(204,26,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:23:\"2026/06/img_CDL-007.jpg\";s:8:\"filesize\";i:46506;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"img_CDL-007-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:13241;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"img_CDL-007-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4796;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:23:\"img_CDL-007-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:51997;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:23:\"img_CDL-007-575x575.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:575;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:34152;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:23:\"img_CDL-007-380x380.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:380;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18705;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:23:\"img_CDL-007-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:21858;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:23:\"img_CDL-007-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2847;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(205,16,'_thumbnail_id','26'),
(206,27,'_wp_attached_file','2026/06/img_EAR-008.jpg'),
(207,27,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:23:\"2026/06/img_EAR-008.jpg\";s:8:\"filesize\";i:98910;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"img_EAR-008-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23306;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"img_EAR-008-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7532;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:23:\"img_EAR-008-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:104377;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:23:\"img_EAR-008-575x575.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:575;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:66572;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:23:\"img_EAR-008-380x380.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:380;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:34289;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:23:\"img_EAR-008-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:40285;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:23:\"img_EAR-008-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4290;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(208,17,'_thumbnail_id','27'),
(209,28,'_wp_attached_file','2026/06/img_CHG-009.jpg'),
(210,28,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:23:\"2026/06/img_CHG-009.jpg\";s:8:\"filesize\";i:63483;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"img_CHG-009-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:13781;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"img_CHG-009-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4654;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:23:\"img_CHG-009-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:65182;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:23:\"img_CHG-009-575x575.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:575;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:40492;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:23:\"img_CHG-009-380x380.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:380;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20257;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:23:\"img_CHG-009-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:24064;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:23:\"img_CHG-009-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2696;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(211,18,'_thumbnail_id','28'),
(212,29,'_wp_attached_file','2026/06/img_PWR-010.jpg'),
(213,29,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:23:\"2026/06/img_PWR-010.jpg\";s:8:\"filesize\";i:84502;s:5:\"sizes\";a:7:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"img_PWR-010-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23529;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"img_PWR-010-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8386;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:23:\"img_PWR-010-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:92080;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:23:\"img_PWR-010-575x575.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:575;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:61291;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:23:\"img_PWR-010-380x380.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:380;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:33482;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:23:\"img_PWR-010-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:39046;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:23:\"img_PWR-010-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4766;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(214,19,'_thumbnail_id','29'),
(215,34,'_wp_attached_file','2021/07/COCOLO-hero2-1_1.jpg'),
(216,34,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:1067;s:4:\"file\";s:28:\"2021/07/COCOLO-hero2-1_1.jpg\";s:8:\"filesize\";i:29253;s:5:\"sizes\";a:12:{s:6:\"medium\";a:5:{s:4:\"file\";s:28:\"COCOLO-hero2-1_1-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5063;}s:5:\"large\";a:5:{s:4:\"file\";s:29:\"COCOLO-hero2-1_1-1024x569.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:569;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:29305;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:28:\"COCOLO-hero2-1_1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3070;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:28:\"COCOLO-hero2-1_1-768x427.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:427;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19064;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:29:\"COCOLO-hero2-1_1-1536x854.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:51946;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:29:\"COCOLO-hero2-1_1-1140x634.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:634;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:33941;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:28:\"COCOLO-hero2-1_1-920x511.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:511;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:24904;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:28:\"COCOLO-hero2-1_1-575x320.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:320;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12466;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:28:\"COCOLO-hero2-1_1-380x211.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:211;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7029;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:28:\"COCOLO-hero2-1_1-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:13025;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:28:\"COCOLO-hero2-1_1-800x445.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:445;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20081;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:28:\"COCOLO-hero2-1_1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1866;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(217,34,'_imagify_optimization_level','1'),
(218,34,'_imagify_status','success'),
(219,34,'_imagify_data','a:2:{s:5:\"sizes\";a:12:{s:4:\"full\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:83495;s:14:\"optimized_size\";i:29286;s:7:\"percent\";d:64.92;}s:22:\"1536x1536@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:51283;s:14:\"optimized_size\";i:17490;s:7:\"percent\";d:65.9;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:18435;s:14:\"optimized_size\";i:7162;s:7:\"percent\";d:61.15;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:3054;s:14:\"optimized_size\";i:1456;s:7:\"percent\";d:52.32;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28382;s:14:\"optimized_size\";i:10324;s:7:\"percent\";d:63.62;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:5000;s:14:\"optimized_size\";i:2246;s:7:\"percent\";d:55.08;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:83495;s:14:\"optimized_size\";i:24220;s:7:\"percent\";d:70.99;}s:6:\"medium\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:5:\"large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28382;s:14:\"optimized_size\";i:13909;s:7:\"percent\";d:50.99;}s:9:\"thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:12:\"medium_large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:18435;s:14:\"optimized_size\";i:10507;s:7:\"percent\";d:43.01;}s:9:\"1536x1536\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:51283;s:14:\"optimized_size\";i:22098;s:7:\"percent\";d:56.91;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:371244;s:14:\"optimized_size\";i:138698;s:7:\"percent\";d:62.64;}}'),
(220,34,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:222685;s:10:\"size_after\";i:222685;s:4:\"time\";d:0.6600000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:13:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5063;s:10:\"size_after\";i:5063;s:4:\"time\";d:0.06;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:29302;s:10:\"size_after\";i:29302;s:4:\"time\";d:0.07;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3070;s:10:\"size_after\";i:3070;s:4:\"time\";d:0.09;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:19064;s:10:\"size_after\";i:19064;s:4:\"time\";d:0.02;}s:9:\"1536x1536\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:51946;s:10:\"size_after\";i:51946;s:4:\"time\";d:0.07;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:33941;s:10:\"size_after\";i:33941;s:4:\"time\";d:0.04;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:24904;s:10:\"size_after\";i:24904;s:4:\"time\";d:0.14;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:12466;s:10:\"size_after\";i:12466;s:4:\"time\";d:0.01;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:7029;s:10:\"size_after\";i:7029;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:928;s:10:\"size_after\";i:928;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:13025;s:10:\"size_after\";i:13025;s:4:\"time\";d:0.05;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:20081;s:10:\"size_after\";i:20081;s:4:\"time\";d:0.05;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1866;s:10:\"size_after\";i:1866;s:4:\"time\";d:0.04;}}}'),
(221,34,'_imagify_optimization_level','1'),
(222,34,'_imagify_status','success'),
(223,34,'_imagify_data','a:2:{s:5:\"sizes\";a:12:{s:4:\"full\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:83495;s:14:\"optimized_size\";i:29286;s:7:\"percent\";d:64.92;}s:22:\"1536x1536@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:51283;s:14:\"optimized_size\";i:17490;s:7:\"percent\";d:65.9;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:18435;s:14:\"optimized_size\";i:7162;s:7:\"percent\";d:61.15;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:3054;s:14:\"optimized_size\";i:1456;s:7:\"percent\";d:52.32;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28382;s:14:\"optimized_size\";i:10324;s:7:\"percent\";d:63.62;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:5000;s:14:\"optimized_size\";i:2246;s:7:\"percent\";d:55.08;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:83495;s:14:\"optimized_size\";i:24220;s:7:\"percent\";d:70.99;}s:6:\"medium\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:5:\"large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28382;s:14:\"optimized_size\";i:13909;s:7:\"percent\";d:50.99;}s:9:\"thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:12:\"medium_large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:18435;s:14:\"optimized_size\";i:10507;s:7:\"percent\";d:43.01;}s:9:\"1536x1536\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:51283;s:14:\"optimized_size\";i:22098;s:7:\"percent\";d:56.91;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:371244;s:14:\"optimized_size\";i:138698;s:7:\"percent\";d:62.64;}}'),
(224,34,'_imagify_optimization_level','1'),
(225,34,'_imagify_status','success'),
(226,34,'_imagify_data','a:2:{s:5:\"sizes\";a:12:{s:4:\"full\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:83495;s:14:\"optimized_size\";i:29286;s:7:\"percent\";d:64.92;}s:22:\"1536x1536@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:51283;s:14:\"optimized_size\";i:17490;s:7:\"percent\";d:65.9;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:18435;s:14:\"optimized_size\";i:7162;s:7:\"percent\";d:61.15;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:3054;s:14:\"optimized_size\";i:1456;s:7:\"percent\";d:52.32;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28382;s:14:\"optimized_size\";i:10324;s:7:\"percent\";d:63.62;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:5000;s:14:\"optimized_size\";i:2246;s:7:\"percent\";d:55.08;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:83495;s:14:\"optimized_size\";i:24220;s:7:\"percent\";d:70.99;}s:6:\"medium\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:5:\"large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28382;s:14:\"optimized_size\";i:13909;s:7:\"percent\";d:50.99;}s:9:\"thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:12:\"medium_large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:18435;s:14:\"optimized_size\";i:10507;s:7:\"percent\";d:43.01;}s:9:\"1536x1536\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:51283;s:14:\"optimized_size\";i:22098;s:7:\"percent\";d:56.91;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:371244;s:14:\"optimized_size\";i:138698;s:7:\"percent\";d:62.64;}}'),
(227,34,'_imagify_optimization_level','1'),
(228,34,'_imagify_status','success'),
(229,34,'_imagify_data','a:2:{s:5:\"sizes\";a:12:{s:4:\"full\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:83495;s:14:\"optimized_size\";i:29286;s:7:\"percent\";d:64.92;}s:22:\"1536x1536@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:51283;s:14:\"optimized_size\";i:17490;s:7:\"percent\";d:65.9;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:18435;s:14:\"optimized_size\";i:7162;s:7:\"percent\";d:61.15;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:3054;s:14:\"optimized_size\";i:1456;s:7:\"percent\";d:52.32;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28382;s:14:\"optimized_size\";i:10324;s:7:\"percent\";d:63.62;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:5000;s:14:\"optimized_size\";i:2246;s:7:\"percent\";d:55.08;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:83495;s:14:\"optimized_size\";i:24220;s:7:\"percent\";d:70.99;}s:6:\"medium\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:5:\"large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28382;s:14:\"optimized_size\";i:13909;s:7:\"percent\";d:50.99;}s:9:\"thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:12:\"medium_large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:18435;s:14:\"optimized_size\";i:10507;s:7:\"percent\";d:43.01;}s:9:\"1536x1536\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:51283;s:14:\"optimized_size\";i:22098;s:7:\"percent\";d:56.91;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:371244;s:14:\"optimized_size\";i:138698;s:7:\"percent\";d:62.64;}}'),
(230,34,'_wxr_import_user_slug','admin'),
(231,34,'_athemes_sites_imported_post','1'),
(232,35,'_wp_attached_file','2021/07/woocommerce-placeholder.png'),
(233,35,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:35:\"2021/07/woocommerce-placeholder.png\";s:8:\"filesize\";i:26237;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:10413;}s:5:\"large\";a:5:{s:4:\"file\";s:37:\"woocommerce-placeholder-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:88407;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:3769;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:50188;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:37:\"woocommerce-placeholder-1140x1140.png\";s:5:\"width\";i:1140;s:6:\"height\";i:1140;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:105777;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-920x920.png\";s:5:\"width\";i:920;s:6:\"height\";i:920;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:71935;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-575x575.png\";s:5:\"width\";i:575;s:6:\"height\";i:575;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:29606;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-380x380.png\";s:5:\"width\";i:380;s:6:\"height\";i:380;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:15211;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:35:\"woocommerce-placeholder-420x420.png\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:17563;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-800x800.png\";s:5:\"width\";i:800;s:6:\"height\";i:800;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:52824;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1725;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(234,35,'_imagify_optimization_level','1'),
(235,35,'_imagify_status','success'),
(236,35,'_imagify_data','a:2:{s:5:\"sizes\";a:10:{s:4:\"full\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:102644;s:14:\"optimized_size\";i:28416;s:7:\"percent\";d:72.32;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:56344;s:14:\"optimized_size\";i:3518;s:7:\"percent\";d:93.76;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:4203;s:14:\"optimized_size\";i:360;s:7:\"percent\";d:91.43;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:92541;s:14:\"optimized_size\";i:5248;s:7:\"percent\";d:94.33;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:11769;s:14:\"optimized_size\";i:902;s:7:\"percent\";d:92.34;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:102644;s:14:\"optimized_size\";i:7288;s:7:\"percent\";d:92.9;}s:6:\"medium\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:11769;s:14:\"optimized_size\";i:2728;s:7:\"percent\";d:76.82;}s:5:\"large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:92541;s:14:\"optimized_size\";i:20313;s:7:\"percent\";d:78.05;}s:9:\"thumbnail\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:4203;s:14:\"optimized_size\";i:1064;s:7:\"percent\";d:74.68;}s:12:\"medium_large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:56344;s:14:\"optimized_size\";i:12883;s:7:\"percent\";d:77.14;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:535002;s:14:\"optimized_size\";i:82720;s:7:\"percent\";d:84.54;}}'),
(237,35,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:16.12774824027327;s:5:\"bytes\";i:79414;s:11:\"size_before\";i:492406;s:10:\"size_after\";i:412992;s:4:\"time\";d:5.449999999999999;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:12:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.86;s:5:\"bytes\";i:443;s:11:\"size_before\";i:11485;s:10:\"size_after\";i:11042;s:4:\"time\";d:0.05;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:18.41;s:5:\"bytes\";i:17662;s:11:\"size_before\";i:95927;s:10:\"size_after\";i:78265;s:4:\"time\";d:1.09;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.63;s:5:\"bytes\";i:407;s:11:\"size_before\";i:4227;s:10:\"size_after\";i:3820;s:4:\"time\";d:0.11;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.87;s:5:\"bytes\";i:7125;s:11:\"size_before\";i:55366;s:10:\"size_after\";i:48241;s:4:\"time\";d:0.42;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:22.06;s:5:\"bytes\";i:25758;s:11:\"size_before\";i:116770;s:10:\"size_after\";i:91012;s:4:\"time\";d:1.74;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:17.52;s:5:\"bytes\";i:13812;s:11:\"size_before\";i:78820;s:10:\"size_after\";i:65008;s:4:\"time\";d:0.38;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.15;s:5:\"bytes\";i:3329;s:11:\"size_before\";i:32791;s:10:\"size_after\";i:29462;s:4:\"time\";d:0.68;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.94;s:5:\"bytes\";i:1333;s:11:\"size_before\";i:16792;s:10:\"size_after\";i:15459;s:4:\"time\";d:0.39;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.62;s:5:\"bytes\";i:5;s:11:\"size_before\";i:802;s:10:\"size_after\";i:797;s:4:\"time\";d:0.03;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.47;s:5:\"bytes\";i:1648;s:11:\"size_before\";i:19457;s:10:\"size_after\";i:17809;s:4:\"time\";d:0.15;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:13.53;s:5:\"bytes\";i:7882;s:11:\"size_before\";i:58244;s:10:\"size_after\";i:50362;s:4:\"time\";d:0.39;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.58;s:5:\"bytes\";i:10;s:11:\"size_before\";i:1725;s:10:\"size_after\";i:1715;s:4:\"time\";d:0.02;}}}'),
(238,35,'_imagify_optimization_level','1'),
(239,35,'_imagify_status','success'),
(240,35,'_imagify_data','a:2:{s:5:\"sizes\";a:10:{s:4:\"full\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:102644;s:14:\"optimized_size\";i:28416;s:7:\"percent\";d:72.32;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:56344;s:14:\"optimized_size\";i:3518;s:7:\"percent\";d:93.76;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:4203;s:14:\"optimized_size\";i:360;s:7:\"percent\";d:91.43;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:92541;s:14:\"optimized_size\";i:5248;s:7:\"percent\";d:94.33;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:11769;s:14:\"optimized_size\";i:902;s:7:\"percent\";d:92.34;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:102644;s:14:\"optimized_size\";i:7288;s:7:\"percent\";d:92.9;}s:6:\"medium\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:11769;s:14:\"optimized_size\";i:2728;s:7:\"percent\";d:76.82;}s:5:\"large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:92541;s:14:\"optimized_size\";i:20313;s:7:\"percent\";d:78.05;}s:9:\"thumbnail\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:4203;s:14:\"optimized_size\";i:1064;s:7:\"percent\";d:74.68;}s:12:\"medium_large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:56344;s:14:\"optimized_size\";i:12883;s:7:\"percent\";d:77.14;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:535002;s:14:\"optimized_size\";i:82720;s:7:\"percent\";d:84.54;}}'),
(241,35,'_imagify_optimization_level','1'),
(242,35,'_imagify_status','success'),
(243,35,'_imagify_data','a:2:{s:5:\"sizes\";a:10:{s:4:\"full\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:102644;s:14:\"optimized_size\";i:28416;s:7:\"percent\";d:72.32;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:56344;s:14:\"optimized_size\";i:3518;s:7:\"percent\";d:93.76;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:4203;s:14:\"optimized_size\";i:360;s:7:\"percent\";d:91.43;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:92541;s:14:\"optimized_size\";i:5248;s:7:\"percent\";d:94.33;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:11769;s:14:\"optimized_size\";i:902;s:7:\"percent\";d:92.34;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:102644;s:14:\"optimized_size\";i:7288;s:7:\"percent\";d:92.9;}s:6:\"medium\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:11769;s:14:\"optimized_size\";i:2728;s:7:\"percent\";d:76.82;}s:5:\"large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:92541;s:14:\"optimized_size\";i:20313;s:7:\"percent\";d:78.05;}s:9:\"thumbnail\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:4203;s:14:\"optimized_size\";i:1064;s:7:\"percent\";d:74.68;}s:12:\"medium_large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:56344;s:14:\"optimized_size\";i:12883;s:7:\"percent\";d:77.14;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:535002;s:14:\"optimized_size\";i:82720;s:7:\"percent\";d:84.54;}}'),
(244,35,'_imagify_optimization_level','1'),
(245,35,'_imagify_status','success'),
(246,35,'_imagify_data','a:2:{s:5:\"sizes\";a:10:{s:4:\"full\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:102644;s:14:\"optimized_size\";i:28416;s:7:\"percent\";d:72.32;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:56344;s:14:\"optimized_size\";i:3518;s:7:\"percent\";d:93.76;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:4203;s:14:\"optimized_size\";i:360;s:7:\"percent\";d:91.43;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:92541;s:14:\"optimized_size\";i:5248;s:7:\"percent\";d:94.33;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:11769;s:14:\"optimized_size\";i:902;s:7:\"percent\";d:92.34;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:102644;s:14:\"optimized_size\";i:7288;s:7:\"percent\";d:92.9;}s:6:\"medium\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:11769;s:14:\"optimized_size\";i:2728;s:7:\"percent\";d:76.82;}s:5:\"large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:92541;s:14:\"optimized_size\";i:20313;s:7:\"percent\";d:78.05;}s:9:\"thumbnail\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:4203;s:14:\"optimized_size\";i:1064;s:7:\"percent\";d:74.68;}s:12:\"medium_large\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:56344;s:14:\"optimized_size\";i:12883;s:7:\"percent\";d:77.14;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:535002;s:14:\"optimized_size\";i:82720;s:7:\"percent\";d:84.54;}}'),
(247,35,'_wxr_import_user_slug','admin'),
(248,35,'_athemes_sites_imported_post','1'),
(249,49,'_wp_attached_file','2021/07/Mask-Group-1-1.jpg'),
(250,49,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1440;s:6:\"height\";i:580;s:4:\"file\";s:26:\"2021/07/Mask-Group-1-1.jpg\";s:8:\"filesize\";i:9449;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:26:\"Mask-Group-1-1-300x121.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:121;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3128;}s:5:\"large\";a:5:{s:4:\"file\";s:27:\"Mask-Group-1-1-1024x412.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:412;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15752;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:26:\"Mask-Group-1-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2246;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:26:\"Mask-Group-1-1-768x309.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:309;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10600;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:27:\"Mask-Group-1-1-1140x459.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:459;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18367;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:26:\"Mask-Group-1-1-920x371.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:371;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:13535;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:26:\"Mask-Group-1-1-575x232.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:232;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7208;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:26:\"Mask-Group-1-1-380x153.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:153;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4218;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:26:\"Mask-Group-1-1-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8516;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:26:\"Mask-Group-1-1-800x322.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:322;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:11098;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:26:\"Mask-Group-1-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1450;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(251,49,'_imagify_optimization_level','1'),
(252,49,'_imagify_status','success'),
(253,49,'_imagify_data','a:2:{s:5:\"sizes\";a:22:{s:4:\"full\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28676;s:14:\"optimized_size\";i:9449;s:7:\"percent\";d:67.05;}s:27:\"shop_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:1396;s:14:\"optimized_size\";i:586;s:7:\"percent\";d:58.02;}s:24:\"shop_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10704;s:14:\"optimized_size\";i:3590;s:7:\"percent\";d:66.46;}s:25:\"shop_catalog@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6300;s:14:\"optimized_size\";i:1950;s:7:\"percent\";d:69.05;}s:42:\"woocommerce_gallery_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:1396;s:14:\"optimized_size\";i:586;s:7:\"percent\";d:58.02;}s:31:\"woocommerce_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10704;s:14:\"optimized_size\";i:3590;s:7:\"percent\";d:66.46;}s:34:\"woocommerce_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6300;s:14:\"optimized_size\";i:1950;s:7:\"percent\";d:69.05;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10129;s:14:\"optimized_size\";i:3426;s:7:\"percent\";d:66.18;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:2170;s:14:\"optimized_size\";i:828;s:7:\"percent\";d:61.84;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:15253;s:14:\"optimized_size\";i:4932;s:7:\"percent\";d:67.67;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:3011;s:14:\"optimized_size\";i:1184;s:7:\"percent\";d:60.68;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28676;s:14:\"optimized_size\";i:7310;s:7:\"percent\";d:74.51;}s:6:\"medium\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:5:\"large\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:9:\"thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:12:\"medium_large\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:21:\"woocommerce_thumbnail\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6300;s:14:\"optimized_size\";i:3667;s:7:\"percent\";d:41.79;}s:18:\"woocommerce_single\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:29:\"woocommerce_gallery_thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:12:\"shop_catalog\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:11:\"shop_single\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:14:\"shop_thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:131015;s:14:\"optimized_size\";i:43048;s:7:\"percent\";d:67.14;}}'),
(254,49,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:96925;s:10:\"size_after\";i:96925;s:4:\"time\";d:0.32;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:12:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3128;s:10:\"size_after\";i:3128;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:15752;s:10:\"size_after\";i:15752;s:4:\"time\";d:0.03;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2246;s:10:\"size_after\";i:2246;s:4:\"time\";i:0;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:10601;s:10:\"size_after\";i:10601;s:4:\"time\";d:0.01;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:18367;s:10:\"size_after\";i:18367;s:4:\"time\";d:0.05;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:13535;s:10:\"size_after\";i:13535;s:4:\"time\";d:0.04;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:7208;s:10:\"size_after\";i:7208;s:4:\"time\";d:0.03;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4218;s:10:\"size_after\";i:4218;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:806;s:10:\"size_after\";i:806;s:4:\"time\";i:0;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:8516;s:10:\"size_after\";i:8516;s:4:\"time\";d:0.07;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:11098;s:10:\"size_after\";i:11098;s:4:\"time\";d:0.03;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1450;s:10:\"size_after\";i:1450;s:4:\"time\";d:0.04;}}}'),
(255,49,'_imagify_optimization_level','1'),
(256,49,'_imagify_status','success'),
(257,49,'_imagify_data','a:2:{s:5:\"sizes\";a:22:{s:4:\"full\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28676;s:14:\"optimized_size\";i:9449;s:7:\"percent\";d:67.05;}s:27:\"shop_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:1396;s:14:\"optimized_size\";i:586;s:7:\"percent\";d:58.02;}s:24:\"shop_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10704;s:14:\"optimized_size\";i:3590;s:7:\"percent\";d:66.46;}s:25:\"shop_catalog@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6300;s:14:\"optimized_size\";i:1950;s:7:\"percent\";d:69.05;}s:42:\"woocommerce_gallery_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:1396;s:14:\"optimized_size\";i:586;s:7:\"percent\";d:58.02;}s:31:\"woocommerce_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10704;s:14:\"optimized_size\";i:3590;s:7:\"percent\";d:66.46;}s:34:\"woocommerce_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6300;s:14:\"optimized_size\";i:1950;s:7:\"percent\";d:69.05;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10129;s:14:\"optimized_size\";i:3426;s:7:\"percent\";d:66.18;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:2170;s:14:\"optimized_size\";i:828;s:7:\"percent\";d:61.84;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:15253;s:14:\"optimized_size\";i:4932;s:7:\"percent\";d:67.67;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:3011;s:14:\"optimized_size\";i:1184;s:7:\"percent\";d:60.68;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28676;s:14:\"optimized_size\";i:7310;s:7:\"percent\";d:74.51;}s:6:\"medium\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:5:\"large\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:9:\"thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:12:\"medium_large\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:21:\"woocommerce_thumbnail\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6300;s:14:\"optimized_size\";i:3667;s:7:\"percent\";d:41.79;}s:18:\"woocommerce_single\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:29:\"woocommerce_gallery_thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:12:\"shop_catalog\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:11:\"shop_single\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:14:\"shop_thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:131015;s:14:\"optimized_size\";i:43048;s:7:\"percent\";d:67.14;}}'),
(258,49,'_imagify_optimization_level','1'),
(259,49,'_imagify_status','success'),
(260,49,'_imagify_data','a:2:{s:5:\"sizes\";a:22:{s:4:\"full\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28676;s:14:\"optimized_size\";i:9449;s:7:\"percent\";d:67.05;}s:27:\"shop_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:1396;s:14:\"optimized_size\";i:586;s:7:\"percent\";d:58.02;}s:24:\"shop_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10704;s:14:\"optimized_size\";i:3590;s:7:\"percent\";d:66.46;}s:25:\"shop_catalog@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6300;s:14:\"optimized_size\";i:1950;s:7:\"percent\";d:69.05;}s:42:\"woocommerce_gallery_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:1396;s:14:\"optimized_size\";i:586;s:7:\"percent\";d:58.02;}s:31:\"woocommerce_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10704;s:14:\"optimized_size\";i:3590;s:7:\"percent\";d:66.46;}s:34:\"woocommerce_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6300;s:14:\"optimized_size\";i:1950;s:7:\"percent\";d:69.05;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10129;s:14:\"optimized_size\";i:3426;s:7:\"percent\";d:66.18;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:2170;s:14:\"optimized_size\";i:828;s:7:\"percent\";d:61.84;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:15253;s:14:\"optimized_size\";i:4932;s:7:\"percent\";d:67.67;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:3011;s:14:\"optimized_size\";i:1184;s:7:\"percent\";d:60.68;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28676;s:14:\"optimized_size\";i:7310;s:7:\"percent\";d:74.51;}s:6:\"medium\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:5:\"large\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:9:\"thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:12:\"medium_large\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:21:\"woocommerce_thumbnail\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6300;s:14:\"optimized_size\";i:3667;s:7:\"percent\";d:41.79;}s:18:\"woocommerce_single\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:29:\"woocommerce_gallery_thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:12:\"shop_catalog\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:11:\"shop_single\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:14:\"shop_thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:131015;s:14:\"optimized_size\";i:43048;s:7:\"percent\";d:67.14;}}'),
(261,49,'_imagify_optimization_level','1'),
(262,49,'_imagify_status','success'),
(263,49,'_imagify_data','a:2:{s:5:\"sizes\";a:22:{s:4:\"full\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28676;s:14:\"optimized_size\";i:9449;s:7:\"percent\";d:67.05;}s:27:\"shop_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:1396;s:14:\"optimized_size\";i:586;s:7:\"percent\";d:58.02;}s:24:\"shop_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10704;s:14:\"optimized_size\";i:3590;s:7:\"percent\";d:66.46;}s:25:\"shop_catalog@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6300;s:14:\"optimized_size\";i:1950;s:7:\"percent\";d:69.05;}s:42:\"woocommerce_gallery_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:1396;s:14:\"optimized_size\";i:586;s:7:\"percent\";d:58.02;}s:31:\"woocommerce_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10704;s:14:\"optimized_size\";i:3590;s:7:\"percent\";d:66.46;}s:34:\"woocommerce_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6300;s:14:\"optimized_size\";i:1950;s:7:\"percent\";d:69.05;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10129;s:14:\"optimized_size\";i:3426;s:7:\"percent\";d:66.18;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:2170;s:14:\"optimized_size\";i:828;s:7:\"percent\";d:61.84;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:15253;s:14:\"optimized_size\";i:4932;s:7:\"percent\";d:67.67;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:3011;s:14:\"optimized_size\";i:1184;s:7:\"percent\";d:60.68;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:28676;s:14:\"optimized_size\";i:7310;s:7:\"percent\";d:74.51;}s:6:\"medium\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:5:\"large\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:9:\"thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:12:\"medium_large\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:21:\"woocommerce_thumbnail\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6300;s:14:\"optimized_size\";i:3667;s:7:\"percent\";d:41.79;}s:18:\"woocommerce_single\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:29:\"woocommerce_gallery_thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:12:\"shop_catalog\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:11:\"shop_single\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:14:\"shop_thumbnail\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:131015;s:14:\"optimized_size\";i:43048;s:7:\"percent\";d:67.14;}}'),
(264,49,'_wxr_import_user_slug','admin'),
(265,49,'_athemes_sites_imported_post','1'),
(266,88,'_wp_attached_file','2021/07/Hero.jpg'),
(267,88,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:1067;s:4:\"file\";s:16:\"2021/07/Hero.jpg\";s:8:\"filesize\";i:75266;s:5:\"sizes\";a:12:{s:6:\"medium\";a:5:{s:4:\"file\";s:16:\"Hero-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4156;}s:5:\"large\";a:5:{s:4:\"file\";s:17:\"Hero-1024x569.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:569;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:30097;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:16:\"Hero-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2121;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:16:\"Hero-768x427.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:427;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18330;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:17:\"Hero-1536x854.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:57793;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:17:\"Hero-1140x634.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:634;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:36236;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:16:\"Hero-920x511.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:511;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:24841;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:16:\"Hero-575x320.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:320;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:11501;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:16:\"Hero-380x211.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:211;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5928;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:16:\"Hero-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9863;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:16:\"Hero-800x445.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:445;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19940;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:16:\"Hero-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1397;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(268,88,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.5998584425998184;s:5:\"bytes\";i:8036;s:11:\"size_before\";i:223231;s:10:\"size_after\";i:215195;s:4:\"time\";d:0.5900000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:13:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4157;s:10:\"size_after\";i:4157;s:4:\"time\";d:0.04;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.96;s:5:\"bytes\";i:1194;s:11:\"size_before\";i:30156;s:10:\"size_after\";i:28962;s:4:\"time\";d:0.01;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2143;s:10:\"size_after\";i:2143;s:4:\"time\";d:0.03;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.18;s:5:\"bytes\";i:583;s:11:\"size_before\";i:18350;s:10:\"size_after\";i:17767;s:4:\"time\";d:0.08;}s:9:\"1536x1536\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.98;s:5:\"bytes\";i:2879;s:11:\"size_before\";i:57852;s:10:\"size_after\";i:54973;s:4:\"time\";d:0.27;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.45;s:5:\"bytes\";i:1612;s:11:\"size_before\";i:36242;s:10:\"size_after\";i:34630;s:4:\"time\";d:0.07;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.47;s:5:\"bytes\";i:862;s:11:\"size_before\";i:24850;s:10:\"size_after\";i:23988;s:4:\"time\";d:0.02;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.18;s:5:\"bytes\";i:251;s:11:\"size_before\";i:11513;s:10:\"size_after\";i:11262;s:4:\"time\";d:0.01;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5915;s:10:\"size_after\";i:5915;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:753;s:10:\"size_after\";i:753;s:4:\"time\";i:0;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:9917;s:10:\"size_after\";i:9917;s:4:\"time\";d:0.02;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.28;s:5:\"bytes\";i:655;s:11:\"size_before\";i:19977;s:10:\"size_after\";i:19322;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1406;s:10:\"size_after\";i:1406;s:4:\"time\";d:0.01;}}}'),
(269,88,'_wxr_import_user_slug','admin'),
(270,88,'_athemes_sites_imported_post','1'),
(271,130,'_wp_attached_file','2021/07/pexels-karolina-grabowska-4397817.jpg'),
(272,130,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:45:\"2021/07/pexels-karolina-grabowska-4397817.jpg\";s:8:\"filesize\";i:50854;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4397817-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4609;}s:5:\"large\";a:5:{s:4:\"file\";s:46:\"pexels-karolina-grabowska-4397817-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:33545;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4397817-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2937;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4397817-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20320;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:46:\"pexels-karolina-grabowska-4397817-1140x760.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:760;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:40190;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4397817-920x613.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:613;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:27998;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4397817-575x383.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:383;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12222;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4397817-380x253.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:253;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6474;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4397817-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12644;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4397817-800x533.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:533;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:21854;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4397817-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1726;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(273,130,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:15.118402086622279;s:5:\"bytes\";i:33039;s:11:\"size_before\";i:218535;s:10:\"size_after\";i:185496;s:4:\"time\";d:0.53;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:12:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:36.54;s:5:\"bytes\";i:2840;s:11:\"size_before\";i:7772;s:10:\"size_after\";i:4932;s:4:\"time\";d:0.03;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.3;s:5:\"bytes\";i:2596;s:11:\"size_before\";i:35538;s:10:\"size_after\";i:32942;s:4:\"time\";d:0.04;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:47.11;s:5:\"bytes\";i:2880;s:11:\"size_before\";i:6113;s:10:\"size_after\";i:3233;s:4:\"time\";d:0.03;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.04;s:5:\"bytes\";i:2758;s:11:\"size_before\";i:22912;s:10:\"size_after\";i:20154;s:4:\"time\";d:0.02;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.95;s:5:\"bytes\";i:2492;s:11:\"size_before\";i:41868;s:10:\"size_after\";i:39376;s:4:\"time\";d:0.04;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.94;s:5:\"bytes\";i:2707;s:11:\"size_before\";i:30274;s:10:\"size_after\";i:27567;s:4:\"time\";d:0.02;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:17.89;s:5:\"bytes\";i:2733;s:11:\"size_before\";i:15279;s:10:\"size_after\";i:12546;s:4:\"time\";d:0.01;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:29.32;s:5:\"bytes\";i:2819;s:11:\"size_before\";i:9615;s:10:\"size_after\";i:6796;s:4:\"time\";d:0.03;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";d:71.62;s:5:\"bytes\";i:2892;s:11:\"size_before\";i:4038;s:10:\"size_after\";i:1146;s:4:\"time\";i:0;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:17.46;s:5:\"bytes\";i:2742;s:11:\"size_before\";i:15704;s:10:\"size_after\";i:12962;s:4:\"time\";d:0.07;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.02;s:5:\"bytes\";i:2703;s:11:\"size_before\";i:24539;s:10:\"size_after\";i:21836;s:4:\"time\";d:0.21;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:58.92;s:5:\"bytes\";i:2877;s:11:\"size_before\";i:4883;s:10:\"size_after\";i:2006;s:4:\"time\";d:0.03;}}}'),
(274,130,'_wxr_import_user_slug','admin'),
(275,130,'_athemes_sites_imported_post','1'),
(276,132,'_wp_attached_file','2021/07/pexels-ray-piedra-2721977.jpg'),
(277,132,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:37:\"2021/07/pexels-ray-piedra-2721977.jpg\";s:8:\"filesize\";i:102815;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:37:\"pexels-ray-piedra-2721977-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10181;}s:5:\"large\";a:5:{s:4:\"file\";s:38:\"pexels-ray-piedra-2721977-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:69690;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:37:\"pexels-ray-piedra-2721977-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4913;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:37:\"pexels-ray-piedra-2721977-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:43647;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:38:\"pexels-ray-piedra-2721977-1140x760.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:760;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:82636;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:37:\"pexels-ray-piedra-2721977-920x613.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:613;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:58666;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:37:\"pexels-ray-piedra-2721977-575x383.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:383;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:27431;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:37:\"pexels-ray-piedra-2721977-380x253.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:253;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:14560;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:37:\"pexels-ray-piedra-2721977-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:22617;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:37:\"pexels-ray-piedra-2721977-800x533.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:533;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:46729;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:37:\"pexels-ray-piedra-2721977-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2848;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(278,132,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:0.7151268656329275;s:5:\"bytes\";i:2757;s:11:\"size_before\";i:385526;s:10:\"size_after\";i:382769;s:4:\"time\";d:0.4;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:12:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:10216;s:10:\"size_after\";i:10216;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.85;s:5:\"bytes\";i:591;s:11:\"size_before\";i:69654;s:10:\"size_after\";i:69063;s:4:\"time\";d:0.04;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4938;s:10:\"size_after\";i:4938;s:4:\"time\";i:0;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.77;s:5:\"bytes\";i:335;s:11:\"size_before\";i:43722;s:10:\"size_after\";i:43387;s:4:\"time\";d:0.09;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.03;s:5:\"bytes\";i:852;s:11:\"size_before\";i:82509;s:10:\"size_after\";i:81657;s:4:\"time\";d:0.05;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.91;s:5:\"bytes\";i:536;s:11:\"size_before\";i:58635;s:10:\"size_after\";i:58099;s:4:\"time\";d:0.12;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.37;s:5:\"bytes\";i:101;s:11:\"size_before\";i:27590;s:10:\"size_after\";i:27489;s:4:\"time\";d:0.01;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:14639;s:10:\"size_after\";i:14639;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1247;s:10:\"size_after\";i:1247;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.03;s:5:\"bytes\";i:7;s:11:\"size_before\";i:22682;s:10:\"size_after\";i:22675;s:4:\"time\";d:0.03;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.72;s:5:\"bytes\";i:335;s:11:\"size_before\";i:46825;s:10:\"size_after\";i:46490;s:4:\"time\";d:0.01;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2869;s:10:\"size_after\";i:2869;s:4:\"time\";d:0.02;}}}'),
(279,132,'_wxr_import_user_slug','admin'),
(280,132,'_athemes_sites_imported_post','1'),
(281,134,'_wp_attached_file','2021/07/pexels-teona-swift-6912808.jpg'),
(282,134,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:38:\"2021/07/pexels-teona-swift-6912808.jpg\";s:8:\"filesize\";i:70071;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:38:\"pexels-teona-swift-6912808-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7945;}s:5:\"large\";a:5:{s:4:\"file\";s:39:\"pexels-teona-swift-6912808-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:46687;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:38:\"pexels-teona-swift-6912808-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4193;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:38:\"pexels-teona-swift-6912808-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:29291;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:39:\"pexels-teona-swift-6912808-1140x760.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:760;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:55718;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:38:\"pexels-teona-swift-6912808-920x613.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:613;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:39101;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:38:\"pexels-teona-swift-6912808-575x383.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:383;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19146;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:38:\"pexels-teona-swift-6912808-380x253.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:253;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10936;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:38:\"pexels-teona-swift-6912808-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16821;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:38:\"pexels-teona-swift-6912808-800x533.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:533;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:31358;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:38:\"pexels-teona-swift-6912808-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2572;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(283,134,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:11.643635410682068;s:5:\"bytes\";i:34656;s:11:\"size_before\";i:297639;s:10:\"size_after\";i:262983;s:4:\"time\";d:0.43;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:12:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:27.01;s:5:\"bytes\";i:3011;s:11:\"size_before\";i:11148;s:10:\"size_after\";i:8137;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.62;s:5:\"bytes\";i:2718;s:11:\"size_before\";i:48340;s:10:\"size_after\";i:45622;s:4:\"time\";d:0.09;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:40.49;s:5:\"bytes\";i:2980;s:11:\"size_before\";i:7360;s:10:\"size_after\";i:4380;s:4:\"time\";i:0;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.75;s:5:\"bytes\";i:2810;s:11:\"size_before\";i:32132;s:10:\"size_after\";i:29322;s:4:\"time\";d:0.02;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.98;s:5:\"bytes\";i:2824;s:11:\"size_before\";i:56698;s:10:\"size_after\";i:53874;s:4:\"time\";d:0.08;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.81;s:5:\"bytes\";i:2822;s:11:\"size_before\";i:41438;s:10:\"size_after\";i:38616;s:4:\"time\";d:0.02;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.99;s:5:\"bytes\";i:2890;s:11:\"size_before\";i:22255;s:10:\"size_after\";i:19365;s:4:\"time\";d:0.05;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:21.08;s:5:\"bytes\";i:2983;s:11:\"size_before\";i:14154;s:10:\"size_after\";i:11171;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";d:67.31;s:5:\"bytes\";i:2932;s:11:\"size_before\";i:4356;s:10:\"size_after\";i:1424;s:4:\"time\";d:0.04;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:14.88;s:5:\"bytes\";i:2969;s:11:\"size_before\";i:19947;s:10:\"size_after\";i:16978;s:4:\"time\";d:0.02;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.07;s:5:\"bytes\";i:2749;s:11:\"size_before\";i:34065;s:10:\"size_after\";i:31316;s:4:\"time\";d:0.04;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:51.65;s:5:\"bytes\";i:2968;s:11:\"size_before\";i:5746;s:10:\"size_after\";i:2778;s:4:\"time\";d:0.05;}}}'),
(284,134,'_wxr_import_user_slug','admin'),
(285,134,'_athemes_sites_imported_post','1'),
(286,136,'_wp_attached_file','2021/07/pexels-karolina-grabowska-5877662.jpg'),
(287,136,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:45:\"2021/07/pexels-karolina-grabowska-5877662.jpg\";s:8:\"filesize\";i:32819;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-5877662-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3956;}s:5:\"large\";a:5:{s:4:\"file\";s:46:\"pexels-karolina-grabowska-5877662-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23959;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-5877662-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2307;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-5877662-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15341;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:46:\"pexels-karolina-grabowska-5877662-1140x760.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:760;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:28347;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-5877662-920x613.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:613;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20352;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-5877662-575x383.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:383;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9947;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-5877662-380x253.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:253;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5494;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-5877662-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9429;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-5877662-800x533.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:533;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16339;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-5877662-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1410;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(288,136,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:139321;s:10:\"size_after\";i:139321;s:4:\"time\";d:0.3400000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:12:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3974;s:10:\"size_after\";i:3974;s:4:\"time\";d:0.03;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:24210;s:10:\"size_after\";i:24210;s:4:\"time\";d:0.03;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2313;s:10:\"size_after\";i:2313;s:4:\"time\";d:0.03;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:15601;s:10:\"size_after\";i:15601;s:4:\"time\";d:0.05;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:28812;s:10:\"size_after\";i:28812;s:4:\"time\";d:0.1;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:20632;s:10:\"size_after\";i:20632;s:4:\"time\";d:0.02;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:10030;s:10:\"size_after\";i:10030;s:4:\"time\";d:0.03;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5575;s:10:\"size_after\";i:5575;s:4:\"time\";d:0.02;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:703;s:10:\"size_after\";i:703;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:9470;s:10:\"size_after\";i:9470;s:4:\"time\";d:0.01;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:16589;s:10:\"size_after\";i:16589;s:4:\"time\";d:0.01;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1412;s:10:\"size_after\";i:1412;s:4:\"time\";i:0;}}}'),
(289,136,'_wxr_import_user_slug','admin'),
(290,136,'_athemes_sites_imported_post','1'),
(291,138,'_wp_attached_file','2021/07/pexels-madison-inouye-1405762.jpg'),
(292,138,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:41:\"2021/07/pexels-madison-inouye-1405762.jpg\";s:8:\"filesize\";i:125271;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:41:\"pexels-madison-inouye-1405762-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:11396;}s:5:\"large\";a:5:{s:4:\"file\";s:42:\"pexels-madison-inouye-1405762-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:85519;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:41:\"pexels-madison-inouye-1405762-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4913;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:41:\"pexels-madison-inouye-1405762-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:53205;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:42:\"pexels-madison-inouye-1405762-1140x760.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:760;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:102005;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:41:\"pexels-madison-inouye-1405762-920x613.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:613;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:72114;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:41:\"pexels-madison-inouye-1405762-575x383.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:383;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:32926;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:41:\"pexels-madison-inouye-1405762-380x253.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:253;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16735;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:41:\"pexels-madison-inouye-1405762-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:26020;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:41:\"pexels-madison-inouye-1405762-800x533.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:533;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:56912;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:41:\"pexels-madison-inouye-1405762-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2692;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(293,138,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:1.2742165600085649;s:5:\"bytes\";i:5832;s:11:\"size_before\";i:457693;s:10:\"size_after\";i:451861;s:4:\"time\";d:0.53;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:12:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.15;s:5:\"bytes\";i:131;s:11:\"size_before\";i:11440;s:10:\"size_after\";i:11309;s:4:\"time\";d:0.09;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.22;s:5:\"bytes\";i:1014;s:11:\"size_before\";i:83352;s:10:\"size_after\";i:82338;s:4:\"time\";d:0.04;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4921;s:10:\"size_after\";i:4921;s:4:\"time\";d:0.04;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.35;s:5:\"bytes\";i:708;s:11:\"size_before\";i:52479;s:10:\"size_after\";i:51771;s:4:\"time\";d:0.08;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.18;s:5:\"bytes\";i:1165;s:11:\"size_before\";i:99064;s:10:\"size_after\";i:97899;s:4:\"time\";d:0.08;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.48;s:5:\"bytes\";i:1048;s:11:\"size_before\";i:70672;s:10:\"size_after\";i:69624;s:4:\"time\";d:0.09;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.5;s:5:\"bytes\";i:494;s:11:\"size_before\";i:32886;s:10:\"size_after\";i:32392;s:4:\"time\";d:0.02;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.86;s:5:\"bytes\";i:144;s:11:\"size_before\";i:16773;s:10:\"size_after\";i:16629;s:4:\"time\";d:0.05;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1068;s:10:\"size_after\";i:1068;s:4:\"time\";i:0;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.32;s:5:\"bytes\";i:342;s:11:\"size_before\";i:25951;s:10:\"size_after\";i:25609;s:4:\"time\";d:0.01;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.39;s:5:\"bytes\";i:786;s:11:\"size_before\";i:56387;s:10:\"size_after\";i:55601;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2700;s:10:\"size_after\";i:2700;s:4:\"time\";d:0.01;}}}'),
(294,138,'_wxr_import_user_slug','admin'),
(295,138,'_athemes_sites_imported_post','1'),
(296,141,'_wp_attached_file','2021/07/pexels-karolina-grabowska-4239013.jpg'),
(297,141,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:45:\"2021/07/pexels-karolina-grabowska-4239013.jpg\";s:8:\"filesize\";i:96470;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4239013-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9340;}s:5:\"large\";a:5:{s:4:\"file\";s:46:\"pexels-karolina-grabowska-4239013-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:63599;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4239013-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4149;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4239013-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:40165;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:46:\"pexels-karolina-grabowska-4239013-1140x760.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:760;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:76296;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4239013-920x613.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:613;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:53739;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4239013-575x383.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:383;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:25162;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4239013-380x253.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:253;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:13377;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4239013-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19163;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4239013-800x533.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:533;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:42861;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4239013-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2424;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(298,141,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:0.2281883777570391;s:5:\"bytes\";i:802;s:11:\"size_before\";i:351464;s:10:\"size_after\";i:350662;s:4:\"time\";d:0.43000000000000005;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:12:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:9391;s:10:\"size_after\";i:9391;s:4:\"time\";d:0.05;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.29;s:5:\"bytes\";i:184;s:11:\"size_before\";i:63473;s:10:\"size_after\";i:63289;s:4:\"time\";d:0.02;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4174;s:10:\"size_after\";i:4174;s:4:\"time\";d:0.02;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.19;s:5:\"bytes\";i:77;s:11:\"size_before\";i:40337;s:10:\"size_after\";i:40260;s:4:\"time\";d:0.02;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.43;s:5:\"bytes\";i:324;s:11:\"size_before\";i:75969;s:10:\"size_after\";i:75645;s:4:\"time\";d:0.09;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.27;s:5:\"bytes\";i:145;s:11:\"size_before\";i:53624;s:10:\"size_after\";i:53479;s:4:\"time\";d:0.03;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:25331;s:10:\"size_after\";i:25331;s:4:\"time\";d:0.01;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:13480;s:10:\"size_after\";i:13480;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1070;s:10:\"size_after\";i:1070;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:19266;s:10:\"size_after\";i:19266;s:4:\"time\";d:0.02;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.17;s:5:\"bytes\";i:72;s:11:\"size_before\";i:42923;s:10:\"size_after\";i:42851;s:4:\"time\";d:0.15;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2426;s:10:\"size_after\";i:2426;s:4:\"time\";i:0;}}}'),
(299,141,'_wxr_import_user_slug','admin'),
(300,141,'_athemes_sites_imported_post','1'),
(301,143,'_wp_attached_file','2021/07/pexels-anna-urlapova-2968785.jpg'),
(302,143,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:40:\"2021/07/pexels-anna-urlapova-2968785.jpg\";s:8:\"filesize\";i:245160;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:40:\"pexels-anna-urlapova-2968785-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16617;}s:5:\"large\";a:5:{s:4:\"file\";s:41:\"pexels-anna-urlapova-2968785-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:148345;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:40:\"pexels-anna-urlapova-2968785-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7380;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:40:\"pexels-anna-urlapova-2968785-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:86314;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:41:\"pexels-anna-urlapova-2968785-1140x760.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:760;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:183470;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:40:\"pexels-anna-urlapova-2968785-920x613.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:613;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:121445;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:40:\"pexels-anna-urlapova-2968785-575x383.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:383;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:51114;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:40:\"pexels-anna-urlapova-2968785-380x253.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:253;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:25155;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:40:\"pexels-anna-urlapova-2968785-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:42430;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:40:\"pexels-anna-urlapova-2968785-800x533.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:533;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:93464;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:40:\"pexels-anna-urlapova-2968785-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3963;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(303,143,'_imagify_optimization_level','1'),
(304,143,'_imagify_status','already_optimized'),
(305,143,'_imagify_data','a:2:{s:5:\"sizes\";a:12:{s:4:\"full\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:27:\"shop_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:7125;s:14:\"optimized_size\";i:2568;s:7:\"percent\";d:63.96;}s:24:\"shop_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:96071;s:14:\"optimized_size\";i:51640;s:7:\"percent\";d:46.25;}s:25:\"shop_catalog@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:33573;s:14:\"optimized_size\";i:18784;s:7:\"percent\";d:44.05;}s:42:\"woocommerce_gallery_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:7125;s:14:\"optimized_size\";i:2568;s:7:\"percent\";d:63.96;}s:31:\"woocommerce_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:96071;s:14:\"optimized_size\";i:51640;s:7:\"percent\";d:46.25;}s:34:\"woocommerce_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:33573;s:14:\"optimized_size\";i:18784;s:7:\"percent\";d:44.05;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:89075;s:14:\"optimized_size\";i:48000;s:7:\"percent\";d:46.11;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10576;s:14:\"optimized_size\";i:4926;s:7:\"percent\";d:53.42;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:149293;s:14:\"optimized_size\";i:79954;s:7:\"percent\";d:46.44;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:19861;s:14:\"optimized_size\";i:10728;s:7:\"percent\";d:45.98;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:293337;s:14:\"optimized_size\";i:167912;s:7:\"percent\";d:42.76;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:835680;s:14:\"optimized_size\";i:457504;s:7:\"percent\";d:45.25;}}'),
(306,143,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:7.599722947308226;s:5:\"bytes\";i:61664;s:11:\"size_before\";i:811398;s:10:\"size_after\";i:749734;s:4:\"time\";d:0.5100000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:12:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:18;s:5:\"bytes\";i:3574;s:11:\"size_before\";i:19861;s:10:\"size_after\";i:16287;s:4:\"time\";d:0.05;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.4;s:5:\"bytes\";i:8064;s:11:\"size_before\";i:149293;s:10:\"size_after\";i:141229;s:4:\"time\";d:0.05;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:31.51;s:5:\"bytes\";i:3332;s:11:\"size_before\";i:10576;s:10:\"size_after\";i:7244;s:4:\"time\";d:0.02;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.31;s:5:\"bytes\";i:5621;s:11:\"size_before\";i:89075;s:10:\"size_after\";i:83454;s:4:\"time\";d:0.03;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.08;s:5:\"bytes\";i:9294;s:11:\"size_before\";i:183067;s:10:\"size_after\";i:173773;s:4:\"time\";d:0.08;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.67;s:5:\"bytes\";i:6996;s:11:\"size_before\";i:123429;s:10:\"size_after\";i:116433;s:4:\"time\";d:0.02;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.46;s:5:\"bytes\";i:4592;s:11:\"size_before\";i:54292;s:10:\"size_after\";i:49700;s:4:\"time\";d:0.03;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:13.36;s:5:\"bytes\";i:3797;s:11:\"size_before\";i:28415;s:10:\"size_after\";i:24618;s:4:\"time\";d:0.06;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";d:64.57;s:5:\"bytes\";i:2983;s:11:\"size_before\";i:4620;s:10:\"size_after\";i:1637;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.56;s:5:\"bytes\";i:4358;s:11:\"size_before\";i:45574;s:10:\"size_after\";i:41216;s:4:\"time\";d:0.09;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.17;s:5:\"bytes\";i:5929;s:11:\"size_before\";i:96071;s:10:\"size_after\";i:90142;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:43.85;s:5:\"bytes\";i:3124;s:11:\"size_before\";i:7125;s:10:\"size_after\";i:4001;s:4:\"time\";d:0.05;}}}'),
(307,143,'_imagify_optimization_level','1'),
(308,143,'_imagify_status','already_optimized'),
(309,143,'_imagify_data','a:2:{s:5:\"sizes\";a:12:{s:4:\"full\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:27:\"shop_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:7125;s:14:\"optimized_size\";i:2568;s:7:\"percent\";d:63.96;}s:24:\"shop_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:96071;s:14:\"optimized_size\";i:51640;s:7:\"percent\";d:46.25;}s:25:\"shop_catalog@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:33573;s:14:\"optimized_size\";i:18784;s:7:\"percent\";d:44.05;}s:42:\"woocommerce_gallery_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:7125;s:14:\"optimized_size\";i:2568;s:7:\"percent\";d:63.96;}s:31:\"woocommerce_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:96071;s:14:\"optimized_size\";i:51640;s:7:\"percent\";d:46.25;}s:34:\"woocommerce_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:33573;s:14:\"optimized_size\";i:18784;s:7:\"percent\";d:44.05;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:89075;s:14:\"optimized_size\";i:48000;s:7:\"percent\";d:46.11;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10576;s:14:\"optimized_size\";i:4926;s:7:\"percent\";d:53.42;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:149293;s:14:\"optimized_size\";i:79954;s:7:\"percent\";d:46.44;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:19861;s:14:\"optimized_size\";i:10728;s:7:\"percent\";d:45.98;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:293337;s:14:\"optimized_size\";i:167912;s:7:\"percent\";d:42.76;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:835680;s:14:\"optimized_size\";i:457504;s:7:\"percent\";d:45.25;}}'),
(310,143,'_imagify_optimization_level','1'),
(311,143,'_imagify_status','already_optimized'),
(312,143,'_imagify_data','a:2:{s:5:\"sizes\";a:12:{s:4:\"full\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:27:\"shop_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:7125;s:14:\"optimized_size\";i:2568;s:7:\"percent\";d:63.96;}s:24:\"shop_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:96071;s:14:\"optimized_size\";i:51640;s:7:\"percent\";d:46.25;}s:25:\"shop_catalog@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:33573;s:14:\"optimized_size\";i:18784;s:7:\"percent\";d:44.05;}s:42:\"woocommerce_gallery_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:7125;s:14:\"optimized_size\";i:2568;s:7:\"percent\";d:63.96;}s:31:\"woocommerce_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:96071;s:14:\"optimized_size\";i:51640;s:7:\"percent\";d:46.25;}s:34:\"woocommerce_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:33573;s:14:\"optimized_size\";i:18784;s:7:\"percent\";d:44.05;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:89075;s:14:\"optimized_size\";i:48000;s:7:\"percent\";d:46.11;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10576;s:14:\"optimized_size\";i:4926;s:7:\"percent\";d:53.42;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:149293;s:14:\"optimized_size\";i:79954;s:7:\"percent\";d:46.44;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:19861;s:14:\"optimized_size\";i:10728;s:7:\"percent\";d:45.98;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:293337;s:14:\"optimized_size\";i:167912;s:7:\"percent\";d:42.76;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:835680;s:14:\"optimized_size\";i:457504;s:7:\"percent\";d:45.25;}}'),
(313,143,'_imagify_optimization_level','1'),
(314,143,'_imagify_status','already_optimized'),
(315,143,'_imagify_data','a:2:{s:5:\"sizes\";a:12:{s:4:\"full\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:27:\"shop_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:7125;s:14:\"optimized_size\";i:2568;s:7:\"percent\";d:63.96;}s:24:\"shop_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:96071;s:14:\"optimized_size\";i:51640;s:7:\"percent\";d:46.25;}s:25:\"shop_catalog@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:33573;s:14:\"optimized_size\";i:18784;s:7:\"percent\";d:44.05;}s:42:\"woocommerce_gallery_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:7125;s:14:\"optimized_size\";i:2568;s:7:\"percent\";d:63.96;}s:31:\"woocommerce_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:96071;s:14:\"optimized_size\";i:51640;s:7:\"percent\";d:46.25;}s:34:\"woocommerce_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:33573;s:14:\"optimized_size\";i:18784;s:7:\"percent\";d:44.05;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:89075;s:14:\"optimized_size\";i:48000;s:7:\"percent\";d:46.11;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:10576;s:14:\"optimized_size\";i:4926;s:7:\"percent\";d:53.42;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:149293;s:14:\"optimized_size\";i:79954;s:7:\"percent\";d:46.44;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:19861;s:14:\"optimized_size\";i:10728;s:7:\"percent\";d:45.98;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:293337;s:14:\"optimized_size\";i:167912;s:7:\"percent\";d:42.76;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:835680;s:14:\"optimized_size\";i:457504;s:7:\"percent\";d:45.25;}}'),
(316,143,'_wxr_import_user_slug','admin'),
(317,143,'_athemes_sites_imported_post','1'),
(318,145,'_wp_attached_file','2021/07/pexels-karolina-grabowska-4210310.jpg'),
(319,145,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:45:\"2021/07/pexels-karolina-grabowska-4210310.jpg\";s:8:\"filesize\";i:68414;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4210310-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4990;}s:5:\"large\";a:5:{s:4:\"file\";s:46:\"pexels-karolina-grabowska-4210310-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:42956;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4210310-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2873;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4210310-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:25216;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:46:\"pexels-karolina-grabowska-4210310-1140x760.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:760;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:53062;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4210310-920x613.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:613;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:35494;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4210310-575x383.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:383;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:14721;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4210310-380x253.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:253;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7539;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4210310-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15223;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4210310-800x533.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:533;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:26964;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:45:\"pexels-karolina-grabowska-4210310-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1643;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(320,145,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.020116940988589;s:5:\"bytes\";i:7035;s:11:\"size_before\";i:232938;s:10:\"size_after\";i:225903;s:4:\"time\";d:0.6400000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:12:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5058;s:10:\"size_after\";i:5058;s:4:\"time\";d:0.06;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.45;s:5:\"bytes\";i:1488;s:11:\"size_before\";i:43145;s:10:\"size_after\";i:41657;s:4:\"time\";d:0.18;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2899;s:10:\"size_after\";i:2899;s:4:\"time\";d:0.02;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.26;s:5:\"bytes\";i:829;s:11:\"size_before\";i:25419;s:10:\"size_after\";i:24590;s:4:\"time\";d:0.03;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.69;s:5:\"bytes\";i:1958;s:11:\"size_before\";i:53083;s:10:\"size_after\";i:51125;s:4:\"time\";d:0.04;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.52;s:5:\"bytes\";i:1254;s:11:\"size_before\";i:35605;s:10:\"size_after\";i:34351;s:4:\"time\";d:0.12;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.11;s:5:\"bytes\";i:317;s:11:\"size_before\";i:15005;s:10:\"size_after\";i:14688;s:4:\"time\";d:0.02;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:7622;s:10:\"size_after\";i:7622;s:4:\"time\";d:0.02;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:814;s:10:\"size_after\";i:814;s:4:\"time\";d:0.04;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.4;s:5:\"bytes\";i:370;s:11:\"size_before\";i:15429;s:10:\"size_after\";i:15059;s:4:\"time\";d:0.07;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.01;s:5:\"bytes\";i:819;s:11:\"size_before\";i:27202;s:10:\"size_after\";i:26383;s:4:\"time\";d:0.03;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1657;s:10:\"size_after\";i:1657;s:4:\"time\";d:0.01;}}}'),
(321,145,'_wxr_import_user_slug','admin'),
(322,145,'_athemes_sites_imported_post','1'),
(323,146,'_wp_attached_file','2021/07/pexels-jess-harper-sunday-2834934.jpg'),
(324,146,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:45:\"2021/07/pexels-jess-harper-sunday-2834934.jpg\";s:8:\"filesize\";i:130220;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:45:\"pexels-jess-harper-sunday-2834934-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:11944;}s:5:\"large\";a:5:{s:4:\"file\";s:46:\"pexels-jess-harper-sunday-2834934-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:84461;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:45:\"pexels-jess-harper-sunday-2834934-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6166;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:45:\"pexels-jess-harper-sunday-2834934-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:52557;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:46:\"pexels-jess-harper-sunday-2834934-1140x760.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:760;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:101808;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:45:\"pexels-jess-harper-sunday-2834934-920x613.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:613;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:70488;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:45:\"pexels-jess-harper-sunday-2834934-575x383.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:383;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:32898;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:45:\"pexels-jess-harper-sunday-2834934-380x253.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:253;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:17240;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:45:\"pexels-jess-harper-sunday-2834934-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:30622;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:45:\"pexels-jess-harper-sunday-2834934-800x533.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:533;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:56179;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:45:\"pexels-jess-harper-sunday-2834934-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3371;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(325,146,'_imagify_optimization_level','1'),
(326,146,'_imagify_status','already_optimized'),
(327,146,'_imagify_data','a:2:{s:5:\"sizes\";a:12:{s:4:\"full\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:27:\"shop_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6553;s:14:\"optimized_size\";i:2006;s:7:\"percent\";d:69.39;}s:24:\"shop_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:58679;s:14:\"optimized_size\";i:26380;s:7:\"percent\";d:55.04;}s:25:\"shop_catalog@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:25974;s:14:\"optimized_size\";i:12572;s:7:\"percent\";d:51.6;}s:42:\"woocommerce_gallery_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6553;s:14:\"optimized_size\";i:2006;s:7:\"percent\";d:69.39;}s:31:\"woocommerce_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:58679;s:14:\"optimized_size\";i:26380;s:7:\"percent\";d:55.04;}s:34:\"woocommerce_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:25974;s:14:\"optimized_size\";i:12572;s:7:\"percent\";d:51.6;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:55038;s:14:\"optimized_size\";i:25194;s:7:\"percent\";d:54.22;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:9335;s:14:\"optimized_size\";i:3734;s:7:\"percent\";d:60;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:85419;s:14:\"optimized_size\";i:36118;s:7:\"percent\";d:57.72;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:15130;s:14:\"optimized_size\";i:6612;s:7:\"percent\";d:56.3;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:160364;s:14:\"optimized_size\";i:57572;s:7:\"percent\";d:64.1;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:507698;s:14:\"optimized_size\";i:211146;s:7:\"percent\";d:58.41;}}'),
(328,146,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:9.624778108583541;s:5:\"bytes\";i:48039;s:11:\"size_before\";i:499118;s:10:\"size_after\";i:451079;s:4:\"time\";d:0.54;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:12:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:21.93;s:5:\"bytes\";i:3318;s:11:\"size_before\";i:15130;s:10:\"size_after\";i:11812;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.02;s:5:\"bytes\";i:5143;s:11:\"size_before\";i:85419;s:10:\"size_after\";i:80276;s:4:\"time\";d:0.02;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:33.78;s:5:\"bytes\";i:3153;s:11:\"size_before\";i:9335;s:10:\"size_after\";i:6182;s:4:\"time\";d:0.02;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.82;s:5:\"bytes\";i:4306;s:11:\"size_before\";i:55038;s:10:\"size_after\";i:50732;s:4:\"time\";d:0.04;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.67;s:5:\"bytes\";i:5773;s:11:\"size_before\";i:101898;s:10:\"size_after\";i:96125;s:4:\"time\";d:0.18;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.65;s:5:\"bytes\";i:4813;s:11:\"size_before\";i:72386;s:10:\"size_after\";i:67573;s:4:\"time\";d:0.05;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.64;s:5:\"bytes\";i:3830;s:11:\"size_before\";i:36013;s:10:\"size_after\";i:32183;s:4:\"time\";d:0.02;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:16.88;s:5:\"bytes\";i:3452;s:11:\"size_before\";i:20451;s:10:\"size_after\";i:16999;s:4:\"time\";d:0.04;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";d:65.3;s:5:\"bytes\";i:2943;s:11:\"size_before\";i:4507;s:10:\"size_after\";i:1564;s:4:\"time\";i:0;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.59;s:5:\"bytes\";i:3906;s:11:\"size_before\";i:33709;s:10:\"size_after\";i:29803;s:4:\"time\";d:0.04;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.45;s:5:\"bytes\";i:4372;s:11:\"size_before\";i:58679;s:10:\"size_after\";i:54307;s:4:\"time\";d:0.05;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:46.24;s:5:\"bytes\";i:3030;s:11:\"size_before\";i:6553;s:10:\"size_after\";i:3523;s:4:\"time\";d:0.06;}}}'),
(329,146,'_imagify_optimization_level','1'),
(330,146,'_imagify_status','already_optimized'),
(331,146,'_imagify_data','a:2:{s:5:\"sizes\";a:12:{s:4:\"full\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:27:\"shop_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6553;s:14:\"optimized_size\";i:2006;s:7:\"percent\";d:69.39;}s:24:\"shop_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:58679;s:14:\"optimized_size\";i:26380;s:7:\"percent\";d:55.04;}s:25:\"shop_catalog@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:25974;s:14:\"optimized_size\";i:12572;s:7:\"percent\";d:51.6;}s:42:\"woocommerce_gallery_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6553;s:14:\"optimized_size\";i:2006;s:7:\"percent\";d:69.39;}s:31:\"woocommerce_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:58679;s:14:\"optimized_size\";i:26380;s:7:\"percent\";d:55.04;}s:34:\"woocommerce_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:25974;s:14:\"optimized_size\";i:12572;s:7:\"percent\";d:51.6;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:55038;s:14:\"optimized_size\";i:25194;s:7:\"percent\";d:54.22;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:9335;s:14:\"optimized_size\";i:3734;s:7:\"percent\";d:60;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:85419;s:14:\"optimized_size\";i:36118;s:7:\"percent\";d:57.72;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:15130;s:14:\"optimized_size\";i:6612;s:7:\"percent\";d:56.3;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:160364;s:14:\"optimized_size\";i:57572;s:7:\"percent\";d:64.1;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:507698;s:14:\"optimized_size\";i:211146;s:7:\"percent\";d:58.41;}}'),
(332,146,'_imagify_optimization_level','1'),
(333,146,'_imagify_status','already_optimized'),
(334,146,'_imagify_data','a:2:{s:5:\"sizes\";a:12:{s:4:\"full\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:27:\"shop_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6553;s:14:\"optimized_size\";i:2006;s:7:\"percent\";d:69.39;}s:24:\"shop_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:58679;s:14:\"optimized_size\";i:26380;s:7:\"percent\";d:55.04;}s:25:\"shop_catalog@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:25974;s:14:\"optimized_size\";i:12572;s:7:\"percent\";d:51.6;}s:42:\"woocommerce_gallery_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6553;s:14:\"optimized_size\";i:2006;s:7:\"percent\";d:69.39;}s:31:\"woocommerce_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:58679;s:14:\"optimized_size\";i:26380;s:7:\"percent\";d:55.04;}s:34:\"woocommerce_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:25974;s:14:\"optimized_size\";i:12572;s:7:\"percent\";d:51.6;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:55038;s:14:\"optimized_size\";i:25194;s:7:\"percent\";d:54.22;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:9335;s:14:\"optimized_size\";i:3734;s:7:\"percent\";d:60;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:85419;s:14:\"optimized_size\";i:36118;s:7:\"percent\";d:57.72;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:15130;s:14:\"optimized_size\";i:6612;s:7:\"percent\";d:56.3;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:160364;s:14:\"optimized_size\";i:57572;s:7:\"percent\";d:64.1;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:507698;s:14:\"optimized_size\";i:211146;s:7:\"percent\";d:58.41;}}'),
(335,146,'_imagify_optimization_level','1'),
(336,146,'_imagify_status','already_optimized'),
(337,146,'_imagify_data','a:2:{s:5:\"sizes\";a:12:{s:4:\"full\";a:2:{s:7:\"success\";b:0;s:5:\"error\";s:77:\"WELL DONE. This image is already compressed, no further compression required.\";}s:27:\"shop_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6553;s:14:\"optimized_size\";i:2006;s:7:\"percent\";d:69.39;}s:24:\"shop_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:58679;s:14:\"optimized_size\";i:26380;s:7:\"percent\";d:55.04;}s:25:\"shop_catalog@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:25974;s:14:\"optimized_size\";i:12572;s:7:\"percent\";d:51.6;}s:42:\"woocommerce_gallery_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:6553;s:14:\"optimized_size\";i:2006;s:7:\"percent\";d:69.39;}s:31:\"woocommerce_single@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:58679;s:14:\"optimized_size\";i:26380;s:7:\"percent\";d:55.04;}s:34:\"woocommerce_thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:25974;s:14:\"optimized_size\";i:12572;s:7:\"percent\";d:51.6;}s:25:\"medium_large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:55038;s:14:\"optimized_size\";i:25194;s:7:\"percent\";d:54.22;}s:22:\"thumbnail@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:9335;s:14:\"optimized_size\";i:3734;s:7:\"percent\";d:60;}s:18:\"large@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:85419;s:14:\"optimized_size\";i:36118;s:7:\"percent\";d:57.72;}s:19:\"medium@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:15130;s:14:\"optimized_size\";i:6612;s:7:\"percent\";d:56.3;}s:17:\"full@imagify-webp\";a:4:{s:7:\"success\";b:1;s:13:\"original_size\";i:160364;s:14:\"optimized_size\";i:57572;s:7:\"percent\";d:64.1;}}s:5:\"stats\";a:3:{s:13:\"original_size\";i:507698;s:14:\"optimized_size\";i:211146;s:7:\"percent\";d:58.41;}}'),
(338,146,'_wxr_import_user_slug','admin'),
(339,146,'_athemes_sites_imported_post','1'),
(340,163,'_wp_attached_file','2021/07/BOTIGA.svg'),
(341,163,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:1769;}'),
(343,163,'_wxr_import_user_slug','admin'),
(344,163,'_athemes_sites_imported_post','1'),
(345,171,'_wp_attached_file','2021/07/gr.jpg'),
(346,171,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:512;s:6:\"height\";i:625;s:4:\"file\";s:14:\"2021/07/gr.jpg\";s:8:\"filesize\";i:7503;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:14:\"gr-246x300.jpg\";s:5:\"width\";i:246;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2976;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:14:\"gr-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1453;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:14:\"gr-380x464.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:464;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5270;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:14:\"gr-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5980;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:14:\"gr-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1016;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(347,171,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:17180;s:10:\"size_after\";i:17180;s:4:\"time\";d:0.17;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:6:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2993;s:10:\"size_after\";i:2993;s:4:\"time\";d:0.03;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1455;s:10:\"size_after\";i:1455;s:4:\"time\";d:0.03;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5210;s:10:\"size_after\";i:5210;s:4:\"time\";d:0.04;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:577;s:10:\"size_after\";i:577;s:4:\"time\";d:0.04;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5933;s:10:\"size_after\";i:5933;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1012;s:10:\"size_after\";i:1012;s:4:\"time\";d:0.01;}}}'),
(348,171,'_wxr_import_user_slug','admin'),
(349,171,'_athemes_sites_imported_post','1'),
(350,172,'_wp_attached_file','2021/07/gray.jpg'),
(351,172,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:512;s:6:\"height\";i:625;s:4:\"file\";s:16:\"2021/07/gray.jpg\";s:8:\"filesize\";i:6490;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:16:\"gray-246x300.jpg\";s:5:\"width\";i:246;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2640;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:16:\"gray-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1302;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:16:\"gray-380x464.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:464;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4602;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:16:\"gray-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5198;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:16:\"gray-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:904;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(352,172,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:15018;s:10:\"size_after\";i:15018;s:4:\"time\";d:0.12;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:6:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2610;s:10:\"size_after\";i:2610;s:4:\"time\";d:0.03;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1293;s:10:\"size_after\";i:1293;s:4:\"time\";d:0.01;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4523;s:10:\"size_after\";i:4523;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:539;s:10:\"size_after\";i:539;s:4:\"time\";d:0.03;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5151;s:10:\"size_after\";i:5151;s:4:\"time\";d:0.01;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:902;s:10:\"size_after\";i:902;s:4:\"time\";d:0.03;}}}'),
(353,172,'_wxr_import_user_slug','admin'),
(354,172,'_athemes_sites_imported_post','1'),
(355,184,'_wp_attached_file','2021/07/Img-1.jpg'),
(356,184,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:732;s:6:\"height\";i:577;s:4:\"file\";s:17:\"2021/07/Img-1.jpg\";s:8:\"filesize\";i:8836;s:5:\"sizes\";a:6:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"Img-1-300x236.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:236;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2539;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"Img-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1347;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:17:\"Img-1-575x453.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:453;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6364;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:17:\"Img-1-380x300.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3482;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:17:\"Img-1-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4981;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:17:\"Img-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:878;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(357,184,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:21075;s:10:\"size_after\";i:21075;s:4:\"time\";d:0.22;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:7:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2648;s:10:\"size_after\";i:2648;s:4:\"time\";d:0.01;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1384;s:10:\"size_after\";i:1384;s:4:\"time\";d:0.01;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:6739;s:10:\"size_after\";i:6739;s:4:\"time\";d:0.05;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3658;s:10:\"size_after\";i:3658;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:538;s:10:\"size_after\";i:538;s:4:\"time\";i:0;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5216;s:10:\"size_after\";i:5216;s:4:\"time\";d:0.01;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:892;s:10:\"size_after\";i:892;s:4:\"time\";d:0.13;}}}'),
(358,184,'_wxr_import_user_slug','admin'),
(359,184,'_athemes_sites_imported_post','1'),
(360,189,'_wp_attached_file','2021/07/Img-2.jpg'),
(361,189,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:668;s:6:\"height\";i:457;s:4:\"file\";s:17:\"2021/07/Img-2.jpg\";s:8:\"filesize\";i:30093;s:5:\"sizes\";a:6:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"Img-2-300x205.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:205;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9028;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"Img-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4548;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:17:\"Img-2-575x393.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:393;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23683;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:17:\"Img-2-380x260.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:260;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12933;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:17:\"Img-2-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:21233;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:17:\"Img-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2564;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(362,189,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:0.9433962264150944;s:5:\"bytes\";i:710;s:11:\"size_before\";i:75260;s:10:\"size_after\";i:74550;s:4:\"time\";d:0.19;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:7:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:9057;s:10:\"size_after\";i:9057;s:4:\"time\";d:0.07;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4564;s:10:\"size_after\";i:4564;s:4:\"time\";d:0.03;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.36;s:5:\"bytes\";i:323;s:11:\"size_before\";i:23735;s:10:\"size_after\";i:23412;s:4:\"time\";d:0.01;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.72;s:5:\"bytes\";i:93;s:11:\"size_before\";i:12986;s:10:\"size_after\";i:12893;s:4:\"time\";d:0.04;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1064;s:10:\"size_after\";i:1064;s:4:\"time\";d:0.03;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.38;s:5:\"bytes\";i:294;s:11:\"size_before\";i:21290;s:10:\"size_after\";i:20996;s:4:\"time\";d:0.01;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2564;s:10:\"size_after\";i:2564;s:4:\"time\";i:0;}}}'),
(363,189,'_wxr_import_user_slug','admin'),
(364,189,'_athemes_sites_imported_post','1'),
(365,190,'_wp_attached_file','2021/07/Img-3.jpg'),
(366,190,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:668;s:6:\"height\";i:457;s:4:\"file\";s:17:\"2021/07/Img-3.jpg\";s:8:\"filesize\";i:23653;s:5:\"sizes\";a:6:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"Img-3-300x205.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:205;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7929;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"Img-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3783;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:17:\"Img-3-575x393.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:393;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19410;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:17:\"Img-3-380x260.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:260;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10966;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:17:\"Img-3-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15425;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:17:\"Img-3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2311;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(367,190,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:60525;s:10:\"size_after\";i:60525;s:4:\"time\";d:0.25;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:7:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:7922;s:10:\"size_after\";i:7922;s:4:\"time\";d:0.04;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3783;s:10:\"size_after\";i:3783;s:4:\"time\";d:0.02;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:19217;s:10:\"size_after\";i:19217;s:4:\"time\";d:0.06;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:10958;s:10:\"size_after\";i:10958;s:4:\"time\";d:0.02;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1096;s:10:\"size_after\";i:1096;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:15240;s:10:\"size_after\";i:15240;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2309;s:10:\"size_after\";i:2309;s:4:\"time\";d:0.08;}}}'),
(368,190,'_wxr_import_user_slug','admin'),
(369,190,'_athemes_sites_imported_post','1'),
(370,242,'_wp_attached_file','2021/07/Hero2.jpg'),
(371,242,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:2048;s:6:\"height\";i:1138;s:4:\"file\";s:17:\"2021/07/Hero2.jpg\";s:8:\"filesize\";i:90519;s:5:\"sizes\";a:12:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"Hero2-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4167;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"Hero2-1024x569.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:569;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:30522;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"Hero2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2131;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"Hero2-768x427.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:427;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18644;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:18:\"Hero2-1536x854.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:60870;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:18:\"Hero2-1140x633.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:633;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:37278;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:17:\"Hero2-920x511.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:511;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:25400;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:17:\"Hero2-575x320.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:320;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:11652;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:17:\"Hero2-380x211.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:211;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5936;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:17:\"Hero2-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10048;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:17:\"Hero2-800x445.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:445;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20308;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:17:\"Hero2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1398;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(372,242,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.8036435038725864;s:5:\"bytes\";i:8717;s:11:\"size_before\";i:229175;s:10:\"size_after\";i:220458;s:4:\"time\";d:0.32;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:13:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4161;s:10:\"size_after\";i:4161;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.93;s:5:\"bytes\";i:1197;s:11:\"size_before\";i:30456;s:10:\"size_after\";i:29259;s:4:\"time\";d:0.03;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2145;s:10:\"size_after\";i:2145;s:4:\"time\";d:0.01;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.32;s:5:\"bytes\";i:621;s:11:\"size_before\";i:18700;s:10:\"size_after\";i:18079;s:4:\"time\";d:0.03;}s:9:\"1536x1536\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.33;s:5:\"bytes\";i:3243;s:11:\"size_before\";i:60790;s:10:\"size_after\";i:57547;s:4:\"time\";d:0.08;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.59;s:5:\"bytes\";i:1712;s:11:\"size_before\";i:37331;s:10:\"size_after\";i:35619;s:4:\"time\";d:0.03;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.74;s:5:\"bytes\";i:950;s:11:\"size_before\";i:25429;s:10:\"size_after\";i:24479;s:4:\"time\";d:0.02;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.37;s:5:\"bytes\";i:276;s:11:\"size_before\";i:11670;s:10:\"size_after\";i:11394;s:4:\"time\";d:0.04;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5935;s:10:\"size_after\";i:5935;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:753;s:10:\"size_after\";i:753;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:10095;s:10:\"size_after\";i:10095;s:4:\"time\";d:0.01;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.54;s:5:\"bytes\";i:718;s:11:\"size_before\";i:20304;s:10:\"size_after\";i:19586;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1406;s:10:\"size_after\";i:1406;s:4:\"time\";d:0.01;}}}'),
(373,242,'_wxr_import_user_slug','admin'),
(374,242,'_athemes_sites_imported_post','1'),
(375,243,'_wp_attached_file','2022/10/woocommerce-placeholder.png'),
(376,243,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:35:\"2022/10/woocommerce-placeholder.png\";s:8:\"filesize\";i:102644;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:10659;}s:5:\"large\";a:5:{s:4:\"file\";s:37:\"woocommerce-placeholder-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:80210;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:3738;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:48652;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:37:\"woocommerce-placeholder-1140x1140.png\";s:5:\"width\";i:1140;s:6:\"height\";i:1140;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:93164;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-920x920.png\";s:5:\"width\";i:920;s:6:\"height\";i:920;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:66476;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-575x575.png\";s:5:\"width\";i:575;s:6:\"height\";i:575;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:30265;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-380x380.png\";s:5:\"width\";i:380;s:6:\"height\";i:380;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:15387;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:35:\"woocommerce-placeholder-420x420.png\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:17910;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-800x800.png\";s:5:\"width\";i:800;s:6:\"height\";i:800;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:52180;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1790;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(377,243,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.066301308805056;s:5:\"bytes\";i:20005;s:11:\"size_before\";i:394864;s:10:\"size_after\";i:374859;s:4:\"time\";d:7.969999999999999;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:9:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.41;s:5:\"bytes\";i:407;s:11:\"size_before\";i:11947;s:10:\"size_after\";i:11540;s:4:\"time\";d:0.48;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.29;s:5:\"bytes\";i:2915;s:11:\"size_before\";i:88586;s:10:\"size_after\";i:85671;s:4:\"time\";d:0.41;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.23;s:5:\"bytes\";i:262;s:11:\"size_before\";i:4205;s:10:\"size_after\";i:3943;s:4:\"time\";d:0.15;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.36;s:5:\"bytes\";i:3525;s:11:\"size_before\";i:55454;s:10:\"size_after\";i:51929;s:4:\"time\";d:2.03;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:5;s:5:\"bytes\";i:5371;s:11:\"size_before\";i:107345;s:10:\"size_after\";i:101974;s:4:\"time\";d:1.82;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.25;s:5:\"bytes\";i:4685;s:11:\"size_before\";i:75008;s:10:\"size_after\";i:70323;s:4:\"time\";d:2.01;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.13;s:5:\"bytes\";i:2101;s:11:\"size_before\";i:34256;s:10:\"size_after\";i:32155;s:4:\"time\";d:0.98;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.27;s:5:\"bytes\";i:735;s:11:\"size_before\";i:17217;s:10:\"size_after\";i:16482;s:4:\"time\";d:0.08;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.47;s:5:\"bytes\";i:4;s:11:\"size_before\";i:846;s:10:\"size_after\";i:842;s:4:\"time\";d:0.01;}}}'),
(378,243,'_wxr_import_user_slug','admin'),
(379,243,'_athemes_sites_imported_post','1'),
(380,249,'_wp_attached_file','2021/07/Img-4.jpg'),
(381,249,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1050;s:6:\"height\";i:1260;s:4:\"file\";s:17:\"2021/07/Img-4.jpg\";s:8:\"filesize\";i:28976;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"Img-4-250x300.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4298;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"Img-4-853x1024.jpg\";s:5:\"width\";i:853;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:24069;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"Img-4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2219;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"Img-4-768x922.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:922;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20415;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:18:\"Img-4-920x1104.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:1104;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:26931;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:17:\"Img-4-575x690.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:690;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:13522;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:17:\"Img-4-380x456.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:456;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7585;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:17:\"Img-4-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8491;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:17:\"Img-4-800x960.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:22047;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:17:\"Img-4-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1360;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(382,249,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:0.6159630727845199;s:5:\"bytes\";i:806;s:11:\"size_before\";i:130852;s:10:\"size_after\";i:130046;s:4:\"time\";d:0.52;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4321;s:10:\"size_after\";i:4321;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.82;s:5:\"bytes\";i:196;s:11:\"size_before\";i:23824;s:10:\"size_after\";i:23628;s:4:\"time\";d:0.04;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2212;s:10:\"size_after\";i:2212;s:4:\"time\";d:0.01;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.79;s:5:\"bytes\";i:161;s:11:\"size_before\";i:20307;s:10:\"size_after\";i:20146;s:4:\"time\";d:0.18;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.73;s:5:\"bytes\";i:194;s:11:\"size_before\";i:26633;s:10:\"size_after\";i:26439;s:4:\"time\";d:0.11;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.64;s:5:\"bytes\";i:87;s:11:\"size_before\";i:13512;s:10:\"size_after\";i:13425;s:4:\"time\";d:0.04;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:7573;s:10:\"size_after\";i:7573;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:720;s:10:\"size_after\";i:720;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:8505;s:10:\"size_after\";i:8505;s:4:\"time\";d:0.02;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.77;s:5:\"bytes\";i:168;s:11:\"size_before\";i:21878;s:10:\"size_after\";i:21710;s:4:\"time\";d:0.04;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1367;s:10:\"size_after\";i:1367;s:4:\"time\";d:0.05;}}}'),
(383,249,'_wxr_import_user_slug','admin'),
(384,249,'_athemes_sites_imported_post','1'),
(385,253,'_wp_attached_file','2021/07/Mask-Group-5.jpg'),
(386,253,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1050;s:6:\"height\";i:1260;s:4:\"file\";s:24:\"2021/07/Mask-Group-5.jpg\";s:8:\"filesize\";i:24341;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:24:\"Mask-Group-5-250x300.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3508;}s:5:\"large\";a:5:{s:4:\"file\";s:25:\"Mask-Group-5-853x1024.jpg\";s:5:\"width\";i:853;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20913;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:24:\"Mask-Group-5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1853;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:24:\"Mask-Group-5-768x922.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:922;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:17804;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:25:\"Mask-Group-5-920x1104.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:1104;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23323;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:24:\"Mask-Group-5-575x690.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:690;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:11581;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:24:\"Mask-Group-5-380x456.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:456;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6379;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:24:\"Mask-Group-5-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7132;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:24:\"Mask-Group-5-800x960.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19008;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:24:\"Mask-Group-5-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1189;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(387,253,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:0.5643620409029793;s:5:\"bytes\";i:638;s:11:\"size_before\";i:113048;s:10:\"size_after\";i:112410;s:4:\"time\";d:0.33999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3504;s:10:\"size_after\";i:3504;s:4:\"time\";d:0.03;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.74;s:5:\"bytes\";i:154;s:11:\"size_before\";i:20796;s:10:\"size_after\";i:20642;s:4:\"time\";d:0.02;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1841;s:10:\"size_after\";i:1841;s:4:\"time\";d:0.01;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.51;s:5:\"bytes\";i:90;s:11:\"size_before\";i:17748;s:10:\"size_after\";i:17658;s:4:\"time\";d:0.08;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.03;s:5:\"bytes\";i:240;s:11:\"size_before\";i:23314;s:10:\"size_after\";i:23074;s:4:\"time\";d:0.06;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.09;s:5:\"bytes\";i:10;s:11:\"size_before\";i:11529;s:10:\"size_after\";i:11519;s:4:\"time\";d:0.03;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:6391;s:10:\"size_after\";i:6391;s:4:\"time\";d:0.02;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:664;s:10:\"size_after\";i:664;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:7152;s:10:\"size_after\";i:7152;s:4:\"time\";d:0.04;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.76;s:5:\"bytes\";i:144;s:11:\"size_before\";i:18916;s:10:\"size_after\";i:18772;s:4:\"time\";d:0.03;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1193;s:10:\"size_after\";i:1193;s:4:\"time\";d:0.01;}}}'),
(388,253,'_wxr_import_user_slug','admin'),
(389,253,'_athemes_sites_imported_post','1'),
(390,255,'_wp_attached_file','2021/07/hbg-1.jpg'),
(391,255,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1440;s:6:\"height\";i:580;s:4:\"file\";s:17:\"2021/07/hbg-1.jpg\";s:8:\"filesize\";i:23664;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"hbg-1-300x121.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:121;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2974;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"hbg-1-1024x412.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:412;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15401;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"hbg-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2175;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"hbg-1-768x309.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:309;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10095;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:18:\"hbg-1-1140x459.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:459;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:17980;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:17:\"hbg-1-920x371.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:371;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:13145;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:17:\"hbg-1-575x232.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:232;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6840;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:17:\"hbg-1-380x153.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:153;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4017;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:17:\"hbg-1-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8224;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:17:\"hbg-1-800x322.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:322;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10715;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:17:\"hbg-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1397;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(392,255,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:94569;s:10:\"size_after\";i:94569;s:4:\"time\";d:0.53;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:12:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3018;s:10:\"size_after\";i:3018;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:15564;s:10:\"size_after\";i:15564;s:4:\"time\";d:0.13;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2205;s:10:\"size_after\";i:2205;s:4:\"time\";d:0.09;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:10182;s:10:\"size_after\";i:10182;s:4:\"time\";d:0.04;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:18101;s:10:\"size_after\";i:18101;s:4:\"time\";d:0.01;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:13314;s:10:\"size_after\";i:13314;s:4:\"time\";d:0.1;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:6859;s:10:\"size_after\";i:6859;s:4:\"time\";d:0.04;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4050;s:10:\"size_after\";i:4050;s:4:\"time\";i:0;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:772;s:10:\"size_after\";i:772;s:4:\"time\";d:0.03;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:8243;s:10:\"size_after\";i:8243;s:4:\"time\";d:0.01;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:10859;s:10:\"size_after\";i:10859;s:4:\"time\";d:0.03;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1402;s:10:\"size_after\";i:1402;s:4:\"time\";d:0.03;}}}'),
(393,255,'_wxr_import_user_slug','admin'),
(394,255,'_athemes_sites_imported_post','1'),
(395,258,'_wp_attached_file','2021/07/Rectangle-603-1.jpg'),
(396,258,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1110;s:6:\"height\";i:480;s:4:\"file\";s:27:\"2021/07/Rectangle-603-1.jpg\";s:8:\"filesize\";i:89008;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:27:\"Rectangle-603-1-300x130.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:130;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9777;}s:5:\"large\";a:5:{s:4:\"file\";s:28:\"Rectangle-603-1-1024x443.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:443;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:74488;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:27:\"Rectangle-603-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6121;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:27:\"Rectangle-603-1-768x332.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:332;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:47808;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:27:\"Rectangle-603-1-920x398.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:398;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:63431;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:27:\"Rectangle-603-1-575x249.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:249;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:30554;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:27:\"Rectangle-603-1-380x164.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:164;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15179;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:27:\"Rectangle-603-1-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:31887;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:27:\"Rectangle-603-1-800x346.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:346;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:51267;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:27:\"Rectangle-603-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3165;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(397,258,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:1.4174520824753265;s:5:\"bytes\";i:4784;s:11:\"size_before\";i:337507;s:10:\"size_after\";i:332723;s:4:\"time\";d:0.49000000000000005;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.32;s:5:\"bytes\";i:31;s:11:\"size_before\";i:9837;s:10:\"size_after\";i:9806;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.42;s:5:\"bytes\";i:1063;s:11:\"size_before\";i:74973;s:10:\"size_after\";i:73910;s:4:\"time\";d:0.15;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:6167;s:10:\"size_after\";i:6167;s:4:\"time\";d:0.01;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.49;s:5:\"bytes\";i:719;s:11:\"size_before\";i:48264;s:10:\"size_after\";i:47545;s:4:\"time\";d:0.15;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.73;s:5:\"bytes\";i:1106;s:11:\"size_before\";i:63943;s:10:\"size_after\";i:62837;s:4:\"time\";d:0.03;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.54;s:5:\"bytes\";i:475;s:11:\"size_before\";i:30825;s:10:\"size_after\";i:30350;s:4:\"time\";d:0.03;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.52;s:5:\"bytes\";i:233;s:11:\"size_before\";i:15287;s:10:\"size_after\";i:15054;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1167;s:10:\"size_after\";i:1167;s:4:\"time\";i:0;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.06;s:5:\"bytes\";i:340;s:11:\"size_before\";i:32094;s:10:\"size_after\";i:31754;s:4:\"time\";d:0.06;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.58;s:5:\"bytes\";i:817;s:11:\"size_before\";i:51774;s:10:\"size_after\";i:50957;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3176;s:10:\"size_after\";i:3176;s:4:\"time\";d:0.01;}}}'),
(398,258,'_wxr_import_user_slug','admin'),
(399,258,'_athemes_sites_imported_post','1'),
(400,305,'_wp_attached_file','2021/07/Rectangle-2.jpg'),
(401,305,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1110;s:6:\"height\";i:480;s:4:\"file\";s:23:\"2021/07/Rectangle-2.jpg\";s:8:\"filesize\";i:123661;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"Rectangle-2-300x130.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:130;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10037;}s:5:\"large\";a:5:{s:4:\"file\";s:24:\"Rectangle-2-1024x443.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:443;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:97086;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"Rectangle-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5598;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:23:\"Rectangle-2-768x332.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:332;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:58060;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:23:\"Rectangle-2-920x398.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:398;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:79915;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:23:\"Rectangle-2-575x249.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:249;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:33804;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:23:\"Rectangle-2-380x164.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:164;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15376;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:23:\"Rectangle-2-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:36600;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:23:\"Rectangle-2-800x346.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:346;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:62586;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:23:\"Rectangle-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2788;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(402,305,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:2.1945655555171513;s:5:\"bytes\";i:8889;s:11:\"size_before\";i:405046;s:10:\"size_after\";i:396157;s:4:\"time\";d:0.32999999999999996;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.16;s:5:\"bytes\";i:16;s:11:\"size_before\";i:10117;s:10:\"size_after\";i:10101;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.27;s:5:\"bytes\";i:2216;s:11:\"size_before\";i:97496;s:10:\"size_after\";i:95280;s:4:\"time\";d:0.06;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5646;s:10:\"size_after\";i:5646;s:4:\"time\";d:0.01;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.4;s:5:\"bytes\";i:1398;s:11:\"size_before\";i:58359;s:10:\"size_after\";i:56961;s:4:\"time\";d:0.03;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.44;s:5:\"bytes\";i:1958;s:11:\"size_before\";i:80343;s:10:\"size_after\";i:78385;s:4:\"time\";d:0.02;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.6;s:5:\"bytes\";i:886;s:11:\"size_before\";i:34135;s:10:\"size_after\";i:33249;s:4:\"time\";d:0.01;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.95;s:5:\"bytes\";i:303;s:11:\"size_before\";i:15505;s:10:\"size_after\";i:15202;s:4:\"time\";d:0.02;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:998;s:10:\"size_after\";i:998;s:4:\"time\";d:0.02;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.4;s:5:\"bytes\";i:512;s:11:\"size_before\";i:36633;s:10:\"size_after\";i:36121;s:4:\"time\";d:0.09;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.54;s:5:\"bytes\";i:1600;s:11:\"size_before\";i:63013;s:10:\"size_after\";i:61413;s:4:\"time\";d:0.04;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2801;s:10:\"size_after\";i:2801;s:4:\"time\";d:0.02;}}}'),
(403,305,'_wxr_import_user_slug','admin'),
(404,305,'_athemes_sites_imported_post','1'),
(405,310,'_wp_attached_file','2021/07/Glamifiedpeach.jpg'),
(406,310,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1050;s:6:\"height\";i:1260;s:4:\"file\";s:26:\"2021/07/Glamifiedpeach.jpg\";s:8:\"filesize\";i:21194;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:26:\"Glamifiedpeach-250x300.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2849;}s:5:\"large\";a:5:{s:4:\"file\";s:27:\"Glamifiedpeach-853x1024.jpg\";s:5:\"width\";i:853;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16869;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:26:\"Glamifiedpeach-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1434;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:26:\"Glamifiedpeach-768x922.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:922;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:14362;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:27:\"Glamifiedpeach-920x1104.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:1104;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19046;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:26:\"Glamifiedpeach-575x690.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:690;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9053;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:26:\"Glamifiedpeach-380x456.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:456;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4706;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:26:\"Glamifiedpeach-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5554;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:26:\"Glamifiedpeach-800x960.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15217;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:26:\"Glamifiedpeach-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:956;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(407,310,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:90187;s:10:\"size_after\";i:90187;s:4:\"time\";d:0.37000000000000005;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2851;s:10:\"size_after\";i:2851;s:4:\"time\";d:0.04;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:16694;s:10:\"size_after\";i:16694;s:4:\"time\";d:0.01;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1436;s:10:\"size_after\";i:1436;s:4:\"time\";i:0;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:14315;s:10:\"size_after\";i:14315;s:4:\"time\";d:0.1;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:18918;s:10:\"size_after\";i:18918;s:4:\"time\";d:0.02;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:9078;s:10:\"size_after\";i:9078;s:4:\"time\";d:0.03;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4723;s:10:\"size_after\";i:4723;s:4:\"time\";d:0.04;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:563;s:10:\"size_after\";i:563;s:4:\"time\";d:0.03;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5531;s:10:\"size_after\";i:5531;s:4:\"time\";d:0.01;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:15115;s:10:\"size_after\";i:15115;s:4:\"time\";d:0.07;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:963;s:10:\"size_after\";i:963;s:4:\"time\";d:0.02;}}}'),
(408,310,'_wxr_import_user_slug','admin'),
(409,310,'_athemes_sites_imported_post','1'),
(410,311,'_wp_attached_file','2021/07/Glamifiedviola.jpg'),
(411,311,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1050;s:6:\"height\";i:1260;s:4:\"file\";s:26:\"2021/07/Glamifiedviola.jpg\";s:8:\"filesize\";i:20702;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:26:\"Glamifiedviola-250x300.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2751;}s:5:\"large\";a:5:{s:4:\"file\";s:27:\"Glamifiedviola-853x1024.jpg\";s:5:\"width\";i:853;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16440;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:26:\"Glamifiedviola-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1393;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:26:\"Glamifiedviola-768x922.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:922;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:14073;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:27:\"Glamifiedviola-920x1104.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:1104;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18688;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:26:\"Glamifiedviola-575x690.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:690;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8870;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:26:\"Glamifiedviola-380x456.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:456;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4580;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:26:\"Glamifiedviola-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5439;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:26:\"Glamifiedviola-800x960.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:14873;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:26:\"Glamifiedviola-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:953;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(412,311,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:88000;s:10:\"size_after\";i:88000;s:4:\"time\";d:0.33999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2750;s:10:\"size_after\";i:2750;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:16324;s:10:\"size_after\";i:16324;s:4:\"time\";d:0.06;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1392;s:10:\"size_after\";i:1392;s:4:\"time\";d:0.04;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:13969;s:10:\"size_after\";i:13969;s:4:\"time\";d:0.04;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:18475;s:10:\"size_after\";i:18475;s:4:\"time\";d:0.02;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:8823;s:10:\"size_after\";i:8823;s:4:\"time\";d:0.04;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4586;s:10:\"size_after\";i:4586;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:554;s:10:\"size_after\";i:554;s:4:\"time\";d:0.02;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5413;s:10:\"size_after\";i:5413;s:4:\"time\";d:0.01;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:14762;s:10:\"size_after\";i:14762;s:4:\"time\";d:0.05;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:952;s:10:\"size_after\";i:952;s:4:\"time\";d:0.03;}}}'),
(413,311,'_wxr_import_user_slug','admin'),
(414,311,'_athemes_sites_imported_post','1'),
(415,315,'_wp_attached_file','2021/07/Allure.jpg'),
(416,315,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1050;s:6:\"height\";i:1260;s:4:\"file\";s:18:\"2021/07/Allure.jpg\";s:8:\"filesize\";i:30296;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:18:\"Allure-250x300.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2933;}s:5:\"large\";a:5:{s:4:\"file\";s:19:\"Allure-853x1024.jpg\";s:5:\"width\";i:853;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:22026;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"Allure-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1324;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:18:\"Allure-768x922.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:922;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18127;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:19:\"Allure-920x1104.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:1104;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:25378;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:18:\"Allure-575x690.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:690;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10812;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:18:\"Allure-380x456.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:456;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5525;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:18:\"Allure-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6409;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:18:\"Allure-800x960.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19845;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:18:\"Allure-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:800;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(417,315,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.060162735267527;s:5:\"bytes\";i:4446;s:11:\"size_before\";i:109503;s:10:\"size_after\";i:105057;s:4:\"time\";d:0.6100000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2942;s:10:\"size_after\";i:2942;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.05;s:5:\"bytes\";i:1062;s:11:\"size_before\";i:21010;s:10:\"size_after\";i:19948;s:4:\"time\";d:0.2;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1327;s:10:\"size_after\";i:1327;s:4:\"time\";d:0.03;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.05;s:5:\"bytes\";i:704;s:11:\"size_before\";i:17402;s:10:\"size_after\";i:16698;s:4:\"time\";d:0.03;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.4;s:5:\"bytes\";i:1298;s:11:\"size_before\";i:24059;s:10:\"size_after\";i:22761;s:4:\"time\";d:0.22;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.06;s:5:\"bytes\";i:326;s:11:\"size_before\";i:10641;s:10:\"size_after\";i:10315;s:4:\"time\";d:0.03;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.1;s:5:\"bytes\";i:61;s:11:\"size_before\";i:5522;s:10:\"size_after\";i:5461;s:4:\"time\";d:0.03;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:421;s:10:\"size_after\";i:421;s:4:\"time\";d:0.02;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.38;s:5:\"bytes\";i:88;s:11:\"size_before\";i:6396;s:10:\"size_after\";i:6308;s:4:\"time\";d:0.01;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.78;s:5:\"bytes\";i:907;s:11:\"size_before\";i:18988;s:10:\"size_after\";i:18081;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:795;s:10:\"size_after\";i:795;s:4:\"time\";d:0.01;}}}'),
(418,315,'_wxr_import_user_slug','admin'),
(419,315,'_athemes_sites_imported_post','1'),
(420,316,'_wp_attached_file','2021/07/Allure-1.jpg'),
(421,316,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1050;s:6:\"height\";i:1260;s:4:\"file\";s:20:\"2021/07/Allure-1.jpg\";s:8:\"filesize\";i:30296;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:20:\"Allure-1-250x300.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2933;}s:5:\"large\";a:5:{s:4:\"file\";s:21:\"Allure-1-853x1024.jpg\";s:5:\"width\";i:853;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:22026;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:20:\"Allure-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1324;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:20:\"Allure-1-768x922.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:922;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18127;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:21:\"Allure-1-920x1104.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:1104;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:25378;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:20:\"Allure-1-575x690.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:690;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10812;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:20:\"Allure-1-380x456.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:456;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5525;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:20:\"Allure-1-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6409;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:20:\"Allure-1-800x960.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19845;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:20:\"Allure-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:800;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(422,316,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.060162735267527;s:5:\"bytes\";i:4446;s:11:\"size_before\";i:109503;s:10:\"size_after\";i:105057;s:4:\"time\";d:0.42000000000000015;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2942;s:10:\"size_after\";i:2942;s:4:\"time\";d:0.03;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.05;s:5:\"bytes\";i:1062;s:11:\"size_before\";i:21010;s:10:\"size_after\";i:19948;s:4:\"time\";d:0.02;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1327;s:10:\"size_after\";i:1327;s:4:\"time\";d:0.02;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.05;s:5:\"bytes\";i:704;s:11:\"size_before\";i:17402;s:10:\"size_after\";i:16698;s:4:\"time\";d:0.07;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.4;s:5:\"bytes\";i:1298;s:11:\"size_before\";i:24059;s:10:\"size_after\";i:22761;s:4:\"time\";d:0.15;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.06;s:5:\"bytes\";i:326;s:11:\"size_before\";i:10641;s:10:\"size_after\";i:10315;s:4:\"time\";d:0.02;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.1;s:5:\"bytes\";i:61;s:11:\"size_before\";i:5522;s:10:\"size_after\";i:5461;s:4:\"time\";d:0.02;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:421;s:10:\"size_after\";i:421;s:4:\"time\";d:0.03;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.38;s:5:\"bytes\";i:88;s:11:\"size_before\";i:6396;s:10:\"size_after\";i:6308;s:4:\"time\";d:0.01;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.78;s:5:\"bytes\";i:907;s:11:\"size_before\";i:18988;s:10:\"size_after\";i:18081;s:4:\"time\";d:0.03;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:795;s:10:\"size_after\";i:795;s:4:\"time\";d:0.02;}}}'),
(423,316,'_wxr_import_user_slug','admin'),
(424,316,'_athemes_sites_imported_post','1'),
(425,317,'_wp_attached_file','2021/07/Maven.jpg'),
(426,317,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1050;s:6:\"height\";i:1260;s:4:\"file\";s:17:\"2021/07/Maven.jpg\";s:8:\"filesize\";i:42651;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"Maven-250x300.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4679;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"Maven-853x1024.jpg\";s:5:\"width\";i:853;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:32092;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"Maven-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2337;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"Maven-768x922.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:922;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:26469;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:18:\"Maven-920x1104.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:1104;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:36817;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:17:\"Maven-575x690.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:690;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16209;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:17:\"Maven-380x456.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:456;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8121;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:17:\"Maven-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9257;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:17:\"Maven-800x960.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:28586;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:17:\"Maven-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1467;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(427,317,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.21509601018206;s:5:\"bytes\";i:5229;s:11:\"size_before\";i:162639;s:10:\"size_after\";i:157410;s:4:\"time\";d:0.26000000000000006;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4683;s:10:\"size_after\";i:4683;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.3;s:5:\"bytes\";i:1334;s:11:\"size_before\";i:30998;s:10:\"size_after\";i:29664;s:4:\"time\";d:0.04;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2336;s:10:\"size_after\";i:2336;s:4:\"time\";d:0.01;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.48;s:5:\"bytes\";i:893;s:11:\"size_before\";i:25691;s:10:\"size_after\";i:24798;s:4:\"time\";d:0.02;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.63;s:5:\"bytes\";i:1649;s:11:\"size_before\";i:35589;s:10:\"size_after\";i:33940;s:4:\"time\";d:0.02;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.21;s:5:\"bytes\";i:354;s:11:\"size_before\";i:16018;s:10:\"size_after\";i:15664;s:4:\"time\";d:0.05;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:8120;s:10:\"size_after\";i:8120;s:4:\"time\";d:0.06;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:753;s:10:\"size_after\";i:753;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:9258;s:10:\"size_after\";i:9258;s:4:\"time\";d:0.01;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.6;s:5:\"bytes\";i:999;s:11:\"size_before\";i:27727;s:10:\"size_after\";i:26728;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1466;s:10:\"size_after\";i:1466;s:4:\"time\";d:0.01;}}}'),
(428,317,'_wxr_import_user_slug','admin'),
(429,317,'_athemes_sites_imported_post','1'),
(430,318,'_wp_attached_file','2021/07/Beaucoup.jpg'),
(431,318,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1050;s:6:\"height\";i:1260;s:4:\"file\";s:20:\"2021/07/Beaucoup.jpg\";s:8:\"filesize\";i:38583;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:20:\"Beaucoup-250x300.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4417;}s:5:\"large\";a:5:{s:4:\"file\";s:21:\"Beaucoup-853x1024.jpg\";s:5:\"width\";i:853;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:31618;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:20:\"Beaucoup-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1943;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:20:\"Beaucoup-768x922.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:922;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:27078;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:21:\"Beaucoup-920x1104.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:1104;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:35492;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:20:\"Beaucoup-575x690.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:690;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:17587;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:20:\"Beaucoup-380x456.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:456;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9261;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:20:\"Beaucoup-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10501;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:20:\"Beaucoup-800x960.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:29036;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:20:\"Beaucoup-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1203;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(432,318,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:2.1742378513414176;s:5:\"bytes\";i:3638;s:11:\"size_before\";i:167323;s:10:\"size_after\";i:163685;s:4:\"time\";d:0.33000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4415;s:10:\"size_after\";i:4415;s:4:\"time\";i:0;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.68;s:5:\"bytes\";i:833;s:11:\"size_before\";i:31137;s:10:\"size_after\";i:30304;s:4:\"time\";d:0.07;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1947;s:10:\"size_after\";i:1947;s:4:\"time\";d:0.01;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.67;s:5:\"bytes\";i:716;s:11:\"size_before\";i:26858;s:10:\"size_after\";i:26142;s:4:\"time\";d:0.04;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.72;s:5:\"bytes\";i:952;s:11:\"size_before\";i:34982;s:10:\"size_after\";i:34030;s:4:\"time\";d:0.1;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.35;s:5:\"bytes\";i:238;s:11:\"size_before\";i:17568;s:10:\"size_after\";i:17330;s:4:\"time\";d:0.01;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:9323;s:10:\"size_after\";i:9323;s:4:\"time\";d:0.02;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:677;s:10:\"size_after\";i:677;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.77;s:5:\"bytes\";i:81;s:11:\"size_before\";i:10514;s:10:\"size_after\";i:10433;s:4:\"time\";d:0.02;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.85;s:5:\"bytes\";i:818;s:11:\"size_before\";i:28703;s:10:\"size_after\";i:27885;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1199;s:10:\"size_after\";i:1199;s:4:\"time\";d:0.03;}}}'),
(433,318,'_wxr_import_user_slug','admin'),
(434,318,'_athemes_sites_imported_post','1'),
(435,319,'_wp_attached_file','2021/07/Pearlville-1.jpg'),
(436,319,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1050;s:6:\"height\";i:1260;s:4:\"file\";s:24:\"2021/07/Pearlville-1.jpg\";s:8:\"filesize\";i:21358;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:24:\"Pearlville-1-250x300.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3273;}s:5:\"large\";a:5:{s:4:\"file\";s:25:\"Pearlville-1-853x1024.jpg\";s:5:\"width\";i:853;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19168;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:24:\"Pearlville-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1702;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:24:\"Pearlville-1-768x922.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:922;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16375;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:25:\"Pearlville-1-920x1104.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:1104;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:21595;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:24:\"Pearlville-1-575x690.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:690;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10708;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:24:\"Pearlville-1-380x456.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:456;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5769;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:24:\"Pearlville-1-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6626;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:24:\"Pearlville-1-800x960.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:17421;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:24:\"Pearlville-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1112;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(437,319,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:0.21164826798629618;s:5:\"bytes\";i:278;s:11:\"size_before\";i:131350;s:10:\"size_after\";i:131072;s:4:\"time\";d:0.51;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3820;s:10:\"size_after\";i:3820;s:4:\"time\";d:0.03;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.48;s:5:\"bytes\";i:118;s:11:\"size_before\";i:24721;s:10:\"size_after\";i:24603;s:4:\"time\";d:0.03;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1899;s:10:\"size_after\";i:1899;s:4:\"time\";d:0.01;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.22;s:5:\"bytes\";i:47;s:11:\"size_before\";i:20890;s:10:\"size_after\";i:20843;s:4:\"time\";d:0.06;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.23;s:5:\"bytes\";i:64;s:11:\"size_before\";i:27893;s:10:\"size_after\";i:27829;s:4:\"time\";d:0.05;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:13230;s:10:\"size_after\";i:13230;s:4:\"time\";d:0.03;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:6954;s:10:\"size_after\";i:6954;s:4:\"time\";d:0.05;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:686;s:10:\"size_after\";i:686;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:7763;s:10:\"size_after\";i:7763;s:4:\"time\";d:0.03;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.22;s:5:\"bytes\";i:49;s:11:\"size_before\";i:22312;s:10:\"size_after\";i:22263;s:4:\"time\";d:0.2;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1182;s:10:\"size_after\";i:1182;s:4:\"time\";d:0.01;}}}'),
(438,319,'_wxr_import_user_slug','admin'),
(439,319,'_athemes_sites_imported_post','1'),
(440,320,'_wp_attached_file','2021/07/Klassichic.jpg'),
(441,320,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1050;s:6:\"height\";i:1260;s:4:\"file\";s:22:\"2021/07/Klassichic.jpg\";s:8:\"filesize\";i:37291;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:22:\"Klassichic-250x300.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5011;}s:5:\"large\";a:5:{s:4:\"file\";s:23:\"Klassichic-853x1024.jpg\";s:5:\"width\";i:853;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:28978;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:22:\"Klassichic-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2555;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:22:\"Klassichic-768x922.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:922;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:24784;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:23:\"Klassichic-920x1104.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:1104;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:32392;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:22:\"Klassichic-575x690.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:690;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16192;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:22:\"Klassichic-380x456.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:456;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8951;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:22:\"Klassichic-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9867;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:22:\"Klassichic-800x960.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:26382;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:22:\"Klassichic-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1606;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(442,320,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:157345;s:10:\"size_after\";i:157345;s:4:\"time\";d:0.42;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5031;s:10:\"size_after\";i:5031;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:28877;s:10:\"size_after\";i:28877;s:4:\"time\";d:0.04;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2568;s:10:\"size_after\";i:2568;s:4:\"time\";d:0.03;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:24679;s:10:\"size_after\";i:24679;s:4:\"time\";d:0.04;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:32378;s:10:\"size_after\";i:32378;s:4:\"time\";d:0.09;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:16202;s:10:\"size_after\";i:16202;s:4:\"time\";d:0.08;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:8970;s:10:\"size_after\";i:8970;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:832;s:10:\"size_after\";i:832;s:4:\"time\";d:0.03;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:9890;s:10:\"size_after\";i:9890;s:4:\"time\";d:0.01;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:26312;s:10:\"size_after\";i:26312;s:4:\"time\";d:0.06;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1606;s:10:\"size_after\";i:1606;s:4:\"time\";d:0.02;}}}'),
(443,320,'_wxr_import_user_slug','admin'),
(444,320,'_athemes_sites_imported_post','1'),
(445,323,'_wp_attached_file','2021/07/Rectangle-582-1.jpg'),
(446,323,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:510;s:6:\"height\";i:490;s:4:\"file\";s:27:\"2021/07/Rectangle-582-1.jpg\";s:8:\"filesize\";i:33064;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:27:\"Rectangle-582-1-300x288.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:288;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:13759;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:27:\"Rectangle-582-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5241;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:27:\"Rectangle-582-1-380x365.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:365;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19891;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:27:\"Rectangle-582-1-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:24472;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:27:\"Rectangle-582-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2968;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(447,323,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:1.3254786450662739;s:5:\"bytes\";i:900;s:11:\"size_before\";i:67900;s:10:\"size_after\";i:67000;s:4:\"time\";d:0.09;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:6:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.32;s:5:\"bytes\";i:183;s:11:\"size_before\";i:13847;s:10:\"size_after\";i:13664;s:4:\"time\";d:0.03;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5260;s:10:\"size_after\";i:5260;s:4:\"time\";d:0.01;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.65;s:5:\"bytes\";i:328;s:11:\"size_before\";i:19939;s:10:\"size_after\";i:19611;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1215;s:10:\"size_after\";i:1215;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.58;s:5:\"bytes\";i:389;s:11:\"size_before\";i:24670;s:10:\"size_after\";i:24281;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2969;s:10:\"size_after\";i:2969;s:4:\"time\";d:0.01;}}}'),
(448,323,'_wxr_import_user_slug','admin'),
(449,323,'_athemes_sites_imported_post','1'),
(450,325,'_wp_attached_file','2021/07/Rectangle-581-1.jpg'),
(451,325,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:510;s:6:\"height\";i:490;s:4:\"file\";s:27:\"2021/07/Rectangle-581-1.jpg\";s:8:\"filesize\";i:16452;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:27:\"Rectangle-581-1-300x288.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:288;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6842;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:27:\"Rectangle-581-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2756;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:27:\"Rectangle-581-1-380x365.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:365;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10109;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:27:\"Rectangle-581-1-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12622;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:27:\"Rectangle-581-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1657;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(452,325,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:34637;s:10:\"size_after\";i:34637;s:4:\"time\";d:0.29000000000000004;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:6:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:6817;s:10:\"size_after\";i:6817;s:4:\"time\";d:0.03;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2774;s:10:\"size_after\";i:2774;s:4:\"time\";d:0.01;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:10011;s:10:\"size_after\";i:10011;s:4:\"time\";d:0.05;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:836;s:10:\"size_after\";i:836;s:4:\"time\";d:0.05;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:12525;s:10:\"size_after\";i:12525;s:4:\"time\";d:0.15;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1674;s:10:\"size_after\";i:1674;s:4:\"time\";i:0;}}}'),
(453,325,'_wxr_import_user_slug','admin'),
(454,325,'_athemes_sites_imported_post','1'),
(455,326,'_wp_attached_file','2021/07/Rectangle-583-1.jpg'),
(456,326,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:510;s:6:\"height\";i:490;s:4:\"file\";s:27:\"2021/07/Rectangle-583-1.jpg\";s:8:\"filesize\";i:26930;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:27:\"Rectangle-583-1-300x288.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:288;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:11164;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:27:\"Rectangle-583-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4134;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:27:\"Rectangle-583-1-380x365.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:365;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16268;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:27:\"Rectangle-583-1-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20421;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:27:\"Rectangle-583-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2298;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(457,326,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:0.5375568222815499;s:5:\"bytes\";i:298;s:11:\"size_before\";i:55436;s:10:\"size_after\";i:55138;s:4:\"time\";d:0.18;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:6:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.03;s:5:\"bytes\";i:3;s:11:\"size_before\";i:11229;s:10:\"size_after\";i:11226;s:4:\"time\";d:0.03;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4166;s:10:\"size_after\";i:4166;s:4:\"time\";d:0.02;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.4;s:5:\"bytes\";i:65;s:11:\"size_before\";i:16346;s:10:\"size_after\";i:16281;s:4:\"time\";d:0.08;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:965;s:10:\"size_after\";i:965;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.13;s:5:\"bytes\";i:230;s:11:\"size_before\";i:20422;s:10:\"size_after\";i:20192;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2308;s:10:\"size_after\";i:2308;s:4:\"time\";d:0.02;}}}'),
(458,326,'_wxr_import_user_slug','admin'),
(459,326,'_athemes_sites_imported_post','1'),
(460,327,'_wp_attached_file','2021/07/Rectangle-584-1.jpg'),
(461,327,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:510;s:6:\"height\";i:490;s:4:\"file\";s:27:\"2021/07/Rectangle-584-1.jpg\";s:8:\"filesize\";i:13517;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:27:\"Rectangle-584-1-300x288.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:288;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6010;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:27:\"Rectangle-584-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2350;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:27:\"Rectangle-584-1-380x365.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:365;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8787;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:27:\"Rectangle-584-1-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10529;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:27:\"Rectangle-584-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1448;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(462,327,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:30223;s:10:\"size_after\";i:30223;s:4:\"time\";d:0.18000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:6:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:6080;s:10:\"size_after\";i:6080;s:4:\"time\";d:0.01;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2408;s:10:\"size_after\";i:2408;s:4:\"time\";d:0.03;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:8894;s:10:\"size_after\";i:8894;s:4:\"time\";d:0.01;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:736;s:10:\"size_after\";i:736;s:4:\"time\";d:0.03;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:10644;s:10:\"size_after\";i:10644;s:4:\"time\";d:0.07;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1461;s:10:\"size_after\";i:1461;s:4:\"time\";d:0.03;}}}'),
(463,327,'_wxr_import_user_slug','admin'),
(464,327,'_athemes_sites_imported_post','1'),
(465,353,'_wp_attached_file','2021/07/Heroc.jpg'),
(466,353,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:2048;s:6:\"height\";i:1138;s:4:\"file\";s:17:\"2021/07/Heroc.jpg\";s:8:\"filesize\";i:90519;s:5:\"sizes\";a:12:{s:6:\"medium\";a:5:{s:4:\"file\";s:17:\"Heroc-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4167;}s:5:\"large\";a:5:{s:4:\"file\";s:18:\"Heroc-1024x569.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:569;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:30522;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:17:\"Heroc-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2131;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:17:\"Heroc-768x427.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:427;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18644;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:18:\"Heroc-1536x854.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:854;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:60870;}s:18:\"botiga-extra-large\";a:5:{s:4:\"file\";s:18:\"Heroc-1140x633.jpg\";s:5:\"width\";i:1140;s:6:\"height\";i:633;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:37278;}s:12:\"botiga-large\";a:5:{s:4:\"file\";s:17:\"Heroc-920x511.jpg\";s:5:\"width\";i:920;s:6:\"height\";i:511;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:25400;}s:10:\"botiga-big\";a:5:{s:4:\"file\";s:17:\"Heroc-575x320.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:320;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:11652;}s:13:\"botiga-medium\";a:5:{s:4:\"file\";s:17:\"Heroc-380x211.jpg\";s:5:\"width\";i:380;s:6:\"height\";i:211;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5936;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:17:\"Heroc-420x420.jpg\";s:5:\"width\";i:420;s:6:\"height\";i:420;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10048;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:17:\"Heroc-800x445.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:445;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20308;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:17:\"Heroc-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1398;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(467,353,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.8036435038725864;s:5:\"bytes\";i:8717;s:11:\"size_before\";i:229175;s:10:\"size_after\";i:220458;s:4:\"time\";d:0.32000000000000006;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:13:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4161;s:10:\"size_after\";i:4161;s:4:\"time\";d:0.03;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.93;s:5:\"bytes\";i:1197;s:11:\"size_before\";i:30456;s:10:\"size_after\";i:29259;s:4:\"time\";d:0.02;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2145;s:10:\"size_after\";i:2145;s:4:\"time\";d:0.01;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.32;s:5:\"bytes\";i:621;s:11:\"size_before\";i:18700;s:10:\"size_after\";i:18079;s:4:\"time\";d:0.03;}s:9:\"1536x1536\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.33;s:5:\"bytes\";i:3243;s:11:\"size_before\";i:60790;s:10:\"size_after\";i:57547;s:4:\"time\";d:0.04;}s:18:\"botiga-extra-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.59;s:5:\"bytes\";i:1712;s:11:\"size_before\";i:37331;s:10:\"size_after\";i:35619;s:4:\"time\";d:0.02;}s:12:\"botiga-large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.74;s:5:\"bytes\";i:950;s:11:\"size_before\";i:25429;s:10:\"size_after\";i:24479;s:4:\"time\";d:0.02;}s:10:\"botiga-big\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.37;s:5:\"bytes\";i:276;s:11:\"size_before\";i:11670;s:10:\"size_after\";i:11394;s:4:\"time\";d:0.07;}s:13:\"botiga-medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:5935;s:10:\"size_after\";i:5935;s:4:\"time\";d:0.02;}s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:753;s:10:\"size_after\";i:753;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:10095;s:10:\"size_after\";i:10095;s:4:\"time\";d:0.01;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.54;s:5:\"bytes\";i:718;s:11:\"size_before\";i:20304;s:10:\"size_after\";i:19586;s:4:\"time\";d:0.01;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:1406;s:10:\"size_after\";i:1406;s:4:\"time\";d:0.03;}}}'),
(468,353,'_wxr_import_user_slug','admin'),
(469,353,'_athemes_sites_imported_post','1'),
(470,385,'_wp_attached_file','2021/12/favicon.png'),
(471,385,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:64;s:6:\"height\";i:64;s:4:\"file\";s:19:\"2021/12/favicon.png\";s:8:\"filesize\";i:1773;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(472,385,'wp-smpro-smush-data','a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:14.007782101167315;s:5:\"bytes\";i:288;s:11:\"size_before\";i:2056;s:10:\"size_after\";i:1768;s:4:\"time\";d:0.02;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:1:{s:19:\"botiga-header-icons\";O:8:\"stdClass\":5:{s:7:\"percent\";d:14.01;s:5:\"bytes\";i:288;s:11:\"size_before\";i:2056;s:10:\"size_after\";i:1768;s:4:\"time\";d:0.02;}}}'),
(473,385,'_wxr_import_user_slug','admin'),
(474,385,'_athemes_sites_imported_post','1'),
(475,386,'_elementor_edit_mode','builder'),
(476,386,'_elementor_template_type','kit'),
(477,386,'_wxr_import_user_slug','admin'),
(478,386,'_athemes_sites_imported_post','1'),
(479,387,'_botiga_hide_page_title','0'),
(480,387,'_botiga_disable_header_transparent','0'),
(481,387,'_botiga_page_builder_mode','0'),
(482,387,'_botiga_sidebar_layout',''),
(483,387,'_botiga_sidebar',''),
(484,387,'_wxr_import_user_slug','admin'),
(485,387,'_athemes_sites_imported_post','1'),
(486,388,'_wxr_import_user_slug','admin'),
(487,388,'_athemes_sites_imported_post','1'),
(488,389,'_wxr_import_user_slug','admin'),
(489,389,'_athemes_sites_imported_post','1'),
(490,390,'_wxr_import_user_slug','admin'),
(491,390,'_athemes_sites_imported_post','1'),
(492,391,'_botiga_hide_page_title','0'),
(493,391,'_botiga_disable_header_transparent','0'),
(494,391,'_botiga_page_builder_mode','1'),
(495,391,'_botiga_sidebar_layout',''),
(496,391,'_botiga_sidebar',''),
(497,391,'_elementor_edit_mode','builder'),
(498,391,'_elementor_template_type','wp-page'),
(499,391,'_elementor_version','3.6.7'),
(500,391,'_wp_page_template','elementor_header_footer'),
(501,391,'_elementor_data','[{\"id\":\"a53f34a\",\"elType\":\"section\",\"settings\":{\"layout\":\"full_width\",\"background_background\":\"classic\",\"background_image\":{\"url\":\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Hero.jpg\",\"id\":88,\"alt\":\"\",\"source\":\"library\"},\"background_position\":\"center center\",\"background_repeat\":\"no-repeat\",\"background_size\":\"cover\",\"padding\":{\"unit\":\"px\",\"top\":\"250\",\"right\":\"0\",\"bottom\":\"250\",\"left\":\"0\",\"isLinked\":false},\"background_position_mobile\":\"center center\",\"background_size_mobile\":\"cover\",\"padding_tablet\":{\"unit\":\"px\",\"top\":\"0100\",\"right\":\"0\",\"bottom\":\"100\",\"left\":\"0\",\"isLinked\":false}},\"elements\":[{\"id\":\"56314a8\",\"elType\":\"column\",\"settings\":{\"_column_size\":100,\"_inline_size\":null},\"elements\":[{\"id\":\"f0fbbd4\",\"elType\":\"section\",\"settings\":{\"structure\":\"20\"},\"elements\":[{\"id\":\"77f1ba6\",\"elType\":\"column\",\"settings\":{\"_column_size\":50,\"_inline_size\":56},\"elements\":[{\"id\":\"dbae005\",\"elType\":\"widget\",\"settings\":{\"title\":\"Headline that grabs people\'s attention\",\"header_size\":\"h1\",\"title_color\":\"#212121\",\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_size\":{\"unit\":\"px\",\"size\":65,\"sizes\":[]},\"typography_font_weight\":\"400\",\"typography_font_size_tablet\":{\"unit\":\"px\",\"size\":40,\"sizes\":[]},\"typography_font_size_mobile\":{\"unit\":\"px\",\"size\":32,\"sizes\":[]},\"_animation\":\"fadeInUpShorter\",\"_animation_delay\":200},\"elements\":[],\"widgetType\":\"heading\"},{\"id\":\"87aedb5\",\"elType\":\"widget\",\"settings\":{\"text\":\"JETZT EINKAUFEN\",\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_weight\":\"400\",\"typography_text_decoration\":\"none\",\"button_text_color\":\"#FFFFFF\",\"background_color\":\"#212121\",\"button_background_hover_color\":\"#757575\",\"border_radius\":{\"unit\":\"px\",\"top\":\"0\",\"right\":\"0\",\"bottom\":\"0\",\"left\":\"0\",\"isLinked\":true},\"text_padding\":{\"unit\":\"px\",\"top\":\"15\",\"right\":\"24\",\"bottom\":\"15\",\"left\":\"24\",\"isLinked\":false},\"_margin\":{\"unit\":\"px\",\"top\":\"12\",\"right\":\"0\",\"bottom\":\"0\",\"left\":\"0\",\"isLinked\":false},\"link\":{\"url\":\"http:\\/\\/localhost:8090\\/shop\\/\",\"is_external\":\"\",\"nofollow\":\"\",\"custom_attributes\":\"\"},\"_animation\":\"fadeInUpShorter\",\"_animation_delay\":400},\"elements\":[],\"widgetType\":\"button\"}],\"isInner\":true},{\"id\":\"ffe626f\",\"elType\":\"column\",\"settings\":{\"_column_size\":50,\"_inline_size\":44},\"elements\":[],\"isInner\":true}],\"isInner\":true}],\"isInner\":false}],\"isInner\":false},{\"id\":\"cc4ba2a\",\"elType\":\"section\",\"settings\":{\"padding\":{\"unit\":\"px\",\"top\":\"120\",\"right\":\"0\",\"bottom\":\"120\",\"left\":\"0\",\"isLinked\":false},\"padding_tablet\":{\"unit\":\"px\",\"top\":\"60\",\"right\":\"0\",\"bottom\":\"60\",\"left\":\"0\",\"isLinked\":false}},\"elements\":[{\"id\":\"e654a9e\",\"elType\":\"column\",\"settings\":{\"_column_size\":100,\"_inline_size\":null},\"elements\":[{\"id\":\"cfaddff\",\"elType\":\"widget\",\"settings\":{\"title\":\"Empfohlen Collection\",\"align\":\"center\",\"title_color\":\"#212121\",\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_size\":{\"unit\":\"px\",\"size\":32,\"sizes\":[]},\"typography_font_weight\":\"400\",\"_animation\":\"fadeInUpShorter\",\"_animation_delay\":200},\"elements\":[],\"widgetType\":\"heading\"},{\"id\":\"befef59\",\"elType\":\"widget\",\"settings\":{\"editor\":\"<p>A powerful headline about your product\\u2019s features to give focus to your chosen product collection<\\/p>\",\"align\":\"center\",\"_margin\":{\"unit\":\"px\",\"top\":\"0\",\"right\":\"0\",\"bottom\":\"-25\",\"left\":\"0\",\"isLinked\":false},\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_weight\":\"400\",\"_animation\":\"fadeInUpShorter\",\"_animation_delay\":400},\"elements\":[],\"widgetType\":\"text-editor\"},{\"id\":\"908745f\",\"elType\":\"widget\",\"settings\":{\"shortcode\":\"[products columns=\\\"3\\\" limit=\\\"3\\\"]\",\"_animation\":\"fadeInUpShorter\",\"_animation_delay\":600},\"elements\":[],\"widgetType\":\"shortcode\"}],\"isInner\":false}],\"isInner\":false},{\"id\":\"5291af9\",\"elType\":\"section\",\"settings\":{\"layout\":\"full_width\",\"background_background\":\"classic\",\"background_image\":{\"url\":\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Mask-Group-1-1.jpg\",\"id\":49,\"alt\":\"\",\"source\":\"library\"},\"background_position\":\"center center\",\"background_repeat\":\"no-repeat\",\"background_size\":\"cover\",\"padding\":{\"unit\":\"px\",\"top\":\"180\",\"right\":\"0\",\"bottom\":\"180\",\"left\":\"0\",\"isLinked\":false},\"padding_mobile\":{\"unit\":\"px\",\"top\":\"70\",\"right\":\"0\",\"bottom\":\"70\",\"left\":\"0\",\"isLinked\":false}},\"elements\":[{\"id\":\"0eb56ce\",\"elType\":\"column\",\"settings\":{\"_column_size\":100,\"_inline_size\":null},\"elements\":[{\"id\":\"9b2fd73\",\"elType\":\"section\",\"settings\":[],\"elements\":[{\"id\":\"8a88a77\",\"elType\":\"column\",\"settings\":{\"_column_size\":100,\"_inline_size\":null},\"elements\":[{\"id\":\"c8a29d4\",\"elType\":\"widget\",\"settings\":{\"title\":\"Highlighted Section\",\"align\":\"center\",\"title_color\":\"#212121\",\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_size\":{\"unit\":\"px\",\"size\":32,\"sizes\":[]},\"typography_font_weight\":\"400\",\"_animation\":\"fadeInUpShorter\",\"_animation_delay\":200},\"elements\":[],\"widgetType\":\"heading\"},{\"id\":\"d80abce\",\"elType\":\"widget\",\"settings\":{\"editor\":\"<p><span style=\\\"color: #212121; font-family: Inter, sans-serif;\\\">What differentiates you from the competition? Use this section to talk about it. Don\\u2019t forget to talk about the benefits.<\\/span><\\/p>\",\"align\":\"center\",\"_margin\":{\"unit\":\"px\",\"top\":\"0\",\"right\":\"0\",\"bottom\":\"-25\",\"left\":\"0\",\"isLinked\":false},\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_weight\":\"400\",\"_animation\":\"fadeInUpShorter\",\"_animation_delay\":400},\"elements\":[],\"widgetType\":\"text-editor\"},{\"id\":\"39ef610\",\"elType\":\"widget\",\"settings\":{\"text\":\"JETZT EINKAUFEN\",\"align\":\"center\",\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_weight\":\"400\",\"typography_text_decoration\":\"none\",\"button_text_color\":\"#FFFFFF\",\"background_color\":\"#212121\",\"button_background_hover_color\":\"#757575\",\"border_radius\":{\"unit\":\"px\",\"top\":\"0\",\"right\":\"0\",\"bottom\":\"0\",\"left\":\"0\",\"isLinked\":true},\"text_padding\":{\"unit\":\"px\",\"top\":\"15\",\"right\":\"24\",\"bottom\":\"15\",\"left\":\"24\",\"isLinked\":false},\"_margin\":{\"unit\":\"px\",\"top\":\"0\",\"right\":\"0\",\"bottom\":\"0\",\"left\":\"0\",\"isLinked\":false},\"link\":{\"url\":\"http:\\/\\/localhost:8090\\/shop\\/\",\"is_external\":\"\",\"nofollow\":\"\",\"custom_attributes\":\"\"},\"_animation\":\"fadeInUpShorter\",\"_animation_delay\":600},\"elements\":[],\"widgetType\":\"button\"}],\"isInner\":true}],\"isInner\":true}],\"isInner\":false}],\"isInner\":false},{\"id\":\"398a725\",\"elType\":\"section\",\"settings\":{\"padding\":{\"unit\":\"px\",\"top\":\"120\",\"right\":\"0\",\"bottom\":\"120\",\"left\":\"0\",\"isLinked\":false},\"padding_tablet\":{\"unit\":\"px\",\"top\":\"70\",\"right\":\"0\",\"bottom\":\"70\",\"left\":\"0\",\"isLinked\":false}},\"elements\":[{\"id\":\"433c458\",\"elType\":\"column\",\"settings\":{\"_column_size\":100,\"_inline_size\":null},\"elements\":[{\"id\":\"52f8025\",\"elType\":\"widget\",\"settings\":{\"title\":\"Empfohlen Categories\",\"align\":\"center\",\"title_color\":\"#212121\",\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_size\":{\"unit\":\"px\",\"size\":32,\"sizes\":[]},\"typography_font_weight\":\"400\",\"_animation\":\"fadeInUpShorter\",\"_animation_delay\":200},\"elements\":[],\"widgetType\":\"heading\"},{\"id\":\"dc93279\",\"elType\":\"widget\",\"settings\":{\"editor\":\"<p><span style=\\\"color: #212121; font-family: Inter, sans-serif;\\\">Entdecke unsere Kollektion natürlicher Pflegeprodukte. Select imagery and name that relates to the product category.<\\/span><\\/p>\",\"align\":\"center\",\"_margin\":{\"unit\":\"px\",\"top\":\"0\",\"right\":\"0\",\"bottom\":\"-25\",\"left\":\"0\",\"isLinked\":false},\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_weight\":\"400\",\"_padding_tablet\":{\"unit\":\"px\",\"top\":\"0\",\"right\":\"80\",\"bottom\":\"0\",\"left\":\"80\",\"isLinked\":false},\"_padding_mobile\":{\"unit\":\"px\",\"top\":\"0\",\"right\":\"0\",\"bottom\":\"0\",\"left\":\"0\",\"isLinked\":false},\"_animation\":\"fadeInUpShorter\",\"_animation_delay\":400},\"elements\":[],\"widgetType\":\"text-editor\"},{\"id\":\"a19ffd5\",\"elType\":\"section\",\"settings\":{\"structure\":\"40\",\"animation\":\"fadeInUpShorter\",\"animation_delay\":600},\"elements\":[{\"id\":\"9b22770\",\"elType\":\"column\",\"settings\":{\"_column_size\":25,\"_inline_size\":null},\"elements\":[{\"id\":\"3fcfc89\",\"elType\":\"widget\",\"settings\":{\"image\":{\"url\":\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-581-1.jpg\",\"id\":325,\"alt\":\"\",\"source\":\"library\"},\"caption_source\":\"custom\",\"caption\":\"Makeup\",\"link_to\":\"custom\",\"link\":{\"url\":\"http:\\/\\/localhost:8090\\/product-category\\/cosmetics\\/\",\"is_external\":\"\",\"nofollow\":\"\",\"custom_attributes\":\"\"}},\"elements\":[],\"widgetType\":\"image\"}],\"isInner\":true},{\"id\":\"2570323\",\"elType\":\"column\",\"settings\":{\"_column_size\":25,\"_inline_size\":null,\"background_hover_transition\":{\"unit\":\"px\",\"size\":\"\",\"sizes\":[]}},\"elements\":[{\"id\":\"bd8f9cc\",\"elType\":\"widget\",\"settings\":{\"image\":{\"url\":\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-582-1.jpg\",\"id\":323,\"alt\":\"\",\"source\":\"library\"},\"caption_source\":\"custom\",\"caption\":\"Lipstick\",\"link_to\":\"custom\",\"link\":{\"url\":\"http:\\/\\/localhost:8090\\/product-category\\/cosmetics\\/\",\"is_external\":\"\",\"nofollow\":\"\",\"custom_attributes\":\"\"}},\"elements\":[],\"widgetType\":\"image\"}],\"isInner\":true},{\"id\":\"1b2f266\",\"elType\":\"column\",\"settings\":{\"_column_size\":25,\"_inline_size\":null},\"elements\":[{\"id\":\"ae7a6ae\",\"elType\":\"widget\",\"settings\":{\"image\":{\"url\":\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-583-1.jpg\",\"id\":326,\"alt\":\"\",\"source\":\"library\"},\"caption_source\":\"custom\",\"caption\":\"Bath Products\",\"link_to\":\"custom\",\"link\":{\"url\":\"http:\\/\\/localhost:8090\\/product-category\\/cosmetics\\/\",\"is_external\":\"\",\"nofollow\":\"\",\"custom_attributes\":\"\"}},\"elements\":[],\"widgetType\":\"image\"}],\"isInner\":true},{\"id\":\"b4c83e4\",\"elType\":\"column\",\"settings\":{\"_column_size\":25,\"_inline_size\":null},\"elements\":[{\"id\":\"7404df9\",\"elType\":\"widget\",\"settings\":{\"image\":{\"url\":\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-584-1.jpg\",\"id\":327,\"alt\":\"\",\"source\":\"library\"},\"caption_source\":\"custom\",\"caption\":\"Treatments\",\"link_to\":\"custom\",\"link\":{\"url\":\"http:\\/\\/localhost:8090\\/product-category\\/cosmetics\\/\",\"is_external\":\"\",\"nofollow\":\"\",\"custom_attributes\":\"\"}},\"elements\":[],\"widgetType\":\"image\"}],\"isInner\":true}],\"isInner\":true}],\"isInner\":false}],\"isInner\":false}]'),
(503,391,'_wxr_import_user_slug','admin'),
(504,391,'_wxr_import_has_attachment_refs','1'),
(505,391,'_athemes_sites_imported_post','1'),
(514,392,'_wxr_import_user_slug','admin'),
(515,392,'_athemes_sites_imported_post','1'),
(516,393,'_botiga_hide_page_title','0'),
(517,393,'_botiga_disable_header_transparent','0'),
(518,393,'_botiga_page_builder_mode','0'),
(519,393,'_botiga_sidebar_layout',''),
(520,393,'_botiga_sidebar',''),
(521,393,'_wxr_import_user_slug','admin'),
(522,393,'_athemes_sites_imported_post','1'),
(523,438,'wpforms_form_locations','a:1:{i:0;a:6:{s:4:\"type\";s:4:\"page\";s:5:\"title\";s:7:\"Kontakt\";s:7:\"form_id\";i:438;s:2:\"id\";i:394;s:6:\"status\";s:7:\"publish\";s:3:\"url\";s:9:\"/kontakt/\";}}'),
(524,394,'_botiga_hide_page_title','0'),
(525,394,'_botiga_disable_header_transparent','0'),
(526,394,'_botiga_page_builder_mode','1'),
(527,394,'_botiga_sidebar_layout',''),
(528,394,'_botiga_sidebar',''),
(529,394,'_elementor_edit_mode','builder'),
(530,394,'_elementor_template_type','wp-page'),
(531,394,'_elementor_version','3.6.7'),
(532,394,'_wp_page_template','elementor_header_footer'),
(533,394,'_elementor_data','[{\"id\":\"c275639\",\"elType\":\"section\",\"settings\":{\"padding\":{\"unit\":\"px\",\"top\":\"90\",\"right\":\"0\",\"bottom\":\"30\",\"left\":\"0\",\"isLinked\":false},\"padding_mobile\":{\"unit\":\"px\",\"top\":\"030\",\"right\":\"0\",\"bottom\":\"020\",\"left\":\"0\",\"isLinked\":false}},\"elements\":[{\"id\":\"0d095d2\",\"elType\":\"column\",\"settings\":{\"_column_size\":100,\"_inline_size\":null},\"elements\":[{\"id\":\"55a89d3\",\"elType\":\"widget\",\"settings\":{\"title\":\"Kontakt\",\"align\":\"center\",\"title_color\":\"#212121\",\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_size\":{\"unit\":\"px\",\"size\":64,\"sizes\":[]},\"typography_font_weight\":\"400\",\"typography_font_size_mobile\":{\"unit\":\"px\",\"size\":49,\"sizes\":[]},\"_animation\":\"fadeInUpShorter\",\"_animation_delay\":200},\"elements\":[],\"widgetType\":\"heading\"}],\"isInner\":false}],\"isInner\":false},{\"id\":\"6c09bab\",\"elType\":\"section\",\"settings\":{\"margin\":{\"unit\":\"px\",\"top\":\"0\",\"right\":0,\"bottom\":\"30\",\"left\":0,\"isLinked\":false},\"animation\":\"fadeInUpShorter\",\"animation_delay\":400},\"elements\":[{\"id\":\"801eab6\",\"elType\":\"column\",\"settings\":{\"_column_size\":100,\"_inline_size\":null},\"elements\":[{\"id\":\"fd0eb9d\",\"elType\":\"widget\",\"settings\":{\"address\":\"Friedrichstraße 100, 10117 Berlin, Deutschland\",\"height\":{\"unit\":\"px\",\"size\":474,\"sizes\":[]},\"height_tablet\":{\"unit\":\"px\",\"size\":315,\"sizes\":[]},\"height_mobile\":{\"unit\":\"px\",\"size\":199,\"sizes\":[]}},\"elements\":[],\"widgetType\":\"google_maps\"}],\"isInner\":false}],\"isInner\":false},{\"id\":\"963138c\",\"elType\":\"section\",\"settings\":{\"structure\":\"20\",\"animation\":\"fadeInUpShorter\",\"animation_delay\":600},\"elements\":[{\"id\":\"d2566ee\",\"elType\":\"column\",\"settings\":{\"_column_size\":50,\"_inline_size\":58},\"elements\":[{\"id\":\"622e931\",\"elType\":\"widget\",\"settings\":{\"title\":\"Leave Us a Message\",\"title_color\":\"#212121\",\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_size\":{\"unit\":\"px\",\"size\":32,\"sizes\":[]},\"typography_font_weight\":\"400\"},\"elements\":[],\"widgetType\":\"heading\"},{\"id\":\"596537d\",\"elType\":\"widget\",\"settings\":{\"form_id\":\"438\"},\"elements\":[],\"widgetType\":\"wpforms\"}],\"isInner\":false},{\"id\":\"dfa68f3\",\"elType\":\"column\",\"settings\":{\"_column_size\":50,\"_inline_size\":42},\"elements\":[{\"id\":\"449cc41\",\"elType\":\"widget\",\"settings\":{\"title\":\"Unser Geschäft\",\"title_color\":\"#212121\",\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_size\":{\"unit\":\"px\",\"size\":32,\"sizes\":[]},\"typography_font_weight\":\"400\"},\"elements\":[],\"widgetType\":\"heading\"},{\"id\":\"87e82a1\",\"elType\":\"widget\",\"settings\":{\"editor\":\"<p style=\\\"box-sizing: inherit; color: #212121; font-family: Inter, sans-serif;\\\">Friedrichstraße 100, 10117 Berlin, Deutschland<\\/p><p style=\\\"box-sizing: inherit; color: #212121; font-family: Inter, sans-serif;\\\">PHONE:<br \\/><span style=\\\"font-weight: var( --e-global-typography-text-font-weight ); letter-spacing: 0px;\\\">+49 30 901820<\\/span><\\/p><p style=\\\"box-sizing: inherit; color: #212121; font-family: Inter, sans-serif;\\\">E-MAIL:<br \\/><span style=\\\"font-weight: var( --e-global-typography-text-font-weight ); letter-spacing: 0px;\\\">kontakt@cocolo-berlin.de<\\/span><\\/p>\",\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_weight\":\"400\"},\"elements\":[],\"widgetType\":\"text-editor\"},{\"id\":\"cbfd614\",\"elType\":\"widget\",\"settings\":{\"title\":\"Store Hours\",\"title_color\":\"#212121\",\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_size\":{\"unit\":\"px\",\"size\":32,\"sizes\":[]},\"typography_font_weight\":\"400\"},\"elements\":[],\"widgetType\":\"heading\"},{\"id\":\"769cb96\",\"elType\":\"widget\",\"settings\":{\"editor\":\"<p style=\\\"box-sizing: inherit; color: #212121; font-family: Inter, sans-serif;\\\">Sun: Closed<br \\/><span style=\\\"font-weight: var( --e-global-typography-text-font-weight ); letter-spacing: 0px;\\\">Mon to Sat: 10 AM \\u2013 5:30 PM<\\/span><\\/p>\",\"typography_typography\":\"custom\",\"typography_font_family\":\"Inter\",\"typography_font_weight\":\"400\"},\"elements\":[],\"widgetType\":\"text-editor\"}],\"isInner\":false}],\"isInner\":false},{\"id\":\"d502af4\",\"elType\":\"section\",\"settings\":[],\"elements\":[{\"id\":\"4bef3e5\",\"elType\":\"column\",\"settings\":{\"_column_size\":100,\"_inline_size\":null},\"elements\":[{\"id\":\"de863e8\",\"elType\":\"widget\",\"settings\":{\"space\":{\"unit\":\"px\",\"size\":90,\"sizes\":[]}},\"elements\":[],\"widgetType\":\"spacer\"}],\"isInner\":false,\"url\":\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/woocommerce-placeholder.png\"}],\"isInner\":false}]'),
(535,394,'_wxr_import_user_slug','admin'),
(536,394,'_athemes_sites_imported_post','1'),
(537,395,'_menu_item_type','post_type'),
(538,395,'_menu_item_menu_item_parent','0'),
(539,395,'_menu_item_object_id','391'),
(540,395,'_menu_item_object','page'),
(541,395,'_menu_item_target',''),
(542,395,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(543,395,'_menu_item_xfn',''),
(544,395,'_menu_item_url',''),
(545,395,'_wp_old_date','2022-10-19'),
(546,395,'_wxr_import_user_slug','admin'),
(547,395,'_athemes_sites_imported_post','1'),
(548,396,'_menu_item_type','post_type'),
(549,396,'_menu_item_menu_item_parent','0'),
(550,396,'_menu_item_object_id','393'),
(551,396,'_menu_item_object','page'),
(552,396,'_menu_item_target',''),
(553,396,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(554,396,'_menu_item_xfn',''),
(555,396,'_menu_item_url',''),
(556,396,'_wp_old_date','2022-10-19'),
(557,396,'_wxr_import_user_slug','admin'),
(558,396,'_athemes_sites_imported_post','1'),
(559,397,'_menu_item_type','post_type'),
(560,397,'_menu_item_menu_item_parent','0'),
(561,397,'_menu_item_object_id','394'),
(562,397,'_menu_item_object','page'),
(563,397,'_menu_item_target',''),
(564,397,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(565,397,'_menu_item_xfn',''),
(566,397,'_menu_item_url',''),
(567,397,'_wp_old_date','2022-10-19'),
(568,397,'_wxr_import_user_slug','admin'),
(569,397,'_athemes_sites_imported_post','1'),
(570,398,'_menu_item_type','post_type'),
(571,398,'_menu_item_menu_item_parent','0'),
(572,398,'_menu_item_object_id','387'),
(573,398,'_menu_item_object','page'),
(574,398,'_menu_item_target',''),
(575,398,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(576,398,'_menu_item_xfn',''),
(577,398,'_menu_item_url',''),
(578,398,'_wp_old_date','2022-10-19'),
(579,398,'_wxr_import_user_slug','admin'),
(580,398,'_athemes_sites_imported_post','1'),
(581,399,'_menu_item_type','post_type'),
(582,399,'_menu_item_menu_item_parent','0'),
(583,399,'_menu_item_object_id','391'),
(584,399,'_menu_item_object','page'),
(585,399,'_menu_item_target',''),
(586,399,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(587,399,'_menu_item_xfn',''),
(588,399,'_menu_item_url',''),
(589,399,'_wxr_import_user_slug','admin'),
(590,399,'_athemes_sites_imported_post','1'),
(591,400,'_menu_item_type','post_type'),
(592,400,'_menu_item_menu_item_parent','0'),
(593,400,'_menu_item_object_id','393'),
(594,400,'_menu_item_object','page'),
(595,400,'_menu_item_target',''),
(596,400,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(597,400,'_menu_item_xfn',''),
(598,400,'_menu_item_url',''),
(599,400,'_wxr_import_user_slug','admin'),
(600,400,'_athemes_sites_imported_post','1'),
(601,401,'_menu_item_type','post_type'),
(602,401,'_menu_item_menu_item_parent','0'),
(603,401,'_menu_item_object_id','387'),
(604,401,'_menu_item_object','page'),
(605,401,'_menu_item_target',''),
(606,401,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(607,401,'_menu_item_xfn',''),
(608,401,'_menu_item_url',''),
(609,401,'_wxr_import_user_slug','admin'),
(610,401,'_athemes_sites_imported_post','1'),
(611,402,'_menu_item_type','custom'),
(612,402,'_menu_item_menu_item_parent','0'),
(613,402,'_menu_item_object_id','402'),
(614,402,'_menu_item_object','custom'),
(615,402,'_menu_item_target',''),
(616,402,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(617,402,'_menu_item_xfn',''),
(618,402,'_menu_item_url','#'),
(619,402,'_wxr_import_user_slug','admin'),
(620,402,'_athemes_sites_imported_post','1'),
(621,403,'_menu_item_type','custom'),
(622,403,'_menu_item_menu_item_parent','0'),
(623,403,'_menu_item_object_id','403'),
(624,403,'_menu_item_object','custom'),
(625,403,'_menu_item_target',''),
(626,403,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(627,403,'_menu_item_xfn',''),
(628,403,'_menu_item_url','#'),
(629,403,'_wxr_import_user_slug','admin'),
(630,403,'_athemes_sites_imported_post','1'),
(631,404,'_menu_item_type','custom'),
(632,404,'_menu_item_menu_item_parent','0'),
(633,404,'_menu_item_object_id','404'),
(634,404,'_menu_item_object','custom'),
(635,404,'_menu_item_target',''),
(636,404,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(637,404,'_menu_item_xfn',''),
(638,404,'_menu_item_url','#'),
(639,404,'_wxr_import_user_slug','admin'),
(640,404,'_athemes_sites_imported_post','1'),
(641,405,'_wxr_import_user_slug','admin'),
(642,405,'_wxr_import_term','a:3:{s:8:\"taxonomy\";s:8:\"wp_theme\";s:4:\"slug\";s:6:\"botiga\";s:4:\"name\";s:6:\"botiga\";}'),
(643,405,'_athemes_sites_imported_post','1'),
(644,31,'total_sales','142'),
(645,31,'_tax_status','taxable'),
(646,31,'_tax_class',''),
(647,31,'_manage_stock','no'),
(648,31,'_backorders','no'),
(649,31,'_sold_individually','no'),
(650,31,'_virtual','no'),
(651,31,'_downloadable','no'),
(652,31,'_download_limit','-1'),
(653,31,'_download_expiry','-1'),
(654,31,'_stock_status','instock'),
(655,31,'_wc_average_rating','4.46'),
(656,31,'_wc_review_count','35'),
(657,31,'_product_version','9.5.1'),
(658,31,'_botiga_page_builder_mode','0'),
(659,31,'_botiga_sidebar_layout','customizer'),
(660,31,'_regular_price','14'),
(661,31,'_price','14'),
(662,31,'_thumbnail_id','316'),
(663,31,'_stock',''),
(664,31,'_wxr_import_user_slug','admin'),
(665,31,'_athemes_sites_imported_post','1'),
(666,40,'_regular_price','21'),
(667,40,'total_sales','168'),
(668,40,'_tax_status','taxable'),
(669,40,'_tax_class',''),
(670,40,'_manage_stock','no'),
(671,40,'_backorders','no'),
(672,40,'_sold_individually','no'),
(673,40,'_virtual','no'),
(674,40,'_downloadable','no'),
(675,40,'_download_limit','-1'),
(676,40,'_download_expiry','-1'),
(677,40,'_stock',''),
(678,40,'_stock_status','instock'),
(679,40,'_wc_average_rating','4.71'),
(680,40,'_wc_review_count','34'),
(681,40,'_product_version','9.5.1'),
(682,40,'_price','18'),
(683,40,'_botiga_page_builder_mode','0'),
(684,40,'_botiga_sidebar_layout','customizer'),
(685,40,'_sale_price','18'),
(686,40,'_thumbnail_id','249'),
(687,40,'_wxr_import_user_slug','admin'),
(688,40,'_athemes_sites_imported_post','1'),
(689,42,'_regular_price','14'),
(690,42,'total_sales','121'),
(691,42,'_tax_status','taxable'),
(692,42,'_tax_class',''),
(693,42,'_manage_stock','no'),
(694,42,'_backorders','no'),
(695,42,'_sold_individually','no'),
(696,42,'_virtual','no'),
(697,42,'_downloadable','no'),
(698,42,'_download_limit','-1'),
(699,42,'_download_expiry','-1'),
(700,42,'_stock',''),
(701,42,'_stock_status','instock'),
(702,42,'_wc_average_rating','4.68'),
(703,42,'_wc_review_count','31'),
(704,42,'_product_version','9.5.1'),
(705,42,'_price','14'),
(706,42,'_botiga_page_builder_mode','0'),
(707,42,'_botiga_sidebar_layout','customizer'),
(708,42,'_thumbnail_id','315'),
(709,42,'_wxr_import_user_slug','admin'),
(710,42,'_athemes_sites_imported_post','1'),
(711,93,'_regular_price','14'),
(712,93,'total_sales','53'),
(713,93,'_tax_status','taxable'),
(714,93,'_tax_class',''),
(715,93,'_manage_stock','no'),
(716,93,'_backorders','no'),
(717,93,'_sold_individually','no'),
(718,93,'_virtual','no'),
(719,93,'_downloadable','no'),
(720,93,'_download_limit','-1'),
(721,93,'_download_expiry','-1'),
(722,93,'_stock',''),
(723,93,'_stock_status','instock'),
(724,93,'_wc_average_rating','4.47'),
(725,93,'_wc_review_count','15'),
(726,93,'_product_version','9.5.1'),
(727,93,'_price','14'),
(728,93,'_botiga_page_builder_mode','0'),
(729,93,'_botiga_sidebar_layout','customizer'),
(730,93,'_thumbnail_id','319'),
(731,93,'_wxr_import_user_slug','admin'),
(732,93,'_athemes_sites_imported_post','1'),
(733,94,'_regular_price','14'),
(734,94,'total_sales','130'),
(735,94,'_tax_status','taxable'),
(736,94,'_tax_class',''),
(737,94,'_manage_stock','no'),
(738,94,'_backorders','no'),
(739,94,'_sold_individually','no'),
(740,94,'_virtual','no'),
(741,94,'_downloadable','no'),
(742,94,'_download_limit','-1'),
(743,94,'_download_expiry','-1'),
(744,94,'_stock',''),
(745,94,'_stock_status','instock'),
(746,94,'_wc_average_rating','4.63'),
(747,94,'_wc_review_count','32'),
(748,94,'_product_version','9.5.1'),
(749,94,'_price','14'),
(750,94,'_botiga_page_builder_mode','0'),
(751,94,'_botiga_sidebar_layout','customizer'),
(752,94,'_thumbnail_id','317'),
(753,94,'_wxr_import_user_slug','admin'),
(754,94,'_athemes_sites_imported_post','1'),
(755,95,'_regular_price','21'),
(756,95,'total_sales','64'),
(757,95,'_tax_status','taxable'),
(758,95,'_tax_class',''),
(759,95,'_manage_stock','no'),
(760,95,'_backorders','no'),
(761,95,'_sold_individually','no'),
(762,95,'_virtual','no'),
(763,95,'_downloadable','no'),
(764,95,'_download_limit','-1'),
(765,95,'_download_expiry','-1'),
(766,95,'_stock',''),
(767,95,'_stock_status','instock'),
(768,95,'_wc_average_rating','4.80'),
(769,95,'_wc_review_count','20'),
(770,95,'_product_version','9.5.1'),
(771,95,'_price','21'),
(772,95,'_botiga_page_builder_mode','0'),
(773,95,'_botiga_sidebar_layout','customizer'),
(774,95,'_product_image_gallery','171,172,310'),
(775,95,'_thumbnail_id','311'),
(776,95,'_wxr_import_user_slug','admin'),
(777,95,'_athemes_sites_imported_post','1'),
(778,96,'_regular_price','14'),
(779,96,'total_sales','98'),
(780,96,'_tax_status','taxable'),
(781,96,'_tax_class',''),
(782,96,'_manage_stock','no'),
(783,96,'_backorders','no'),
(784,96,'_sold_individually','no'),
(785,96,'_virtual','no'),
(786,96,'_downloadable','no'),
(787,96,'_download_limit','-1'),
(788,96,'_download_expiry','-1'),
(789,96,'_stock',''),
(790,96,'_stock_status','instock'),
(791,96,'_wc_average_rating','4.68'),
(792,96,'_wc_review_count','19'),
(793,96,'_product_version','9.5.1'),
(794,96,'_price','14'),
(795,96,'_botiga_page_builder_mode','0'),
(796,96,'_botiga_sidebar_layout',''),
(797,96,'_thumbnail_id','318'),
(798,96,'_botiga_disable_header_transparent','0'),
(799,96,'_wxr_import_user_slug','admin'),
(800,96,'_athemes_sites_imported_post','1'),
(801,97,'_regular_price','16'),
(802,97,'total_sales','110'),
(803,97,'_tax_status','taxable'),
(804,97,'_tax_class',''),
(805,97,'_manage_stock','no'),
(806,97,'_backorders','no'),
(807,97,'_sold_individually','no'),
(808,97,'_virtual','no'),
(809,97,'_downloadable','no'),
(810,97,'_download_limit','-1'),
(811,97,'_download_expiry','-1'),
(812,97,'_stock',''),
(813,97,'_stock_status','instock'),
(814,97,'_wc_average_rating','4.27'),
(815,97,'_wc_review_count','15'),
(816,97,'_product_version','9.5.1'),
(817,97,'_price','12'),
(818,97,'_botiga_page_builder_mode','0'),
(819,97,'_botiga_sidebar_layout','customizer'),
(820,97,'_sale_price','12'),
(821,97,'_product_image_gallery',''),
(822,97,'_thumbnail_id','310'),
(823,97,'_wxr_import_user_slug','admin'),
(824,97,'_athemes_sites_imported_post','1'),
(898,438,'wpforms_form_locations','a:1:{i:0;a:6:{s:4:\"type\";s:4:\"page\";s:5:\"title\";s:7:\"Kontakt\";s:7:\"form_id\";i:438;s:2:\"id\";i:394;s:6:\"status\";s:7:\"publish\";s:3:\"url\";s:9:\"/kontakt/\";}}'),
(899,438,'_wxr_import_user_slug','admin'),
(900,438,'_athemes_sites_imported_post','1'),
(901,439,'_elementor_edit_mode','builder'),
(902,439,'_elementor_template_type','kit'),
(903,386,'_wp_page_template','default'),
(904,386,'_elementor_page_settings','a:1:{s:9:\"site_name\";s:16:\"Cocolo Demo Shop\";}'),
(908,391,'_elementor_migrations_state_d2a1','4.1.1:6235a6c47f65a3aca2fc5a7c56ad64e4'),
(912,394,'_elementor_migrations_state_d2a1','4.1.1:6235a6c47f65a3aca2fc5a7c56ad64e4'),
(922,440,'_wp_trash_meta_status','publish'),
(923,440,'_wp_trash_meta_time','1780322958'),
(924,19,'_wp_trash_meta_status','publish'),
(925,19,'_wp_trash_meta_time','1780328506'),
(926,19,'_wp_desired_post_slug','powerbank-10000mah'),
(927,18,'_wp_trash_meta_status','publish'),
(928,18,'_wp_trash_meta_time','1780328509'),
(929,18,'_wp_desired_post_slug','usb-c-schnellladegeraet'),
(930,17,'_wp_trash_meta_status','publish'),
(931,17,'_wp_trash_meta_time','1780328570'),
(932,17,'_wp_desired_post_slug','bluetooth-kopfhoerer'),
(933,16,'_wp_trash_meta_status','publish'),
(934,16,'_wp_trash_meta_time','1780328576'),
(935,16,'_wp_desired_post_slug','duftkerze-vanille'),
(936,15,'_wp_trash_meta_status','publish'),
(937,15,'_wp_trash_meta_time','1780328578'),
(938,15,'_wp_desired_post_slug','edelstahl-trinkflasche'),
(939,13,'_wp_trash_meta_status','publish'),
(940,13,'_wp_trash_meta_time','1780328583'),
(941,13,'_wp_desired_post_slug','canvas-umhaengetasche'),
(942,14,'_wp_trash_meta_status','publish'),
(943,14,'_wp_trash_meta_time','1780328585'),
(944,14,'_wp_desired_post_slug','keramik-tasse-300ml'),
(945,12,'_wp_trash_meta_status','publish'),
(946,12,'_wp_trash_meta_time','1780328588'),
(947,12,'_wp_desired_post_slug','snapback-cap-schwarz'),
(948,11,'_wp_trash_meta_status','publish'),
(949,11,'_wp_trash_meta_time','1780328590'),
(950,11,'_wp_desired_post_slug','kapuzenpullover-grau'),
(951,10,'_wp_trash_meta_status','publish'),
(952,10,'_wp_trash_meta_time','1780328592'),
(953,10,'_wp_desired_post_slug','bio-baumwoll-t-shirt'),
(965,442,'_pingme','1'),
(966,442,'_encloseme','1'),
(967,443,'_pingme','1'),
(968,443,'_encloseme','1'),
(969,443,'_thumbnail_id','317'),
(970,444,'_pingme','1'),
(971,444,'_encloseme','1'),
(972,444,'_thumbnail_id','316'),
(973,445,'_pingme','1'),
(974,445,'_encloseme','1'),
(975,445,'_thumbnail_id','249'),
(976,446,'_pingme','1'),
(977,446,'_encloseme','1'),
(978,446,'_thumbnail_id','319'),
(979,447,'_pingme','1'),
(980,447,'_encloseme','1'),
(981,447,'_thumbnail_id','310'),
(982,442,'_thumbnail_id','318'),
(1014,97,'_wc_rating_count','a:5:{i:1;i:0;i:2;i:1;i:3;i:2;i:4;i:4;i:5;i:8;}'),
(1015,96,'_wc_rating_count','a:5:{i:1;i:0;i:2;i:1;i:3;i:0;i:4;i:3;i:5;i:15;}'),
(1016,95,'_wc_rating_count','a:5:{i:1;i:0;i:2;i:0;i:3;i:1;i:4;i:2;i:5;i:17;}'),
(1017,94,'_wc_rating_count','a:5:{i:1;i:0;i:2;i:1;i:3;i:1;i:4;i:7;i:5;i:23;}'),
(1018,93,'_wc_rating_count','a:5:{i:1;i:0;i:2;i:0;i:3;i:1;i:4;i:6;i:5;i:8;}'),
(1019,42,'_wc_rating_count','a:5:{i:1;i:1;i:2;i:0;i:3;i:1;i:4;i:4;i:5;i:25;}'),
(1020,40,'_wc_rating_count','a:5:{i:1;i:0;i:2;i:0;i:3;i:1;i:4;i:8;i:5;i:25;}'),
(1021,31,'_wc_rating_count','a:5:{i:1;i:1;i:2;i:3;i:3;i:1;i:4;i:4;i:5;i:26;}'),
(1028,395,'_wp_old_date','2022-12-06'),
(1029,397,'_wp_old_date','2022-12-06'),
(1030,399,'_wp_old_date','2022-10-19'),
(1031,402,'_wp_old_date','2022-10-19'),
(1032,403,'_wp_old_date','2022-10-19'),
(1033,404,'_wp_old_date','2022-10-19'),
(1074,386,'_elementor_css','a:6:{s:4:\"time\";i:1780395989;s:5:\"fonts\";a:2:{i:0;s:6:\"Roboto\";i:1;s:11:\"Roboto Slab\";}s:5:\"icons\";a:0:{}s:20:\"dynamic_elements_ids\";a:0:{}s:6:\"status\";s:4:\"file\";i:0;s:0:\"\";}'),
(1075,391,'_elementor_page_assets','a:2:{s:6:\"styles\";a:3:{i:0;s:27:\"e-animation-fadeInUpShorter\";i:1;s:14:\"widget-heading\";i:2;s:12:\"widget-image\";}s:7:\"scripts\";a:1:{i:0;s:18:\"elementor-frontend\";}}'),
(1076,391,'_elementor_css','a:6:{s:4:\"time\";i:1780395989;s:5:\"fonts\";a:1:{i:0;s:5:\"Inter\";}s:5:\"icons\";a:1:{i:0;s:0:\"\";}s:20:\"dynamic_elements_ids\";a:0:{}s:6:\"status\";s:4:\"file\";i:0;s:0:\"\";}'),
(1077,391,'_elementor_element_cache','{\"timeout\":1780482389,\"value\":{\"content\":\"\\t\\t<section class=\\\"elementor-section elementor-top-section elementor-element elementor-element-a53f34a elementor-section-full_width elementor-section-height-default elementor-section-height-default\\\" data-id=\\\"a53f34a\\\" data-element_type=\\\"section\\\" data-e-type=\\\"section\\\" data-settings=\\\"{&quot;background_background&quot;:&quot;classic&quot;}\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-container elementor-column-gap-default\\\">\\n\\t\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-56314a8\\\" data-id=\\\"56314a8\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<section class=\\\"elementor-section elementor-inner-section elementor-element elementor-element-f0fbbd4 elementor-section-boxed elementor-section-height-default elementor-section-height-default\\\" data-id=\\\"f0fbbd4\\\" data-element_type=\\\"section\\\" data-e-type=\\\"section\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-container elementor-column-gap-default\\\">\\n\\t\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-77f1ba6\\\" data-id=\\\"77f1ba6\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-dbae005 elementor-invisible elementor-widget elementor-widget-heading\\\" data-id=\\\"dbae005\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-settings=\\\"{&quot;_animation&quot;:&quot;fadeInUpShorter&quot;,&quot;_animation_delay&quot;:200}\\\" data-widget_type=\\\"heading.default\\\">\\n\\t\\t\\t\\t\\t<h1 class=\\\"elementor-heading-title elementor-size-default\\\">Headline that grabs people\'s attention<\\/h1>\\t\\t\\t\\t<\\/div>\\n\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-87aedb5 elementor-invisible elementor-widget elementor-widget-button\\\" data-id=\\\"87aedb5\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-settings=\\\"{&quot;_animation&quot;:&quot;fadeInUpShorter&quot;,&quot;_animation_delay&quot;:400}\\\" data-widget_type=\\\"button.default\\\">\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<a class=\\\"elementor-button elementor-button-link elementor-size-sm\\\" href=\\\"http:\\/\\/localhost:8090\\/shop\\/\\\">\\n\\t\\t\\t\\t\\t\\t<span class=\\\"elementor-button-content-wrapper\\\">\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t<span class=\\\"elementor-button-text\\\">JETZT EINKAUFEN<\\/span>\\n\\t\\t\\t\\t\\t<\\/span>\\n\\t\\t\\t\\t\\t<\\/a>\\n\\t\\t\\t\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-ffe626f\\\" data-id=\\\"ffe626f\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap\\\">\\n\\t\\t\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/section>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/section>\\n\\t\\t\\t\\t<section class=\\\"elementor-section elementor-top-section elementor-element elementor-element-cc4ba2a elementor-section-boxed elementor-section-height-default elementor-section-height-default\\\" data-id=\\\"cc4ba2a\\\" data-element_type=\\\"section\\\" data-e-type=\\\"section\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-container elementor-column-gap-default\\\">\\n\\t\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-e654a9e\\\" data-id=\\\"e654a9e\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-cfaddff elementor-invisible elementor-widget elementor-widget-heading\\\" data-id=\\\"cfaddff\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-settings=\\\"{&quot;_animation&quot;:&quot;fadeInUpShorter&quot;,&quot;_animation_delay&quot;:200}\\\" data-widget_type=\\\"heading.default\\\">\\n\\t\\t\\t\\t\\t<h2 class=\\\"elementor-heading-title elementor-size-default\\\">Empfohlen Collection<\\/h2>\\t\\t\\t\\t<\\/div>\\n\\t\\t[elementor-element k=\\\"092918d9a5eb55fd11f59f61ce549a0d\\\" data=\\\"eyJpZCI6ImJlZmVmNTkiLCJlbFR5cGUiOiJ3aWRnZXQiLCJzZXR0aW5ncyI6eyJlZGl0b3IiOiI8cD5BIHBvd2VyZnVsIGhlYWRsaW5lIGFib3V0IHlvdXIgcHJvZHVjdFx1MjAxOXMgZmVhdHVyZXMgdG8gZ2l2ZSBmb2N1cyB0byB5b3VyIGNob3NlbiBwcm9kdWN0IGNvbGxlY3Rpb248XC9wPiIsImFsaWduIjoiY2VudGVyIiwiX21hcmdpbiI6eyJ1bml0IjoicHgiLCJ0b3AiOiIwIiwicmlnaHQiOiIwIiwiYm90dG9tIjoiLTI1IiwibGVmdCI6IjAiLCJpc0xpbmtlZCI6ZmFsc2V9LCJ0eXBvZ3JhcGh5X3R5cG9ncmFwaHkiOiJjdXN0b20iLCJ0eXBvZ3JhcGh5X2ZvbnRfZmFtaWx5IjoiSW50ZXIiLCJ0eXBvZ3JhcGh5X2ZvbnRfd2VpZ2h0IjoiNDAwIiwiX2FuaW1hdGlvbiI6ImZhZGVJblVwU2hvcnRlciIsIl9hbmltYXRpb25fZGVsYXkiOjQwMH0sImVsZW1lbnRzIjpbXSwid2lkZ2V0VHlwZSI6InRleHQtZWRpdG9yIn0=\\\"][elementor-element k=\\\"092918d9a5eb55fd11f59f61ce549a0d\\\" data=\\\"eyJpZCI6IjkwODc0NWYiLCJlbFR5cGUiOiJ3aWRnZXQiLCJzZXR0aW5ncyI6eyJzaG9ydGNvZGUiOiJbcHJvZHVjdHMgY29sdW1ucz1cIjNcIiBsaW1pdD1cIjNcIl0iLCJfYW5pbWF0aW9uIjoiZmFkZUluVXBTaG9ydGVyIiwiX2FuaW1hdGlvbl9kZWxheSI6NjAwfSwiZWxlbWVudHMiOltdLCJ3aWRnZXRUeXBlIjoic2hvcnRjb2RlIn0=\\\"]\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/section>\\n\\t\\t\\t\\t<section class=\\\"elementor-section elementor-top-section elementor-element elementor-element-5291af9 elementor-section-full_width elementor-section-height-default elementor-section-height-default\\\" data-id=\\\"5291af9\\\" data-element_type=\\\"section\\\" data-e-type=\\\"section\\\" data-settings=\\\"{&quot;background_background&quot;:&quot;classic&quot;}\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-container elementor-column-gap-default\\\">\\n\\t\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0eb56ce\\\" data-id=\\\"0eb56ce\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<section class=\\\"elementor-section elementor-inner-section elementor-element elementor-element-9b2fd73 elementor-section-boxed elementor-section-height-default elementor-section-height-default\\\" data-id=\\\"9b2fd73\\\" data-element_type=\\\"section\\\" data-e-type=\\\"section\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-container elementor-column-gap-default\\\">\\n\\t\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-8a88a77\\\" data-id=\\\"8a88a77\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-c8a29d4 elementor-invisible elementor-widget elementor-widget-heading\\\" data-id=\\\"c8a29d4\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-settings=\\\"{&quot;_animation&quot;:&quot;fadeInUpShorter&quot;,&quot;_animation_delay&quot;:200}\\\" data-widget_type=\\\"heading.default\\\">\\n\\t\\t\\t\\t\\t<h2 class=\\\"elementor-heading-title elementor-size-default\\\">Highlighted Section<\\/h2>\\t\\t\\t\\t<\\/div>\\n\\t\\t[elementor-element k=\\\"092918d9a5eb55fd11f59f61ce549a0d\\\" data=\\\"eyJpZCI6ImQ4MGFiY2UiLCJlbFR5cGUiOiJ3aWRnZXQiLCJzZXR0aW5ncyI6eyJlZGl0b3IiOiI8cD48c3BhbiBzdHlsZT1cImNvbG9yOiAjMjEyMTIxOyBmb250LWZhbWlseTogSW50ZXIsIHNhbnMtc2VyaWY7XCI+V2hhdCBkaWZmZXJlbnRpYXRlcyB5b3UgZnJvbSB0aGUgY29tcGV0aXRpb24\\/IFVzZSB0aGlzIHNlY3Rpb24gdG8gdGFsayBhYm91dCBpdC4gRG9uXHUyMDE5dCBmb3JnZXQgdG8gdGFsayBhYm91dCB0aGUgYmVuZWZpdHMuPFwvc3Bhbj48XC9wPiIsImFsaWduIjoiY2VudGVyIiwiX21hcmdpbiI6eyJ1bml0IjoicHgiLCJ0b3AiOiIwIiwicmlnaHQiOiIwIiwiYm90dG9tIjoiLTI1IiwibGVmdCI6IjAiLCJpc0xpbmtlZCI6ZmFsc2V9LCJ0eXBvZ3JhcGh5X3R5cG9ncmFwaHkiOiJjdXN0b20iLCJ0eXBvZ3JhcGh5X2ZvbnRfZmFtaWx5IjoiSW50ZXIiLCJ0eXBvZ3JhcGh5X2ZvbnRfd2VpZ2h0IjoiNDAwIiwiX2FuaW1hdGlvbiI6ImZhZGVJblVwU2hvcnRlciIsIl9hbmltYXRpb25fZGVsYXkiOjQwMH0sImVsZW1lbnRzIjpbXSwid2lkZ2V0VHlwZSI6InRleHQtZWRpdG9yIn0=\\\"]\\t\\t<div class=\\\"elementor-element elementor-element-39ef610 elementor-align-center elementor-invisible elementor-widget elementor-widget-button\\\" data-id=\\\"39ef610\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-settings=\\\"{&quot;_animation&quot;:&quot;fadeInUpShorter&quot;,&quot;_animation_delay&quot;:600}\\\" data-widget_type=\\\"button.default\\\">\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<a class=\\\"elementor-button elementor-button-link elementor-size-sm\\\" href=\\\"http:\\/\\/localhost:8090\\/shop\\/\\\">\\n\\t\\t\\t\\t\\t\\t<span class=\\\"elementor-button-content-wrapper\\\">\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t<span class=\\\"elementor-button-text\\\">JETZT EINKAUFEN<\\/span>\\n\\t\\t\\t\\t\\t<\\/span>\\n\\t\\t\\t\\t\\t<\\/a>\\n\\t\\t\\t\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/section>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/section>\\n\\t\\t\\t\\t<section class=\\\"elementor-section elementor-top-section elementor-element elementor-element-398a725 elementor-section-boxed elementor-section-height-default elementor-section-height-default\\\" data-id=\\\"398a725\\\" data-element_type=\\\"section\\\" data-e-type=\\\"section\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-container elementor-column-gap-default\\\">\\n\\t\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-433c458\\\" data-id=\\\"433c458\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-52f8025 elementor-invisible elementor-widget elementor-widget-heading\\\" data-id=\\\"52f8025\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-settings=\\\"{&quot;_animation&quot;:&quot;fadeInUpShorter&quot;,&quot;_animation_delay&quot;:200}\\\" data-widget_type=\\\"heading.default\\\">\\n\\t\\t\\t\\t\\t<h2 class=\\\"elementor-heading-title elementor-size-default\\\">Empfohlen Categories<\\/h2>\\t\\t\\t\\t<\\/div>\\n\\t\\t[elementor-element k=\\\"092918d9a5eb55fd11f59f61ce549a0d\\\" data=\\\"eyJpZCI6ImRjOTMyNzkiLCJlbFR5cGUiOiJ3aWRnZXQiLCJzZXR0aW5ncyI6eyJlZGl0b3IiOiI8cD48c3BhbiBzdHlsZT1cImNvbG9yOiAjMjEyMTIxOyBmb250LWZhbWlseTogSW50ZXIsIHNhbnMtc2VyaWY7XCI+RW50ZGVja2UgdW5zZXJlIEtvbGxla3Rpb24gbmF0XHUwMGZjcmxpY2hlciBQZmxlZ2Vwcm9kdWt0ZS4gU2VsZWN0IGltYWdlcnkgYW5kIG5hbWUgdGhhdCByZWxhdGVzIHRvIHRoZSBwcm9kdWN0IGNhdGVnb3J5LjxcL3NwYW4+PFwvcD4iLCJhbGlnbiI6ImNlbnRlciIsIl9tYXJnaW4iOnsidW5pdCI6InB4IiwidG9wIjoiMCIsInJpZ2h0IjoiMCIsImJvdHRvbSI6Ii0yNSIsImxlZnQiOiIwIiwiaXNMaW5rZWQiOmZhbHNlfSwidHlwb2dyYXBoeV90eXBvZ3JhcGh5IjoiY3VzdG9tIiwidHlwb2dyYXBoeV9mb250X2ZhbWlseSI6IkludGVyIiwidHlwb2dyYXBoeV9mb250X3dlaWdodCI6IjQwMCIsIl9wYWRkaW5nX3RhYmxldCI6eyJ1bml0IjoicHgiLCJ0b3AiOiIwIiwicmlnaHQiOiI4MCIsImJvdHRvbSI6IjAiLCJsZWZ0IjoiODAiLCJpc0xpbmtlZCI6ZmFsc2V9LCJfcGFkZGluZ19tb2JpbGUiOnsidW5pdCI6InB4IiwidG9wIjoiMCIsInJpZ2h0IjoiMCIsImJvdHRvbSI6IjAiLCJsZWZ0IjoiMCIsImlzTGlua2VkIjpmYWxzZX0sIl9hbmltYXRpb24iOiJmYWRlSW5VcFNob3J0ZXIiLCJfYW5pbWF0aW9uX2RlbGF5Ijo0MDB9LCJlbGVtZW50cyI6W10sIndpZGdldFR5cGUiOiJ0ZXh0LWVkaXRvciJ9\\\"]\\t\\t<section class=\\\"elementor-section elementor-inner-section elementor-element elementor-element-a19ffd5 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-invisible\\\" data-id=\\\"a19ffd5\\\" data-element_type=\\\"section\\\" data-e-type=\\\"section\\\" data-settings=\\\"{&quot;animation&quot;:&quot;fadeInUpShorter&quot;,&quot;animation_delay&quot;:600}\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-container elementor-column-gap-default\\\">\\n\\t\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-9b22770\\\" data-id=\\\"9b22770\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-3fcfc89 elementor-widget elementor-widget-image\\\" data-id=\\\"3fcfc89\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-widget_type=\\\"image.default\\\">\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<figure class=\\\"wp-caption\\\">\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<a href=\\\"http:\\/\\/localhost:8090\\/product-category\\/cosmetics\\/\\\">\\n\\t\\t\\t\\t\\t\\t\\t<img width=\\\"510\\\" height=\\\"490\\\" src=\\\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-581-1.jpg\\\" class=\\\"attachment-large size-large wp-image-325\\\" alt=\\\"\\\" srcset=\\\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-581-1.jpg 510w, http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-581-1-300x288.jpg 300w, http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-581-1-380x365.jpg 380w\\\" sizes=\\\"(max-width: 510px) 100vw, 510px\\\" \\/>\\t\\t\\t\\t\\t\\t\\t\\t<\\/a>\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<figcaption class=\\\"widget-image-caption wp-caption-text\\\">Makeup<\\/figcaption>\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<\\/figure>\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-2570323\\\" data-id=\\\"2570323\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-bd8f9cc elementor-widget elementor-widget-image\\\" data-id=\\\"bd8f9cc\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-widget_type=\\\"image.default\\\">\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<figure class=\\\"wp-caption\\\">\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<a href=\\\"http:\\/\\/localhost:8090\\/product-category\\/cosmetics\\/\\\">\\n\\t\\t\\t\\t\\t\\t\\t<img width=\\\"510\\\" height=\\\"490\\\" src=\\\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-582-1.jpg\\\" class=\\\"attachment-large size-large wp-image-323\\\" alt=\\\"\\\" srcset=\\\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-582-1.jpg 510w, http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-582-1-300x288.jpg 300w, http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-582-1-380x365.jpg 380w\\\" sizes=\\\"(max-width: 510px) 100vw, 510px\\\" \\/>\\t\\t\\t\\t\\t\\t\\t\\t<\\/a>\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<figcaption class=\\\"widget-image-caption wp-caption-text\\\">Lipstick<\\/figcaption>\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<\\/figure>\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-1b2f266\\\" data-id=\\\"1b2f266\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-ae7a6ae elementor-widget elementor-widget-image\\\" data-id=\\\"ae7a6ae\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-widget_type=\\\"image.default\\\">\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<figure class=\\\"wp-caption\\\">\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<a href=\\\"http:\\/\\/localhost:8090\\/product-category\\/cosmetics\\/\\\">\\n\\t\\t\\t\\t\\t\\t\\t<img width=\\\"510\\\" height=\\\"490\\\" src=\\\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-583-1.jpg\\\" class=\\\"attachment-large size-large wp-image-326\\\" alt=\\\"\\\" srcset=\\\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-583-1.jpg 510w, http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-583-1-300x288.jpg 300w, http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-583-1-380x365.jpg 380w\\\" sizes=\\\"(max-width: 510px) 100vw, 510px\\\" \\/>\\t\\t\\t\\t\\t\\t\\t\\t<\\/a>\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<figcaption class=\\\"widget-image-caption wp-caption-text\\\">Bath Products<\\/figcaption>\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<\\/figure>\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-b4c83e4\\\" data-id=\\\"b4c83e4\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-7404df9 elementor-widget elementor-widget-image\\\" data-id=\\\"7404df9\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-widget_type=\\\"image.default\\\">\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<figure class=\\\"wp-caption\\\">\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<a href=\\\"http:\\/\\/localhost:8090\\/product-category\\/cosmetics\\/\\\">\\n\\t\\t\\t\\t\\t\\t\\t<img width=\\\"510\\\" height=\\\"490\\\" src=\\\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-584-1.jpg\\\" class=\\\"attachment-large size-large wp-image-327\\\" alt=\\\"\\\" srcset=\\\"http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-584-1.jpg 510w, http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-584-1-300x288.jpg 300w, http:\\/\\/localhost:8090\\/wp-content\\/uploads\\/2021\\/07\\/Rectangle-584-1-380x365.jpg 380w\\\" sizes=\\\"(max-width: 510px) 100vw, 510px\\\" \\/>\\t\\t\\t\\t\\t\\t\\t\\t<\\/a>\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<figcaption class=\\\"widget-image-caption wp-caption-text\\\">Treatments<\\/figcaption>\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t<\\/figure>\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/section>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/section>\\n\\t\\t\",\"scripts\":[],\"styles\":[]}}'),
(1090,394,'_elementor_page_assets','a:2:{s:6:\"styles\";a:4:{i:0;s:27:\"e-animation-fadeInUpShorter\";i:1;s:14:\"widget-heading\";i:2;s:18:\"widget-google_maps\";i:3;s:13:\"widget-spacer\";}s:7:\"scripts\";a:2:{i:0;s:18:\"elementor-frontend\";i:1;s:17:\"wpforms-elementor\";}}'),
(1091,394,'_elementor_css','a:6:{s:4:\"time\";i:1780397651;s:5:\"fonts\";a:1:{i:0;s:5:\"Inter\";}s:5:\"icons\";a:0:{}s:20:\"dynamic_elements_ids\";a:0:{}s:6:\"status\";s:4:\"file\";i:0;s:0:\"\";}'),
(1092,394,'_elementor_element_cache','{\"timeout\":1780484051,\"value\":{\"content\":\"\\t\\t<section class=\\\"elementor-section elementor-top-section elementor-element elementor-element-c275639 elementor-section-boxed elementor-section-height-default elementor-section-height-default\\\" data-id=\\\"c275639\\\" data-element_type=\\\"section\\\" data-e-type=\\\"section\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-container elementor-column-gap-default\\\">\\n\\t\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0d095d2\\\" data-id=\\\"0d095d2\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-55a89d3 elementor-invisible elementor-widget elementor-widget-heading\\\" data-id=\\\"55a89d3\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-settings=\\\"{&quot;_animation&quot;:&quot;fadeInUpShorter&quot;,&quot;_animation_delay&quot;:200}\\\" data-widget_type=\\\"heading.default\\\">\\n\\t\\t\\t\\t\\t<h2 class=\\\"elementor-heading-title elementor-size-default\\\">Kontakt<\\/h2>\\t\\t\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/section>\\n\\t\\t\\t\\t<section class=\\\"elementor-section elementor-top-section elementor-element elementor-element-6c09bab elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-invisible\\\" data-id=\\\"6c09bab\\\" data-element_type=\\\"section\\\" data-e-type=\\\"section\\\" data-settings=\\\"{&quot;animation&quot;:&quot;fadeInUpShorter&quot;,&quot;animation_delay&quot;:400}\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-container elementor-column-gap-default\\\">\\n\\t\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-801eab6\\\" data-id=\\\"801eab6\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-fd0eb9d elementor-widget elementor-widget-google_maps\\\" data-id=\\\"fd0eb9d\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-widget_type=\\\"google_maps.default\\\">\\n\\t\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-custom-embed\\\">\\n\\t\\t\\t<iframe loading=\\\"lazy\\\"\\n\\t\\t\\t\\t\\tsrc=\\\"https:\\/\\/maps.google.com\\/maps?q=Friedrichstra%C3%9Fe%20100%2C%2010117%20Berlin%2C%20Deutschland&#038;t=m&#038;z=10&#038;output=embed&#038;iwloc=near\\\"\\n\\t\\t\\t\\t\\ttitle=\\\"Friedrichstra\\u00dfe 100, 10117 Berlin, Deutschland\\\"\\n\\t\\t\\t\\t\\taria-label=\\\"Friedrichstra\\u00dfe 100, 10117 Berlin, Deutschland\\\"\\n\\t\\t\\t><\\/iframe>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/section>\\n\\t\\t\\t\\t<section class=\\\"elementor-section elementor-top-section elementor-element elementor-element-963138c elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-invisible\\\" data-id=\\\"963138c\\\" data-element_type=\\\"section\\\" data-e-type=\\\"section\\\" data-settings=\\\"{&quot;animation&quot;:&quot;fadeInUpShorter&quot;,&quot;animation_delay&quot;:600}\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-container elementor-column-gap-default\\\">\\n\\t\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-d2566ee\\\" data-id=\\\"d2566ee\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-622e931 elementor-widget elementor-widget-heading\\\" data-id=\\\"622e931\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-widget_type=\\\"heading.default\\\">\\n\\t\\t\\t\\t\\t<h2 class=\\\"elementor-heading-title elementor-size-default\\\">Leave Us a Message<\\/h2>\\t\\t\\t\\t<\\/div>\\n\\t\\t[elementor-element k=\\\"092918d9a5eb55fd11f59f61ce549a0d\\\" data=\\\"eyJpZCI6IjU5NjUzN2QiLCJlbFR5cGUiOiJ3aWRnZXQiLCJzZXR0aW5ncyI6eyJmb3JtX2lkIjoiNDM4In0sImVsZW1lbnRzIjpbXSwid2lkZ2V0VHlwZSI6IndwZm9ybXMifQ==\\\"]\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-dfa68f3\\\" data-id=\\\"dfa68f3\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-449cc41 elementor-widget elementor-widget-heading\\\" data-id=\\\"449cc41\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-widget_type=\\\"heading.default\\\">\\n\\t\\t\\t\\t\\t<h2 class=\\\"elementor-heading-title elementor-size-default\\\">Unser Gesch\\u00e4ft<\\/h2>\\t\\t\\t\\t<\\/div>\\n\\t\\t[elementor-element k=\\\"092918d9a5eb55fd11f59f61ce549a0d\\\" data=\\\"eyJpZCI6Ijg3ZTgyYTEiLCJlbFR5cGUiOiJ3aWRnZXQiLCJzZXR0aW5ncyI6eyJlZGl0b3IiOiI8cCBzdHlsZT1cImJveC1zaXppbmc6IGluaGVyaXQ7IGNvbG9yOiAjMjEyMTIxOyBmb250LWZhbWlseTogSW50ZXIsIHNhbnMtc2VyaWY7XCI+RnJpZWRyaWNoc3RyYVx1MDBkZmUgMTAwLCAxMDExNyBCZXJsaW4sIERldXRzY2hsYW5kPFwvcD48cCBzdHlsZT1cImJveC1zaXppbmc6IGluaGVyaXQ7IGNvbG9yOiAjMjEyMTIxOyBmb250LWZhbWlseTogSW50ZXIsIHNhbnMtc2VyaWY7XCI+UEhPTkU6PGJyIFwvPjxzcGFuIHN0eWxlPVwiZm9udC13ZWlnaHQ6IHZhciggLS1lLWdsb2JhbC10eXBvZ3JhcGh5LXRleHQtZm9udC13ZWlnaHQgKTsgbGV0dGVyLXNwYWNpbmc6IDBweDtcIj4rNDkgMzAgOTAxODIwPFwvc3Bhbj48XC9wPjxwIHN0eWxlPVwiYm94LXNpemluZzogaW5oZXJpdDsgY29sb3I6ICMyMTIxMjE7IGZvbnQtZmFtaWx5OiBJbnRlciwgc2Fucy1zZXJpZjtcIj5FLU1BSUw6PGJyIFwvPjxzcGFuIHN0eWxlPVwiZm9udC13ZWlnaHQ6IHZhciggLS1lLWdsb2JhbC10eXBvZ3JhcGh5LXRleHQtZm9udC13ZWlnaHQgKTsgbGV0dGVyLXNwYWNpbmc6IDBweDtcIj5rb250YWt0QGNvY29sby1iZXJsaW4uZGU8XC9zcGFuPjxcL3A+IiwidHlwb2dyYXBoeV90eXBvZ3JhcGh5IjoiY3VzdG9tIiwidHlwb2dyYXBoeV9mb250X2ZhbWlseSI6IkludGVyIiwidHlwb2dyYXBoeV9mb250X3dlaWdodCI6IjQwMCJ9LCJlbGVtZW50cyI6W10sIndpZGdldFR5cGUiOiJ0ZXh0LWVkaXRvciJ9\\\"]\\t\\t<div class=\\\"elementor-element elementor-element-cbfd614 elementor-widget elementor-widget-heading\\\" data-id=\\\"cbfd614\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-widget_type=\\\"heading.default\\\">\\n\\t\\t\\t\\t\\t<h2 class=\\\"elementor-heading-title elementor-size-default\\\">Store Hours<\\/h2>\\t\\t\\t\\t<\\/div>\\n\\t\\t[elementor-element k=\\\"092918d9a5eb55fd11f59f61ce549a0d\\\" data=\\\"eyJpZCI6Ijc2OWNiOTYiLCJlbFR5cGUiOiJ3aWRnZXQiLCJzZXR0aW5ncyI6eyJlZGl0b3IiOiI8cCBzdHlsZT1cImJveC1zaXppbmc6IGluaGVyaXQ7IGNvbG9yOiAjMjEyMTIxOyBmb250LWZhbWlseTogSW50ZXIsIHNhbnMtc2VyaWY7XCI+U3VuOiBDbG9zZWQ8YnIgXC8+PHNwYW4gc3R5bGU9XCJmb250LXdlaWdodDogdmFyKCAtLWUtZ2xvYmFsLXR5cG9ncmFwaHktdGV4dC1mb250LXdlaWdodCApOyBsZXR0ZXItc3BhY2luZzogMHB4O1wiPk1vbiB0byBTYXQ6IDEwIEFNIFx1MjAxMyA1OjMwIFBNPFwvc3Bhbj48XC9wPiIsInR5cG9ncmFwaHlfdHlwb2dyYXBoeSI6ImN1c3RvbSIsInR5cG9ncmFwaHlfZm9udF9mYW1pbHkiOiJJbnRlciIsInR5cG9ncmFwaHlfZm9udF93ZWlnaHQiOiI0MDAifSwiZWxlbWVudHMiOltdLCJ3aWRnZXRUeXBlIjoidGV4dC1lZGl0b3IifQ==\\\"]\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/section>\\n\\t\\t\\t\\t<section class=\\\"elementor-section elementor-top-section elementor-element elementor-element-d502af4 elementor-section-boxed elementor-section-height-default elementor-section-height-default\\\" data-id=\\\"d502af4\\\" data-element_type=\\\"section\\\" data-e-type=\\\"section\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-container elementor-column-gap-default\\\">\\n\\t\\t\\t\\t\\t<div class=\\\"elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-4bef3e5\\\" data-id=\\\"4bef3e5\\\" data-element_type=\\\"column\\\" data-e-type=\\\"column\\\">\\n\\t\\t\\t<div class=\\\"elementor-widget-wrap elementor-element-populated\\\">\\n\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-element elementor-element-de863e8 elementor-widget elementor-widget-spacer\\\" data-id=\\\"de863e8\\\" data-element_type=\\\"widget\\\" data-e-type=\\\"widget\\\" data-widget_type=\\\"spacer.default\\\">\\n\\t\\t\\t\\t\\t\\t\\t<div class=\\\"elementor-spacer\\\">\\n\\t\\t\\t<div class=\\\"elementor-spacer-inner\\\"><\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/div>\\n\\t\\t\\t\\t\\t<\\/div>\\n\\t\\t<\\/section>\\n\\t\\t\",\"scripts\":[],\"styles\":[]}}');
/*!40000 ALTER TABLE `wp_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=454 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_posts`
--

LOCK TABLES `wp_posts` WRITE;
/*!40000 ALTER TABLE `wp_posts` DISABLE KEYS */;
INSERT INTO `wp_posts` VALUES
(3,1,'2026-06-01 13:48:36','2026-06-01 13:48:36','<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Who we are</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://localhost:8090.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Comments</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Media</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Cookies</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Embedded content from other websites</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Who we share your data with</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">How long we retain your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">What rights you have over your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Where your data is sent</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->\n','Privacy Policy','','draft','closed','open','','privacy-policy','','','2026-06-01 13:48:36','2026-06-01 13:48:36','',0,'http://localhost:8090/?page_id=3',0,'page','',0),
(4,0,'2026-06-01 13:48:47','2026-06-01 13:48:47','','woocommerce-placeholder','','inherit','open','closed','','woocommerce-placeholder','','','2026-06-01 13:48:47','2026-06-01 13:48:47','',0,'http://localhost:8090/wp-content/uploads/2026/06/woocommerce-placeholder.png',0,'attachment','image/png',0),
(8,1,'2026-06-01 13:48:47','2026-06-01 13:48:47','<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->','My account','','publish','closed','closed','','my-account','','','2026-06-01 13:48:47','2026-06-01 13:48:47','',0,'http://localhost:8090/?page_id=8',0,'page','',0),
(9,1,'2026-06-01 13:48:47','0000-00-00 00:00:00','<!-- wp:paragraph -->\n<p><b>This is a sample page.</b></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Overview</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Our refund and returns policy lasts 30 days. If 30 days have passed since your purchase, we can’t offer you a full refund or exchange.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Several types of goods are exempt from being returned. Perishable goods such as food, flowers, newspapers or magazines cannot be returned. We also do not accept products that are intimate or sanitary goods, hazardous materials, or flammable liquids or gases.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Additional non-returnable items:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Gift cards</li>\n<li>Downloadable software products</li>\n<li>Some health and personal care items</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>To complete your return, we require a receipt or proof of purchase.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Please do not send your purchase back to the manufacturer.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>There are certain situations where only partial refunds are granted:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Book with obvious signs of use</li>\n<li>CD, DVD, VHS tape, software, video game, cassette tape, or vinyl record that has been opened.</li>\n<li>Any item not in its original condition, is damaged or missing parts for reasons not due to our error.</li>\n<li>Any item that is returned more than 30 days after delivery</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Refunds</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h3 class=\"wp-block-heading\">Late or missing refunds</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>If you haven’t received a refund yet, first check your bank account again.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Then contact your credit card company, it may take some time before your refund is officially posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Next contact your bank. There is often some processing time before a refund is posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you’ve done all of this and you still have not received your refund yet, please contact us at {email address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h3 class=\"wp-block-heading\">Sale items</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Only regular priced items may be refunded. Sale items cannot be refunded.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Exchanges</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>We only replace items if they are defective or damaged. If you need to exchange it for the same item, send us an email at {email address} and send your item to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Gifts</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>If the item was marked as a gift when purchased and shipped directly to you, you’ll receive a gift credit for the value of your return. Once the returned item is received, a gift certificate will be mailed to you.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item wasn’t marked as a gift when purchased, or the gift giver had the order shipped to themselves to give to you later, we will send a refund to the gift giver and they will find out about your return.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Shipping returns</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>To return your product, you should mail your product to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. If you receive a refund, the cost of return shipping will be deducted from your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Depending on where you live, the time it may take for your exchanged product to reach you may vary.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are returning more expensive items, you may consider using a trackable shipping service or purchasing shipping insurance. We don’t guarantee that we will receive your returned item.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Need help?</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Contact us at {email} for questions related to refunds and returns.</p>\n<!-- /wp:paragraph -->','Refund and Returns Policy','','draft','closed','closed','','refund_returns','','','2026-06-01 13:48:47','0000-00-00 00:00:00','',0,'http://localhost:8090/?page_id=9',0,'page','',0),
(10,1,'2026-06-01 13:48:58','2026-06-01 13:48:58','','Bio-Baumwoll-T-Shirt','','trash','open','closed','','bio-baumwoll-t-shirt__trashed','','','2026-06-01 15:43:12','2026-06-01 15:43:12','',0,'http://localhost:8090/?product=bio-baumwoll-t-shirt',0,'product','',0),
(11,1,'2026-06-01 13:49:00','2026-06-01 13:49:00','','Kapuzenpullover Grau','','trash','open','closed','','kapuzenpullover-grau__trashed','','','2026-06-01 15:43:10','2026-06-01 15:43:10','',0,'http://localhost:8090/?product=kapuzenpullover-grau',0,'product','',0),
(12,1,'2026-06-01 13:49:02','2026-06-01 13:49:02','','Snapback Cap Schwarz','','trash','open','closed','','snapback-cap-schwarz__trashed','','','2026-06-01 15:43:08','2026-06-01 15:43:08','',0,'http://localhost:8090/?product=snapback-cap-schwarz',0,'product','',0),
(13,1,'2026-06-01 13:49:04','2026-06-01 13:49:04','','Canvas-Umhängetasche','','trash','open','closed','','canvas-umhaengetasche__trashed','','','2026-06-01 15:43:03','2026-06-01 15:43:03','',0,'http://localhost:8090/?product=canvas-umhaengetasche',0,'product','',0),
(14,1,'2026-06-01 13:49:06','2026-06-01 13:49:06','','Keramik-Tasse 300ml','','trash','open','closed','','keramik-tasse-300ml__trashed','','','2026-06-01 15:43:05','2026-06-01 15:43:05','',0,'http://localhost:8090/?product=keramik-tasse-300ml',0,'product','',0),
(15,1,'2026-06-01 13:49:08','2026-06-01 13:49:08','','Edelstahl-Trinkflasche','','trash','open','closed','','edelstahl-trinkflasche__trashed','','','2026-06-01 15:42:58','2026-06-01 15:42:58','',0,'http://localhost:8090/?product=edelstahl-trinkflasche',0,'product','',0),
(16,1,'2026-06-01 13:49:10','2026-06-01 13:49:10','','Duftkerze Vanille','','trash','open','closed','','duftkerze-vanille__trashed','','','2026-06-01 15:42:56','2026-06-01 15:42:56','',0,'http://localhost:8090/?product=duftkerze-vanille',0,'product','',0),
(17,1,'2026-06-01 13:49:12','2026-06-01 13:49:12','','Bluetooth-Kopfhörer','','trash','open','closed','','bluetooth-kopfhoerer__trashed','','','2026-06-01 15:42:50','2026-06-01 15:42:50','',0,'http://localhost:8090/?product=bluetooth-kopfhoerer',0,'product','',0),
(18,1,'2026-06-01 13:49:13','2026-06-01 13:49:13','','USB-C Schnellladegerät','','trash','open','closed','','usb-c-schnellladegeraet__trashed','','','2026-06-01 15:41:49','2026-06-01 15:41:49','',0,'http://localhost:8090/?product=usb-c-schnellladegeraet',0,'product','',0),
(19,1,'2026-06-01 13:49:15','2026-06-01 13:49:15','','Powerbank 10000mAh','','trash','open','closed','','powerbank-10000mah__trashed','','','2026-06-01 15:41:46','2026-06-01 15:41:46','',0,'http://localhost:8090/?product=powerbank-10000mah',0,'product','',0),
(20,0,'2026-06-01 13:49:28','2026-06-01 13:49:28','','img_TS-001','','inherit','open','closed','','img_ts-001','','','2026-06-01 13:49:28','2026-06-01 13:49:28','',10,'http://localhost:8090/wp-content/uploads/2026/06/img_TS-001.jpg',0,'attachment','image/jpeg',0),
(21,0,'2026-06-01 13:49:30','2026-06-01 13:49:30','','img_HD-002','','inherit','open','closed','','img_hd-002','','','2026-06-01 13:49:30','2026-06-01 13:49:30','',11,'http://localhost:8090/wp-content/uploads/2026/06/img_HD-002.jpg',0,'attachment','image/jpeg',0),
(22,0,'2026-06-01 13:49:32','2026-06-01 13:49:32','','img_CAP-003','','inherit','open','closed','','img_cap-003','','','2026-06-01 13:49:32','2026-06-01 13:49:32','',12,'http://localhost:8090/wp-content/uploads/2026/06/img_CAP-003.jpg',0,'attachment','image/jpeg',0),
(23,0,'2026-06-01 13:49:35','2026-06-01 13:49:35','','img_BAG-004','','inherit','open','closed','','img_bag-004','','','2026-06-01 13:49:35','2026-06-01 13:49:35','',13,'http://localhost:8090/wp-content/uploads/2026/06/img_BAG-004.jpg',0,'attachment','image/jpeg',0),
(24,0,'2026-06-01 13:49:37','2026-06-01 13:49:37','','img_MUG-005','','inherit','open','closed','','img_mug-005','','','2026-06-01 13:49:37','2026-06-01 13:49:37','',14,'http://localhost:8090/wp-content/uploads/2026/06/img_MUG-005.jpg',0,'attachment','image/jpeg',0),
(25,0,'2026-06-01 13:49:40','2026-06-01 13:49:40','','img_BTL-006','','inherit','open','closed','','img_btl-006','','','2026-06-01 13:49:40','2026-06-01 13:49:40','',15,'http://localhost:8090/wp-content/uploads/2026/06/img_BTL-006.jpg',0,'attachment','image/jpeg',0),
(26,0,'2026-06-01 13:49:42','2026-06-01 13:49:42','','img_CDL-007','','inherit','open','closed','','img_cdl-007','','','2026-06-01 13:49:42','2026-06-01 13:49:42','',16,'http://localhost:8090/wp-content/uploads/2026/06/img_CDL-007.jpg',0,'attachment','image/jpeg',0),
(27,0,'2026-06-01 13:49:44','2026-06-01 13:49:44','','img_EAR-008','','inherit','open','closed','','img_ear-008','','','2026-06-01 13:49:44','2026-06-01 13:49:44','',17,'http://localhost:8090/wp-content/uploads/2026/06/img_EAR-008.jpg',0,'attachment','image/jpeg',0),
(28,0,'2026-06-01 13:49:47','2026-06-01 13:49:47','','img_CHG-009','','inherit','open','closed','','img_chg-009','','','2026-06-01 13:49:47','2026-06-01 13:49:47','',18,'http://localhost:8090/wp-content/uploads/2026/06/img_CHG-009.jpg',0,'attachment','image/jpeg',0),
(29,0,'2026-06-01 13:49:49','2026-06-01 13:49:49','','img_PWR-010','','inherit','open','closed','','img_pwr-010','','','2026-06-01 13:49:49','2026-06-01 13:49:49','',19,'http://localhost:8090/wp-content/uploads/2026/06/img_PWR-010.jpg',0,'attachment','image/jpeg',0),
(31,1,'2021-07-17 09:49:14','2021-07-17 09:49:14','Diese Tiefenreinigung mit mineralischer Tonerde entfernt Unreinheiten, überschüssiges Öl und Ablagerungen aus den Poren. Die Haut wirkt danach sichtbar klarer, mattierter und die Poren erscheinen verfeinert. <strong>Anwendung:</strong> Auf die feuchte Haut massieren, kurz einwirken lassen und gründlich abspülen. Zwei- bis dreimal pro Woche als ergänzende Reinigung. Besonders geeignet für ölige und zu Unreinheiten neigende Haut.','Rare Earth Deep Pore Minimizing Cleansing','Tiefenreinigung mit Tonerde für sichtbar verfeinerte Poren.','publish','open','closed','','rare-earth-deep-pore-minimizing-cleansing-clay-mask','','','2026-06-02 10:25:17','2026-06-02 10:25:17','',0,'http://localhost:8090/?post_type=product&#038;p=31',0,'product','',37),
(33,1,'2026-06-01 14:02:08','0000-00-00 00:00:00','','Automatisch gespeicherter Entwurf','','auto-draft','open','open','','','','','2026-06-01 14:02:08','0000-00-00 00:00:00','',0,'http://localhost:8090/?p=33',0,'post','',0),
(34,1,'2021-07-17 08:42:31','2021-07-17 08:42:31','','COCOLO-hero2-1_1','','inherit','open','closed','','cocolo-hero2-1_1','','','2021-07-17 08:42:31','2021-07-17 08:42:31','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/COCOLO-hero2-1_1.jpg',0,'attachment','image/jpeg',0),
(35,1,'2021-07-17 09:42:25','2021-07-17 09:42:25','','woocommerce-placeholder','','inherit','open','closed','','woocommerce-placeholder-2','','','2021-07-17 09:42:25','2021-07-17 09:42:25','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/woocommerce-placeholder.png',0,'attachment','image/png',0),
(40,1,'2021-07-17 10:39:31','2021-07-17 10:39:31','Diese leichte Essence ist der ideale Zwischenschritt zwischen Reinigung und Pflege. Sie versorgt die Haut intensiv mit Feuchtigkeit, verfeinert das Hautbild und sorgt für einen klaren, strahlenden Teint. Die seidige Textur zieht sofort ein, ohne zu fetten. <strong>Anwendung:</strong> Morgens und abends auf die gereinigte Haut auftragen und sanft einklopfen, anschliessend mit Serum und Creme weiterpflegen. Geeignet für alle Hauttypen, auch für empfindliche Haut.','Facial Treatment Essence (Pitera Essence)','Leichte Essence für einen klaren, ebenmässigen Teint.','publish','open','closed','','facial-treatment-essence-pitera-essence','','','2026-06-02 10:25:17','2026-06-02 10:25:17','',0,'http://localhost:8090/?post_type=product&#038;p=40',0,'product','',34),
(42,1,'2021-07-17 10:42:05','2021-07-17 10:42:05','Das praktische Mini-Duo vereint einen cremigen Concealer und ein Rouge in einem kompakten Format – perfekt für unterwegs. Der Concealer kaschiert kleine Makel und Augenringe, das Rouge zaubert einen frischen, natürlichen Teint. <strong>Anwendung:</strong> Den Concealer punktuell auftupfen und verblenden, das Rouge auf die Wangenknochen geben. Die cremige Textur lässt sich auch mit den Fingern leicht verarbeiten. Für den schnellen Frischekick zwischendurch.','Mini Radiant Creamy Concealer and Blush','Praktisches Mini-Duo: cremiger Concealer und Rouge für unterwegs.','publish','open','closed','','mini-radiant-creamy-concealer-and-blush-customizable-set','','','2026-06-02 10:25:17','2026-06-02 10:25:17','',0,'http://localhost:8090/?post_type=product&#038;p=42',0,'product','',31),
(49,1,'2021-07-17 14:08:17','2021-07-17 14:08:17','','Mask Group (1) (1)','','inherit','open','closed','','mask-group-1-1','','','2021-07-17 14:08:17','2021-07-17 14:08:17','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Mask-Group-1-1.jpg',0,'attachment','image/jpeg',0),
(88,1,'2021-07-18 08:23:43','2021-07-18 08:23:43','','Hero','','inherit','open','closed','','hero','','','2021-07-18 08:23:43','2021-07-18 08:23:43','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Hero.jpg',0,'attachment','image/jpeg',0),
(93,1,'2021-07-18 08:40:16','2021-07-18 08:40:16','Diese erfrischende Maske kombiniert klärende Tonerde mit feuchtigkeitsspendendem Hyaluron – für ein verfeinertes Hautbild ohne austrocknenden Effekt. Sie absorbiert überschüssiges Öl und schenkt der Haut gleichzeitig einen frischen, gesunden Glow. <strong>Anwendung:</strong> Eine gleichmässige Schicht auf das gereinigte Gesicht auftragen, 10 Minuten einwirken lassen und abspülen. Ein- bis zweimal pro Woche. Ideal für normale bis ölige Haut.','Watermelon Glow Hyaluronic Clay Pore','Erfrischende Tonerde-Maske mit Hyaluron für strahlende Haut.','publish','open','closed','','watermelon-glow-hyaluronic-clay-pore-tight-facial-mask','','','2026-06-02 10:25:17','2026-06-02 10:25:17','',0,'http://localhost:8090/?post_type=product&#038;p=93',0,'product','',15),
(94,1,'2021-07-18 08:40:27','2021-07-18 08:40:27','Eine reichhaltige Feuchtigkeitscreme, die die Haut langanhaltend mit Feuchtigkeit versorgt und die natürliche Hautbarriere stärkt. Trotz der nährenden Formel zieht sie angenehm schnell ein und hinterlässt ein geschmeidiges Hautgefühl. <strong>Anwendung:</strong> Morgens und abends auf die gereinigte Haut auftragen. Besonders geeignet für trockene und empfindliche Haut sowie für die kalte Jahreszeit.','Ultra Facial Moisturizing Cream','Reichhaltige Feuchtigkeitscreme für geschmeidige, gepflegte Haut.','publish','open','closed','','ultra-facial-moisturizing-cream-with-squalane-combination','','','2026-06-02 10:25:17','2026-06-02 10:25:17','',0,'http://localhost:8090/?post_type=product&#038;p=94',0,'product','',32),
(95,1,'2021-07-18 08:40:49','2021-07-18 08:40:49','Das Deep Sweep Tonikum mit 2 % BHA (Beta-Hydroxysäure) reinigt die Poren porentief und löst sanft abgestorbene Hautschüppchen. So wirkt die Haut ebenmässiger, glatter und klarer. <strong>Anwendung:</strong> Nach der Reinigung mit einem Wattepad oder den Händen auftragen und einziehen lassen. Bei regelmässiger Anwendung verfeinert es das Hautbild spürbar. Für Mischhaut und zu Unreinheiten neigende Haut – bei empfindlicher Haut langsam einschleichen.','Deep Sweep 2% BHA Pore Cleaning Toner','Klärendes Gesichtswasser mit BHA für sichtbar verfeinerte Poren.','publish','open','closed','','deep-sweep-2-bha-pore-cleaning-toner-with-moringa','','','2026-06-02 10:25:17','2026-06-02 10:25:17','',0,'http://localhost:8090/?post_type=product&#038;p=95',0,'product','',20),
(96,1,'2021-07-18 08:40:56','2021-07-18 08:40:56','Dieses klärende Reinigungsgel befreit die Haut zuverlässig von Make-up, überschüssigem Talg und Unreinheiten – ohne sie auszutrocknen. Das Ergebnis ist ein frisches, mattiertes Hautbild mit sichtbar verfeinerten Poren. <strong>Anwendung:</strong> Eine kleine Menge mit kreisenden Bewegungen auf die feuchte Haut massieren und mit lauwarmem Wasser abspülen. Ideal für die tägliche Reinigung morgens und abends, besonders bei zu Unreinheiten neigender Haut.','Vinopure Pore Purifying Gel Cleanser','Klärendes Reinigungsgel für ein frisches, mattiertes Hautbild.','publish','open','closed','','vinopure-pore-purifying-gel-cleanser-salicylic-acid-combination','','','2026-06-02 10:25:17','2026-06-02 10:25:17','',0,'http://localhost:8090/?post_type=product&#038;p=96',0,'product','',19),
(97,1,'2021-07-18 08:41:13','2021-07-18 08:41:13','Ein cremiges Multitalent für Lippen und Wangen, das dem Gesicht im Handumdrehen einen warmen, sonnengeküssten Glow verleiht. Die Textur lässt sich mit den Fingerspitzen mühelos verblenden und wirkt natürlich – nie maskenhaft. <strong>Anwendung:</strong> Etwas Produkt auf die Wangenknochen und Lippen tupfen und sanft verblenden. Für einen frischen Alltagslook ebenso geeignet wie für den Abend. Dermatologisch verträglich und angenehm leicht auf der Haut.','Eternal Sunset Collection Lip and Cheek','Cremiges Duo für Lippen und Wangen – für einen natürlichen, warmen Glow.','publish','open','closed','','eternal-sunset-collection-lip-and-cheek-set-with-jojoba-oil','','','2026-06-02 10:25:17','2026-06-02 10:25:17','',0,'http://localhost:8090/?post_type=product&#038;p=97',0,'product','',15),
(130,1,'2021-07-18 19:31:36','2021-07-18 19:31:36','','pexels-karolina-grabowska-4397817','','inherit','open','closed','','pexels-karolina-grabowska-4397817','','','2021-07-18 19:31:36','2021-07-18 19:31:36','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/pexels-karolina-grabowska-4397817.jpg',0,'attachment','image/jpeg',0),
(132,1,'2021-07-18 19:33:37','2021-07-18 19:33:37','','pexels-ray-piedra-2721977','','inherit','open','closed','','pexels-ray-piedra-2721977','','','2021-07-18 19:33:37','2021-07-18 19:33:37','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/pexels-ray-piedra-2721977.jpg',0,'attachment','image/jpeg',0),
(134,1,'2021-07-18 19:34:29','2021-07-18 19:34:29','','pexels-teona-swift-6912808','','inherit','open','closed','','pexels-teona-swift-6912808','','','2021-07-18 19:34:29','2021-07-18 19:34:29','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/pexels-teona-swift-6912808.jpg',0,'attachment','image/jpeg',0),
(136,1,'2021-07-18 19:35:22','2021-07-18 19:35:22','','pexels-karolina-grabowska-5877662','','inherit','open','closed','','pexels-karolina-grabowska-5877662','','','2021-07-18 19:35:22','2021-07-18 19:35:22','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/pexels-karolina-grabowska-5877662.jpg',0,'attachment','image/jpeg',0),
(138,1,'2021-07-18 19:35:59','2021-07-18 19:35:59','','pexels-madison-inouye-1405762','','inherit','open','closed','','pexels-madison-inouye-1405762','','','2021-07-18 19:35:59','2021-07-18 19:35:59','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/pexels-madison-inouye-1405762.jpg',0,'attachment','image/jpeg',0),
(141,1,'2021-07-18 19:37:25','2021-07-18 19:37:25','','pexels-karolina-grabowska-4239013','','inherit','open','closed','','pexels-karolina-grabowska-4239013','','','2021-07-18 19:37:25','2021-07-18 19:37:25','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/pexels-karolina-grabowska-4239013.jpg',0,'attachment','image/jpeg',0),
(143,1,'2021-07-18 19:38:42','2021-07-18 19:38:42','','pexels-anna-urlapova-2968785','','inherit','open','closed','','pexels-anna-urlapova-2968785','','','2021-07-18 19:38:42','2021-07-18 19:38:42','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/pexels-anna-urlapova-2968785.jpg',0,'attachment','image/jpeg',0),
(145,1,'2021-07-18 19:41:14','2021-07-18 19:41:14','','pexels-karolina-grabowska-4210310','','inherit','open','closed','','pexels-karolina-grabowska-4210310','','','2021-07-18 19:41:14','2021-07-18 19:41:14','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/pexels-karolina-grabowska-4210310.jpg',0,'attachment','image/jpeg',0),
(146,1,'2021-07-18 19:41:24','2021-07-18 19:41:24','','pexels-jess-harper-sunday-2834934','','inherit','open','closed','','pexels-jess-harper-sunday-2834934','','','2021-07-18 19:41:24','2021-07-18 19:41:24','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/pexels-jess-harper-sunday-2834934.jpg',0,'attachment','image/jpeg',0),
(163,1,'2021-07-21 10:07:04','2021-07-21 10:07:04','','BOTIGA','','inherit','open','closed','','botiga-2','','','2021-07-21 10:07:04','2021-07-21 10:07:04','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/BOTIGA.svg',0,'attachment','image/svg+xml',0),
(171,1,'2021-07-21 10:59:41','2021-07-21 10:59:41','','gr','','inherit','open','closed','','gr','','','2021-07-21 10:59:41','2021-07-21 10:59:41','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/gr.jpg',0,'attachment','image/jpeg',0),
(172,1,'2021-07-21 11:01:20','2021-07-21 11:01:20','','gray','','inherit','open','closed','','gray','','','2021-07-21 11:01:20','2021-07-21 11:01:20','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/gray.jpg',0,'attachment','image/jpeg',0),
(184,1,'2021-07-21 15:08:45','2021-07-21 15:08:45','','Img-1','','inherit','open','closed','','img-1','','','2021-07-21 15:08:45','2021-07-21 15:08:45','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Img-1.jpg',0,'attachment','image/jpeg',0),
(189,1,'2021-07-21 16:24:08','2021-07-21 16:24:08','','Img (2)','','inherit','open','closed','','img-2','','','2021-07-21 16:24:08','2021-07-21 16:24:08','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Img-2.jpg',0,'attachment','image/jpeg',0),
(190,1,'2021-07-21 16:24:31','2021-07-21 16:24:31','','Img-3','','inherit','open','closed','','img-3','','','2021-07-21 16:24:31','2021-07-21 16:24:31','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Img-3.jpg',0,'attachment','image/jpeg',0),
(242,1,'2021-07-22 15:21:28','2021-07-22 15:21:28','','Hero2','','inherit','open','closed','','hero2','','','2021-07-22 15:21:28','2021-07-22 15:21:28','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Hero2.jpg',0,'attachment','image/jpeg',0),
(243,1,'2022-10-19 13:28:33','2022-10-19 13:28:33','','woocommerce-placeholder','','inherit','open','closed','','woocommerce-placeholder-3','','','2022-10-19 13:28:33','2022-10-19 13:28:33','',0,'http://localhost:8090/wp-content/uploads/sites/138/2022/10/woocommerce-placeholder.png',0,'attachment','image/png',0),
(249,1,'2021-07-22 17:49:17','2021-07-22 17:49:17','','Img (4)','','inherit','open','closed','','img-4','','','2021-07-22 17:49:17','2021-07-22 17:49:17','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Img-4.jpg',0,'attachment','image/jpeg',0),
(253,1,'2021-07-22 17:51:19','2021-07-22 17:51:19','','Mask Group-5','','inherit','open','closed','','mask-group-5','','','2021-07-22 17:51:19','2021-07-22 17:51:19','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Mask-Group-5.jpg',0,'attachment','image/jpeg',0),
(255,1,'2021-07-22 17:59:36','2021-07-22 17:59:36','','hbg (1)','','inherit','open','closed','','hbg-1','','','2021-07-22 17:59:36','2021-07-22 17:59:36','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/hbg-1.jpg',0,'attachment','image/jpeg',0),
(258,1,'2021-07-22 18:22:06','2021-07-22 18:22:06','','Rectangle 603 (1)','','inherit','open','closed','','rectangle-603-1','','','2021-07-22 18:22:06','2021-07-22 18:22:06','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-603-1.jpg',0,'attachment','image/jpeg',0),
(305,1,'2021-07-22 19:26:29','2021-07-22 19:26:29','','Rectangle-2','','inherit','open','closed','','rectangle-2','','','2021-07-22 19:26:29','2021-07-22 19:26:29','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-2.jpg',0,'attachment','image/jpeg',0),
(310,1,'2021-07-23 17:04:56','2021-07-23 17:04:56','','Glamifiedpeach','','inherit','open','closed','','glamifiedpeach','','','2021-07-23 17:04:56','2021-07-23 17:04:56','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Glamifiedpeach.jpg',0,'attachment','image/jpeg',0),
(311,1,'2021-07-23 17:05:17','2021-07-23 17:05:17','','Glamifiedviola','','inherit','open','closed','','glamifiedviola','','','2021-07-23 17:05:17','2021-07-23 17:05:17','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Glamifiedviola.jpg',0,'attachment','image/jpeg',0),
(315,1,'2021-07-23 18:13:20','2021-07-23 18:13:20','','Allure','','inherit','open','closed','','allure','','','2021-07-23 18:13:20','2021-07-23 18:13:20','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Allure.jpg',0,'attachment','image/jpeg',0),
(316,1,'2021-07-23 18:13:20','2021-07-23 18:13:20','','Allure','','inherit','open','closed','','allure-2','','','2021-07-23 18:13:20','2021-07-23 18:13:20','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Allure-1.jpg',0,'attachment','image/jpeg',0),
(317,1,'2021-07-23 18:13:38','2021-07-23 18:13:38','','Maven','','inherit','open','closed','','maven','','','2021-07-23 18:13:38','2021-07-23 18:13:38','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Maven.jpg',0,'attachment','image/jpeg',0),
(318,1,'2021-07-23 18:13:54','2021-07-23 18:13:54','','Beaucoup','','inherit','open','closed','','beaucoup','','','2021-07-23 18:13:54','2021-07-23 18:13:54','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Beaucoup.jpg',0,'attachment','image/jpeg',0),
(319,1,'2021-07-23 18:14:05','2021-07-23 18:14:05','','Pearlville','','inherit','open','closed','','pearlville-2','','','2021-07-23 18:14:05','2021-07-23 18:14:05','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Pearlville-1.jpg',0,'attachment','image/jpeg',0),
(320,1,'2021-07-23 18:14:27','2021-07-23 18:14:27','','Klassichic','','inherit','open','closed','','klassichic','','','2021-07-23 18:14:27','2021-07-23 18:14:27','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Klassichic.jpg',0,'attachment','image/jpeg',0),
(323,1,'2021-07-26 18:10:38','2021-07-26 18:10:38','','Rectangle 582 (1)','','inherit','open','closed','','rectangle-582-1','','','2021-07-26 18:10:38','2021-07-26 18:10:38','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-582-1.jpg',0,'attachment','image/jpeg',0),
(325,1,'2021-07-26 18:11:27','2021-07-26 18:11:27','','Rectangle 581 (1)','','inherit','open','closed','','rectangle-581-1','','','2021-07-26 18:11:27','2021-07-26 18:11:27','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-581-1.jpg',0,'attachment','image/jpeg',0),
(326,1,'2021-07-26 18:12:03','2021-07-26 18:12:03','','Rectangle 583 (1)','','inherit','open','closed','','rectangle-583-1','','','2021-07-26 18:12:03','2021-07-26 18:12:03','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-583-1.jpg',0,'attachment','image/jpeg',0),
(327,1,'2021-07-26 18:13:02','2021-07-26 18:13:02','','Rectangle 584 (1)','','inherit','open','closed','','rectangle-584-1','','','2021-07-26 18:13:02','2021-07-26 18:13:02','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-584-1.jpg',0,'attachment','image/jpeg',0),
(353,1,'2021-07-28 18:51:00','2021-07-28 18:51:00','','Heroc','','inherit','open','closed','','heroc','','','2021-07-28 18:51:00','2021-07-28 18:51:00','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/07/Heroc.jpg',0,'attachment','image/jpeg',0),
(385,1,'2021-12-02 15:24:51','2021-12-02 15:24:51','','favicon','','inherit','open','closed','','favicon','','','2021-12-02 15:24:51','2021-12-02 15:24:51','',0,'http://localhost:8090/wp-content/uploads/sites/138/2021/12/favicon.png',0,'attachment','image/png',0),
(386,1,'2022-10-19 13:25:58','2022-10-19 13:25:58','','Default Kit','','publish','closed','closed','','default-kit','','','2026-06-01 14:05:49','2026-06-01 14:05:49','',0,'http://localhost:8090/?elementor_library=default-kit',0,'elementor_library','',0),
(387,1,'2022-10-19 13:28:38','2022-10-19 13:28:38','<!-- wp:paragraph -->\n<p>Natürliche Pflege aus Berlin – entdecke unsere Auswahl an hochwertiger Kosmetik für deine tägliche Routine.</p>\n<!-- /wp:paragraph -->','Shop','','publish','closed','closed','','shop','','','2026-06-02 07:01:42','2026-06-02 07:01:42','',0,'http://localhost:8090/shop/',0,'page','',0),
(388,1,'2022-10-19 13:28:38','2022-10-19 13:28:38','<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->','Cart','','publish','closed','closed','','cart','','','2026-06-02 10:00:20','2026-06-02 10:00:20','',0,'http://localhost:8090/cart/',0,'page','',0),
(389,1,'2022-10-19 13:28:38','2022-10-19 13:28:38','<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->','Checkout','','publish','closed','closed','','checkout','','','2026-06-02 10:00:20','2026-06-02 10:00:20','',0,'http://localhost:8090/checkout/',0,'page','',0),
(390,1,'2022-10-19 13:28:38','2022-10-19 13:28:38','<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->','My account','','publish','closed','closed','','my-account-2','','','2022-10-19 13:28:38','2022-10-19 13:28:38','',0,'http://localhost:8090/my-account/',0,'page','',0),
(391,1,'2022-10-19 13:30:27','2022-10-19 13:30:27','<style>/*! elementor - v3.6.7 - 03-07-2022 */\n.elementor-heading-title{padding:0;margin:0;line-height:1}.elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a{color:inherit;font-size:inherit;line-height:inherit}.elementor-widget-heading .elementor-heading-title.elementor-size-small{font-size:15px}.elementor-widget-heading .elementor-heading-title.elementor-size-medium{font-size:19px}.elementor-widget-heading .elementor-heading-title.elementor-size-large{font-size:29px}.elementor-widget-heading .elementor-heading-title.elementor-size-xl{font-size:39px}.elementor-widget-heading .elementor-heading-title.elementor-size-xxl{font-size:59px}</style><h1>Headline that grabs people\'s attention</h1>		\n			<a href=\"http://localhost:8090/shop/\" role=\"button\">\n						JETZT EINKAUFEN\n					</a>\n			<h2>Empfohlen Collection</h2>		\n		<p>A powerful headline about your product’s features to give focus to your chosen product collection</p>[products columns=\"3\" limit=\"3\"]		\n			<h2>Highlighted Section</h2>		\n		<p>What differentiates you from the competition? Use this section to talk about it. Don’t forget to talk about the benefits.</p>		\n			<a href=\"http://localhost:8090/shop/\" role=\"button\">\n						JETZT EINKAUFEN\n					</a>\n			<h2>Empfohlen Categories</h2>		\n		<p>Entdecke unsere Kollektion natürlicher Pflegeprodukte. Select imagery and name that relates to the product category.</p>		\n			<style>/*! elementor - v3.6.7 - 03-07-2022 */\n.elementor-widget-image{text-align:center}.elementor-widget-image a{display:inline-block}.elementor-widget-image a img[src$=\".svg\"]{width:48px}.elementor-widget-image img{vertical-align:middle;display:inline-block}</style>									<figure>\n											<a href=\"http://localhost:8090/product-category/cosmetics/\">\n							<img width=\"510\" height=\"490\" src=\"http://localhost:8090/wp-content/uploads/2021/07/Rectangle-581-1.jpg\" alt=\"\" loading=\"lazy\" srcset=\"http://localhost:8090/wp-content/uploads/2021/07/Rectangle-581-1.jpg 510w, http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-581-1-300x288.jpg 300w, http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-581-1-380x365.jpg 380w\" sizes=\"(max-width: 510px) 100vw, 510px\" />								</a>\n											<figcaption>Makeup</figcaption>\n										</figure>\n												<figure>\n											<a href=\"http://localhost:8090/product-category/cosmetics/\">\n							<img width=\"510\" height=\"490\" src=\"http://localhost:8090/wp-content/uploads/2021/07/Rectangle-582-1.jpg\" alt=\"\" loading=\"lazy\" srcset=\"http://localhost:8090/wp-content/uploads/2021/07/Rectangle-582-1.jpg 510w, http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-582-1-300x288.jpg 300w, http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-582-1-380x365.jpg 380w\" sizes=\"(max-width: 510px) 100vw, 510px\" />								</a>\n											<figcaption>Lipstick</figcaption>\n										</figure>\n												<figure>\n											<a href=\"http://localhost:8090/product-category/cosmetics/\">\n							<img width=\"510\" height=\"490\" src=\"http://localhost:8090/wp-content/uploads/2021/07/Rectangle-583-1.jpg\" alt=\"\" loading=\"lazy\" srcset=\"http://localhost:8090/wp-content/uploads/2021/07/Rectangle-583-1.jpg 510w, http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-583-1-300x288.jpg 300w, http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-583-1-380x365.jpg 380w\" sizes=\"(max-width: 510px) 100vw, 510px\" />								</a>\n											<figcaption>Bath Products</figcaption>\n										</figure>\n												<figure>\n											<a href=\"http://localhost:8090/product-category/cosmetics/\">\n							<img width=\"510\" height=\"490\" src=\"http://localhost:8090/wp-content/uploads/2021/07/Rectangle-584-1.jpg\" alt=\"\" loading=\"lazy\" srcset=\"http://localhost:8090/wp-content/uploads/2021/07/Rectangle-584-1.jpg 510w, http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-584-1-300x288.jpg 300w, http://localhost:8090/wp-content/uploads/sites/138/2021/07/Rectangle-584-1-380x365.jpg 380w\" sizes=\"(max-width: 510px) 100vw, 510px\" />								</a>\n											<figcaption>Treatments</figcaption>\n										</figure>','Home','','publish','closed','closed','','home','','','2022-10-19 13:30:27','2022-10-19 13:30:27','',0,'http://localhost:8090/?page_id=14',0,'page','',0),
(392,1,'2022-10-19 13:45:03','2022-10-19 13:45:03','.page-id-393 .wpforms-form button[type=submit] {\n    background-color: #000 !important;\n    border-color: #000 !important;\n    color: #fff !important;\n}\n \n.page-id-393 .wpforms-form button[type=submit]:hover {\n    background-color: #000 !important;\n}\n.page-id-393 .wpforms-form input,\n.page-id-393 .wpforms-form textarea {\n	border-color: #000 !important;\n}\n\ndiv.wpforms-container-full, div.wpforms-container-full .wpforms-form * {\n	position: relative;\n}\n\n.elementor-invisible {\n	opacity: 0;\n}','botiga','','publish','closed','closed','','botiga','','','2022-10-19 13:45:03','2022-10-19 13:45:03','',0,'http://localhost:8090/2022/10/19/botiga/',0,'custom_css','',0),
(393,1,'2022-10-19 13:58:21','2022-10-19 13:58:21','','Blog','','publish','closed','closed','','blog','','','2022-10-19 13:58:21','2022-10-19 13:58:21','',0,'http://localhost:8090/?page_id=391',0,'page','',0),
(394,1,'2022-10-19 13:58:34','2022-10-19 13:58:34','<style>/*! elementor - v3.6.7 - 03-07-2022 */\n.elementor-heading-title{padding:0;margin:0;line-height:1}.elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a{color:inherit;font-size:inherit;line-height:inherit}.elementor-widget-heading .elementor-heading-title.elementor-size-small{font-size:15px}.elementor-widget-heading .elementor-heading-title.elementor-size-medium{font-size:19px}.elementor-widget-heading .elementor-heading-title.elementor-size-large{font-size:29px}.elementor-widget-heading .elementor-heading-title.elementor-size-xl{font-size:39px}.elementor-widget-heading .elementor-heading-title.elementor-size-xxl{font-size:59px}</style><h2>Kontakt</h2>		\n			<style>/*! elementor - v3.6.7 - 03-07-2022 */\n.elementor-widget-google_maps .elementor-widget-container{overflow:hidden}.elementor-widget-google_maps iframe{height:300px}</style>		\n			<iframe frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\"\n					src=\"https://maps.google.com/maps?q=Friedrichstra%C3%9Fe%20100%2C%2010117%20Berlin%2C%20Deutschland&#038;t=m&#038;z=10&#038;output=embed&#038;iwloc=near\"\n					title=\"Friedrichstraße 100, 10117 Berlin, Deutschland\"\n					aria-label=\"Friedrichstraße 100, 10117 Berlin, Deutschland\"\n			></iframe>\n			<h2>Leave Us a Message</h2>		\n		[wpforms id=\"438\" title=\"false\" description=\"false\"]		\n			<h2>Unser Geschäft</h2>		\n		<p style=\"box-sizing: inherit; color: #212121; font-family: Inter, sans-serif;\">Friedrichstraße 100, 10117 Berlin, Deutschland</p><p style=\"box-sizing: inherit; color: #212121; font-family: Inter, sans-serif;\">PHONE:<br />+49 30 901820</p><p style=\"box-sizing: inherit; color: #212121; font-family: Inter, sans-serif;\">E-MAIL:<br />kontakt@cocolo-berlin.de</p>		\n			<h2>Store Hours</h2>		\n		<p style=\"box-sizing: inherit; color: #212121; font-family: Inter, sans-serif;\">Sun: Closed<br />Mon to Sat: 10 AM – 5:30 PM</p>		\n			<style>/*! elementor - v3.6.7 - 03-07-2022 */\n.e-container.e-container--row .elementor-spacer-inner{width:var(--spacer-size)}.e-container.e-container--column .elementor-spacer-inner,.elementor-column .elementor-spacer-inner{height:var(--spacer-size)}</style>','Kontakt','','publish','closed','closed','','kontakt','','','2026-06-02 10:54:00','2026-06-02 10:54:00','',0,'http://localhost:8090/?page_id=393',0,'page','',0),
(395,1,'2026-06-02 07:18:23','2022-10-19 17:31:11','','Startseite','','publish','closed','closed','','395','','','2026-06-02 07:18:23','2026-06-02 07:18:23','',0,'http://localhost:8090/?p=395',1,'nav_menu_item','',0),
(396,1,'2022-12-06 23:15:59','2022-10-19 17:31:11',' ','','','publish','closed','closed','','396','','','2022-12-06 23:15:59','2022-10-19 17:31:11','',0,'http://localhost:8090/?p=396',2,'nav_menu_item','',0),
(397,1,'2026-06-02 07:18:25','2022-10-19 17:31:11',' ','','','publish','closed','closed','','397','','','2026-06-02 07:18:25','2026-06-02 07:18:25','',0,'http://localhost:8090/?p=397',4,'nav_menu_item','',0),
(398,1,'2022-12-06 23:15:59','2022-10-19 17:31:11',' ','','','publish','closed','closed','','398','','','2022-12-06 23:15:59','2022-10-19 17:31:11','',0,'http://localhost:8090/?p=398',3,'nav_menu_item','',0),
(399,1,'2026-06-02 07:18:27','2022-10-19 17:31:35','','Startseite','','publish','closed','closed','','399','','','2026-06-02 07:18:27','2026-06-02 07:18:27','',0,'http://localhost:8090/?p=399',1,'nav_menu_item','',0),
(400,1,'2022-10-19 17:31:35','2022-10-19 17:31:35',' ','','','publish','closed','closed','','400','','','2022-10-19 17:31:35','2022-10-19 17:31:35','',0,'http://localhost:8090/?p=400',2,'nav_menu_item','',0),
(401,1,'2022-10-19 17:31:35','2022-10-19 17:31:35',' ','','','publish','closed','closed','','401','','','2022-10-19 17:31:35','2022-10-19 17:31:35','',0,'http://localhost:8090/?p=401',3,'nav_menu_item','',0),
(402,1,'2026-06-02 07:18:28','2022-10-19 17:32:19','','Versand','','publish','closed','closed','','shipping','','','2026-06-02 07:18:28','2026-06-02 07:18:28','',0,'http://localhost:8090/?p=402',1,'nav_menu_item','',0),
(403,1,'2026-06-02 07:18:30','2022-10-19 17:32:19','','AGB','','publish','closed','closed','','terms','','','2026-06-02 07:18:30','2026-06-02 07:18:30','',0,'http://localhost:8090/?p=403',2,'nav_menu_item','',0),
(404,1,'2026-06-02 07:18:32','2022-10-19 17:32:19','','Datenschutz','','publish','closed','closed','','policy','','','2026-06-02 07:18:32','2026-06-02 07:18:32','',0,'http://localhost:8090/?p=404',3,'nav_menu_item','',0),
(405,1,'2022-10-19 13:29:57','2022-10-19 13:29:57','{\"version\": 2, \"isGlobalStylesUserThemeJSON\": true }','Custom Styles','','publish','closed','closed','','wp-global-styles-botiga','','','2022-10-19 13:29:57','2022-10-19 13:29:57','',0,'http://localhost:8090/2022/10/19/wp-global-styles-botiga/',0,'wp_global_styles','',0),
(438,1,'2022-10-19 18:07:45','2022-10-19 18:07:45','{\"fields\":[{\"id\":\"0\",\"type\":\"name\",\"label\":\"Name\",\"format\":\"simple\",\"description\":\"\",\"required\":\"1\",\"size\":\"large\",\"simple_placeholder\":\"\",\"simple_default\":\"\",\"first_placeholder\":\"\",\"first_default\":\"\",\"middle_placeholder\":\"\",\"middle_default\":\"\",\"last_placeholder\":\"\",\"last_default\":\"\",\"css\":\"wpforms-one-half wpforms-first\"},{\"id\":\"1\",\"type\":\"email\",\"label\":\"Email\",\"description\":\"\",\"required\":\"1\",\"size\":\"large\",\"placeholder\":\"\",\"confirmation_placeholder\":\"\",\"default_value\":false,\"filter_type\":\"\",\"allowlist\":\"\",\"denylist\":\"\",\"css\":\"wpforms-one-half\"},{\"id\":\"2\",\"type\":\"textarea\",\"label\":\"Comment or Message\",\"description\":\"\",\"required\":\"1\",\"size\":\"large\",\"placeholder\":\"\",\"limit_count\":\"1\",\"limit_mode\":\"characters\",\"default_value\":\"\",\"css\":\"\"}],\"id\":\"438\",\"field_id\":3,\"settings\":{\"form_title\":\"[Beauty Elementor] Simple Contact Form\",\"form_desc\":\"\",\"submit_text\":\"Send message\",\"submit_text_processing\":\"Sending...\",\"antispam\":\"1\",\"form_class\":\"\",\"submit_class\":\"\",\"ajax_submit\":\"1\",\"notification_enable\":\"1\",\"notifications\":{\"1\":{\"email\":\"{admin_email}\",\"subject\":\"New Entry: Simple Contact Form\",\"sender_name\":\"Botiga\",\"sender_address\":\"{admin_email}\",\"replyto\":\"{field_id=\\\"1\\\"}\",\"message\":\"{all_fields}\"}},\"confirmations\":{\"1\":{\"type\":\"message\",\"message\":\"<p>Thanks for contacting us! We will be in touch with you shortly.<\\/p>\",\"message_scroll\":\"1\",\"page\":\"391\",\"redirect\":\"\"}},\"form_tags\":[]},\"meta\":{\"template\":\"4dbf022985a4fe4bda4a80365011a3a0\"}}','[Beauty Elementor] Simple Contact Form','','publish','closed','closed','','simple-contact-form','','','2022-10-19 18:07:45','2022-10-19 18:07:45','',0,'http://localhost:8090/?post_type=wpforms&amp;p=438',0,'wpforms','',0),
(439,1,'2026-06-01 14:05:49','2026-06-01 14:05:49','','Default Kit','','inherit','closed','closed','','386-revision-v1','','','2026-06-01 14:05:49','2026-06-01 14:05:49','',386,'http://localhost:8090/?p=439',0,'revision','',0),
(440,1,'2026-06-01 14:09:18','2026-06-01 14:09:18','{\n    \"botiga::botiga_header_menu_font\": {\n        \"value\": \"{\\\"font\\\":\\\"Sumana\\\",\\\"regularweight\\\":\\\"400\\\",\\\"category\\\":\\\"serif\\\"}\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2026-06-01 14:09:18\"\n    }\n}','','','trash','closed','closed','','fa4177c3-10b3-4418-b81e-a5c84bbb7427','','','2026-06-01 14:09:18','2026-06-01 14:09:18','',0,'http://localhost:8090/fa4177c3-10b3-4418-b81e-a5c84bbb7427/',0,'customize_changeset','',0),
(441,0,'2026-06-02 06:04:14','2026-06-02 06:04:14','','','','draft','closed','closed','','','','','2026-06-02 06:04:14','2026-06-02 06:04:14','',0,'http://localhost:8090/?post_type=shop_order_placehold&p=441',0,'shop_order_placehold','',2),
(442,1,'2026-06-02 07:00:22','2026-06-02 07:00:22','<p>Naturkosmetik verspricht Pflege im Einklang mit der Haut – doch was bedeutet das konkret? Ein Blick auf die wichtigsten Inhaltsstoffe hilft, gute von werblicher Pflege zu unterscheiden und bewusster auszuwählen.</p>\n\n<h2>Die INCI-Liste lesen lernen</h2>\n<p>Jedes Kosmetikprodukt trägt eine Inhaltsstoffliste nach dem INCI-Standard (International Nomenclature of Cosmetic Ingredients). Die Stoffe sind nach Menge geordnet: Was zuerst steht, ist am meisten enthalten. Pflanzenöle erscheinen oft unter ihren lateinischen Namen, etwa <em>Butyrospermum Parkii</em> für Sheabutter oder <em>Simmondsia Chinensis</em> für Jojobaöl.</p>\n\n<h2>Typische Bausteine guter Pflege</h2>\n<ul>\n<li><strong>Pflanzliche Öle und Butter</strong> spenden Lipide und unterstützen die Hautbarriere.</li>\n<li><strong>Feuchthaltestoffe</strong> wie Glycerin binden Wasser in den oberen Hautschichten.</li>\n<li><strong>Ätherische Öle</strong> sorgen für Duft und können das Wohlbefinden fördern – in geringer Dosierung.</li>\n<li><strong>Antioxidantien</strong> wie Vitamin E (<em>Tocopherol</em>) schützen empfindliche Öle vor dem Ranzigwerden.</li>\n</ul>\n\n<h2>Worauf es wirklich ankommt</h2>\n<p>Nicht „natürlich\" allein macht ein Produkt gut, sondern die passende Kombination für deinen Hauttyp. Wenige, hochwertige Inhaltsstoffe sind oft sinnvoller als eine lange Liste. Wer zu Empfindlichkeiten neigt, achtet auf eine überschaubare Rezeptur und testet neue Produkte zuerst an einer kleinen Hautstelle.</p>\n\n<p>Im Zweifel gilt: Lieber verstehen, was drinsteckt, als blind dem Etikett zu vertrauen. So wird aus Pflege eine bewusste Entscheidung.</p>\n','Naturkosmetik verstehen: Was steckt wirklich drin?','','publish','open','open','','naturkosmetik-verstehen-was-steckt-wirklich-drin','','','2026-06-02 07:00:22','2026-06-02 07:00:22','',0,'http://localhost:8090/naturkosmetik-verstehen-was-steckt-wirklich-drin/',0,'post','',0),
(443,1,'2026-06-02 07:00:24','2026-06-02 07:00:24','<p>Sheabutter, Jojoba- und Mandelöl gehören zu den Klassikern natürlicher Hautpflege. Sie unterscheiden sich aber deutlich in Konsistenz und Wirkung – und genau das macht sie für verschiedene Bedürfnisse interessant.</p>\n\n<h2>Sheabutter: reichhaltiger Schutz</h2>\n<p>Sheabutter ist fest und schmilzt auf der Haut. Sie ist reich an Fettsäuren und eignet sich besonders für trockene, beanspruchte Stellen wie Ellbogen, Knie oder Hände. Als Schutzschicht hilft sie, Feuchtigkeit in der Haut zu halten.</p>\n\n<h2>Jojobaöl: dem Hauttalg ähnlich</h2>\n<p>Streng genommen ist Jojoba ein flüssiges Wachs. Seine Struktur ähnelt dem hauteigenen Talg, weshalb es schnell einzieht und kaum fettet. Das macht es zu einem guten Allrounder – auch für Mischhaut.</p>\n\n<h2>Mandelöl: mild und ausgleichend</h2>\n<p>Mandelöl ist leicht, zieht angenehm ein und gilt als besonders verträglich. Es wird gern für empfindliche oder zu Trockenheit neigende Haut verwendet und eignet sich auch für eine sanfte Massage.</p>\n\n<h2>So findest du dein Öl</h2>\n<ul>\n<li><strong>Sehr trockene Haut:</strong> reichhaltige Butter als Abschluss der Pflege.</li>\n<li><strong>Normale bis Mischhaut:</strong> leichtes, schnell einziehendes Öl.</li>\n<li><strong>Empfindliche Haut:</strong> milde, reizarme Öle, sparsam dosiert.</li>\n</ul>\n\n<p>Pflanzenöle sind keine Wundermittel, aber vielseitige Begleiter. Wer ihre Eigenschaften kennt, kann gezielter wählen – statt nach dem Zufallsprinzip zu kaufen.</p>\n','Sheabutter, Jojoba & Mandelöl: Pflanzenöle und ihre Wirkung','','publish','open','open','','sheabutter-jojoba-mandeloel-pflanzenoele-und-ihre-wirkung','','','2026-06-02 07:00:24','2026-06-02 07:00:24','',0,'http://localhost:8090/sheabutter-jojoba-mandeloel-pflanzenoele-und-ihre-wirkung/',0,'post','',0),
(444,1,'2026-06-02 07:00:27','2026-06-02 07:00:27','<p>Viele Produkte, aber in welcher Reihenfolge? Eine gute Pflegeroutine muss nicht kompliziert sein. Entscheidend ist das Prinzip: von der leichtesten zur reichhaltigsten Textur.</p>\n\n<h2>Die Grundregel: dünn vor dick</h2>\n<p>Trage Produkte mit hohem Wasseranteil zuerst auf, fetthaltige Texturen zuletzt. So können leichte Wirkstoffe einziehen, bevor ein reichhaltiges Öl oder eine Creme sie „versiegelt\".</p>\n\n<h2>Eine einfache Reihenfolge</h2>\n<ol>\n<li><strong>Reinigung</strong> – Schmutz und Talg sanft entfernen.</li>\n<li><strong>Gesichtswasser / Toner</strong> – die Haut auf die Pflege vorbereiten.</li>\n<li><strong>Serum oder Wirkstoffpflege</strong> – gezielte Feuchtigkeit oder Pflegestoffe.</li>\n<li><strong>Creme oder Öl</strong> – als Abschluss, um Feuchtigkeit zu halten.</li>\n<li><strong>Sonnenschutz</strong> – tagsüber immer als letzter Schritt.</li>\n</ol>\n\n<h2>Morgens und abends unterscheiden</h2>\n<p>Am Morgen liegt der Fokus auf Schutz (Feuchtigkeit, Sonnenschutz), am Abend auf Regeneration (reichhaltigere Pflege). Weniger ist oft mehr: Drei gut abgestimmte Schritte bringen meist mehr als sieben halbherzige.</p>\n\n<p>Gib neuen Produkten ein paar Wochen Zeit und beobachte, wie deine Haut reagiert. Eine Routine wirkt vor allem durch Regelmässigkeit.</p>\n','Die richtige Reihenfolge: So baust du deine Pflegeroutine auf','','publish','open','open','','die-richtige-reihenfolge-so-baust-du-deine-pflegeroutine-auf','','','2026-06-02 07:00:27','2026-06-02 07:00:27','',0,'http://localhost:8090/die-richtige-reihenfolge-so-baust-du-deine-pflegeroutine-auf/',0,'post','',0),
(445,1,'2026-06-02 07:00:31','2026-06-02 07:00:31','<p>Hautpflege ist mehr als Kosmetik – sie kann ein kleiner Anker im Alltag sein. Wer die täglichen Schritte bewusst gestaltet, gönnt sich neben der Pflege für die Haut auch eine Pause für den Kopf.</p>\n\n<h2>Vom Pflichtprogramm zum Moment</h2>\n<p>Statt morgens hektisch etwas aufzutragen, lohnt es sich, kurz innezuhalten. Schon ein bewusster Atemzug, das Auftragen einer Creme mit sanften Bewegungen oder der Duft eines Pflegeprodukts können einen ruhigen Start in den Tag unterstützen.</p>\n\n<h2>Kleine Rituale, die sich leicht einbauen lassen</h2>\n<ul>\n<li><strong>Gesichtsmassage:</strong> die Creme mit kreisenden Bewegungen einarbeiten – das fördert die Durchblutung und entspannt.</li>\n<li><strong>Bewusster Duft:</strong> ein dezent beduftetes Produkt mit den Sinnen wahrnehmen.</li>\n<li><strong>Abendliche Routine:</strong> die Pflege als Signal nutzen, dass der Tag nun ausklingt.</li>\n</ul>\n\n<h2>Achtsamkeit statt Perfektion</h2>\n<p>Es geht nicht darum, möglichst viele Produkte zu verwenden, sondern den Moment bewusst zu erleben. Zwei Minuten Aufmerksamkeit reichen, um aus Routine ein Ritual zu machen – und sich selbst etwas Gutes zu tun.</p>\n','Pflege als Ritual: Mehr Achtsamkeit in der täglichen Routine','','publish','open','open','','pflege-als-ritual-mehr-achtsamkeit-in-der-taeglichen-routine','','','2026-06-02 07:00:31','2026-06-02 07:00:31','',0,'http://localhost:8090/pflege-als-ritual-mehr-achtsamkeit-in-der-taeglichen-routine/',0,'post','',0),
(446,1,'2026-06-02 07:00:34','2026-06-02 07:00:34','<p>Sobald es kälter wird, spannt und juckt die Haut bei vielen Menschen. Das ist kein Zufall: Die Kombination aus Kälte, Wind und trockener Heizungsluft setzt der Hautbarriere zu. Mit ein paar einfachen Anpassungen lässt sich gegensteuern.</p>\n\n<h2>Warum die Haut im Winter leidet</h2>\n<p>Bei niedrigen Temperaturen produziert die Haut weniger Talg, der sie normalerweise vor Feuchtigkeitsverlust schützt. Heizungsluft entzieht ihr zusätzlich Wasser. Das Ergebnis: eine geschwächte Barriere, die schneller austrocknet und empfindlicher reagiert.</p>\n\n<h2>Sanft gegensteuern</h2>\n<ul>\n<li><strong>Reichhaltiger pflegen:</strong> im Winter ruhig zu etwas gehaltvolleren Texturen greifen.</li>\n<li><strong>Nicht zu heiss duschen:</strong> heisses Wasser entfettet die Haut zusätzlich.</li>\n<li><strong>Milde Reinigung:</strong> aggressive Produkte meiden, die die Barriere weiter schwächen.</li>\n<li><strong>Luftfeuchtigkeit erhöhen:</strong> Lüften und etwas Feuchtigkeit im Raum helfen auch der Haut.</li>\n<li><strong>Genug trinken:</strong> Hautpflege beginnt auch von innen.</li>\n</ul>\n\n<h2>Wann zur Fachperson?</h2>\n<p>Hält die Trockenheit trotz guter Pflege an, kommen Rötungen, Risse oder starker Juckreiz hinzu, ist ärztlicher Rat sinnvoll – dahinter kann auch eine Hauterkrankung stecken.</p>\n\n<p><em>Hinweis: Dieser Beitrag dient der allgemeinen Information und ersetzt keine medizinische Beratung.</em></p>\n','Trockene Haut im Winter: Ursachen verstehen, sanft gegensteuern','','publish','open','open','','trockene-haut-im-winter-ursachen-verstehen-sanft-gegensteuern','','','2026-06-02 07:00:34','2026-06-02 07:00:34','',0,'http://localhost:8090/trockene-haut-im-winter-ursachen-verstehen-sanft-gegensteuern/',0,'post','',0),
(447,1,'2026-06-02 07:00:38','2026-06-02 07:00:38','<p>Ein dezenter Duft kann die Stimmung verändern, beim Entspannen helfen oder einen Raum gemütlicher wirken lassen. Ätherische Öle und Duftkerzen sind dafür beliebte Begleiter – wenn man sie bewusst einsetzt.</p>\n\n<h2>Wie Düfte auf uns wirken</h2>\n<p>Gerüche werden im Gehirn eng mit Emotionen und Erinnerungen verarbeitet. Deshalb können bestimmte Düfte als beruhigend (etwa Lavendel) oder belebend (etwa Zitrus) empfunden werden. Die Wirkung ist individuell – was die eine Person entspannt, empfindet eine andere als zu intensiv.</p>\n\n<h2>Tipps für den Alltag</h2>\n<ul>\n<li><strong>Sparsam dosieren:</strong> weniger Duft wirkt oft angenehmer und natürlicher.</li>\n<li><strong>Gut lüften:</strong> frische Luft zwischendurch verhindert, dass der Duft zu schwer wird.</li>\n<li><strong>Kerzen sicher abbrennen:</strong> nie unbeaufsichtigt lassen und auf einen stabilen, hitzebeständigen Untergrund stellen.</li>\n<li><strong>Rücksicht nehmen:</strong> in Gegenwart von Schwangeren, Kleinkindern oder Haustieren auf intensive ätherische Öle verzichten.</li>\n</ul>\n\n<h2>Atmosphäre bewusst gestalten</h2>\n<p>Ob beim Lesen, Baden oder zur Ruhe kommen am Abend: Ein passender Duft kann einen Moment rahmen und ihn besonders machen. Entscheidend ist nicht die Menge, sondern dass er zu dir und zur Situation passt.</p>\n','Ätherische Öle und Duftkerzen: Wirkung auf Stimmung und Raumklima','','publish','open','open','','aetherische-oele-und-duftkerzen-wirkung-auf-stimmung-und-raumklima','','','2026-06-02 07:00:38','2026-06-02 07:00:38','',0,'http://localhost:8090/aetherische-oele-und-duftkerzen-wirkung-auf-stimmung-und-raumklima/',0,'post','',0),
(448,0,'2026-06-02 07:01:42','2026-06-02 07:01:42','<!-- wp:paragraph -->\n<p>Natürliche Pflege aus Berlin – entdecke unsere Auswahl an hochwertiger Kosmetik für deine tägliche Routine.</p>\n<!-- /wp:paragraph -->','Shop','','inherit','closed','closed','','387-revision-v1','','','2026-06-02 07:01:42','2026-06-02 07:01:42','',387,'http://localhost:8090/?p=448',0,'revision','',0),
(450,0,'2026-06-02 09:24:15','2026-06-02 09:24:15','','','','draft','closed','closed','','','','','2026-06-02 09:24:15','2026-06-02 09:24:15','',0,'http://localhost:8090/?post_type=shop_order_placehold&p=450',0,'shop_order_placehold','',2),
(451,0,'2026-06-02 10:00:20','2026-06-02 10:00:20','<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->','Cart','','inherit','closed','closed','','388-revision-v1','','','2026-06-02 10:00:20','2026-06-02 10:00:20','',388,'http://localhost:8090/?p=451',0,'revision','',0),
(452,0,'2026-06-02 10:00:20','2026-06-02 10:00:20','<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->','Checkout','','inherit','closed','closed','','389-revision-v1','','','2026-06-02 10:00:20','2026-06-02 10:00:20','',389,'http://localhost:8090/?p=452',0,'revision','',0);
/*!40000 ALTER TABLE `wp_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_relationships`
--

LOCK TABLES `wp_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_term_relationships` VALUES
(10,2,0),
(11,2,0),
(12,2,0),
(13,2,0),
(14,2,0),
(15,2,0),
(16,2,0),
(17,2,0),
(18,2,0),
(19,2,0),
(31,2,0),
(31,13,0),
(31,20,0),
(40,2,0),
(40,14,0),
(40,20,0),
(42,2,0),
(42,14,0),
(42,20,0),
(93,2,0),
(93,13,0),
(93,20,0),
(94,2,0),
(94,14,0),
(94,20,0),
(95,2,0),
(95,14,0),
(95,20,0),
(96,2,0),
(96,14,0),
(96,20,0),
(97,2,0),
(97,13,0),
(97,20,0),
(395,23,0),
(396,23,0),
(397,23,0),
(398,23,0),
(399,21,0),
(400,21,0),
(401,21,0),
(402,22,0),
(403,22,0),
(404,22,0),
(442,24,0),
(443,24,0),
(444,25,0),
(445,26,0),
(446,27,0),
(447,26,0);
/*!40000 ALTER TABLE `wp_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_taxonomy`
--

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_term_taxonomy` VALUES
(1,1,'category','',0,0),
(2,2,'product_type','',0,8),
(3,3,'product_type','',0,0),
(4,4,'product_type','',0,0),
(5,5,'product_type','',0,0),
(6,6,'product_visibility','',0,0),
(7,7,'product_visibility','',0,0),
(8,8,'product_visibility','',0,0),
(9,9,'product_visibility','',0,0),
(10,10,'product_visibility','',0,0),
(11,11,'product_visibility','',0,0),
(12,12,'product_visibility','',0,0),
(13,13,'product_visibility','',0,3),
(14,14,'product_visibility','',0,5),
(15,15,'product_cat','',0,0),
(20,20,'product_cat','',0,8),
(21,21,'nav_menu','',0,3),
(22,22,'nav_menu','',0,3),
(23,23,'nav_menu','',0,4),
(24,24,'category','',0,2),
(25,25,'category','',0,1),
(26,26,'category','',0,2),
(27,27,'category','',0,1);
/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_termmeta`
--

LOCK TABLES `wp_termmeta` WRITE;
/*!40000 ALTER TABLE `wp_termmeta` DISABLE KEYS */;
INSERT INTO `wp_termmeta` VALUES
(9,20,'order','0'),
(10,20,'order','0'),
(11,20,'product_count_product_cat','8'),
(12,20,'_athemes_sites_imported_term','1'),
(13,21,'_athemes_sites_imported_term','1'),
(14,22,'_athemes_sites_imported_term','1'),
(15,23,'_athemes_sites_imported_term','1');
/*!40000 ALTER TABLE `wp_termmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_terms`
--

LOCK TABLES `wp_terms` WRITE;
/*!40000 ALTER TABLE `wp_terms` DISABLE KEYS */;
INSERT INTO `wp_terms` VALUES
(1,'Uncategorized','uncategorized',0),
(2,'simple','simple',0),
(3,'grouped','grouped',0),
(4,'variable','variable',0),
(5,'external','external',0),
(6,'exclude-from-search','exclude-from-search',0),
(7,'exclude-from-catalog','exclude-from-catalog',0),
(8,'featured','featured',0),
(9,'outofstock','outofstock',0),
(10,'rated-1','rated-1',0),
(11,'rated-2','rated-2',0),
(12,'rated-3','rated-3',0),
(13,'rated-4','rated-4',0),
(14,'rated-5','rated-5',0),
(15,'Allgemein','uncategorized',0),
(20,'Kosmetik','cosmetics',0),
(21,'Footer','footer',0),
(22,'Footer 2','footer-2',0),
(23,'Main','main',0),
(24,'Inhaltsstoffe','inhaltsstoffe',0),
(25,'Anwendung','anwendung',0),
(26,'Alltag &amp; Tipps','alltag-tipps',0),
(27,'Gesundheit','gesundheit',0);
/*!40000 ALTER TABLE `wp_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_usermeta`
--

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;
INSERT INTO `wp_usermeta` VALUES
(1,1,'nickname','admin'),
(2,1,'first_name',''),
(3,1,'last_name',''),
(4,1,'description',''),
(5,1,'rich_editing','true'),
(6,1,'syntax_highlighting','true'),
(7,1,'comment_shortcuts','false'),
(8,1,'admin_color','fresh'),
(9,1,'use_ssl','0'),
(10,1,'show_admin_bar_front','true'),
(11,1,'locale',''),
(12,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}'),
(13,1,'wp_user_level','10'),
(14,1,'dismissed_wp_pointers',''),
(15,1,'show_welcome_panel','1'),
(17,1,'wc_last_active','1780272000'),
(19,1,'_woocommerce_tracks_anon_id','woo:TayF0DzzHfsL1oMRaZlqd4k5'),
(20,1,'wp_dashboard_quick_press_last_post_id','33'),
(21,1,'_woocommerce_persistent_cart_1','a:1:{s:4:\"cart\";a:0:{}}'),
(22,1,'community-events-location','a:1:{s:2:\"ip\";s:13:\"172.217.208.0\";}'),
(23,1,'elementor_introduction','a:2:{s:27:\"e-editor-one-notice-pointer\";b:1;s:30:\"e-ai-product-image-unification\";b:1;}'),
(26,1,'last_update','1780395844');
/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_users`
--

LOCK TABLES `wp_users` WRITE;
/*!40000 ALTER TABLE `wp_users` DISABLE KEYS */;
INSERT INTO `wp_users` VALUES
(1,'admin','$P$BWx9sHqxJZ.vPx2UREqpeCe26U0II50','admin','admin@example.com','http://localhost:8090','2026-06-01 13:48:36','',0,'admin');
/*!40000 ALTER TABLE `wp_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_admin_note_actions`
--

DROP TABLE IF EXISTS `wp_wc_admin_note_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `query` longtext NOT NULL,
  `status` varchar(255) NOT NULL,
  `actioned_text` varchar(255) NOT NULL,
  `nonce_action` varchar(255) DEFAULT NULL,
  `nonce_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_admin_note_actions`
--

LOCK TABLES `wp_wc_admin_note_actions` WRITE;
/*!40000 ALTER TABLE `wp_wc_admin_note_actions` DISABLE KEYS */;
INSERT INTO `wp_wc_admin_note_actions` VALUES
(1,1,'notify-refund-returns-page','Edit page','http://localhost:8090/wp-admin/post.php?post=9&action=edit','actioned','',NULL,NULL);
/*!40000 ALTER TABLE `wp_wc_admin_note_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_admin_notes`
--

DROP TABLE IF EXISTS `wp_wc_admin_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_admin_notes` (
  `note_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `locale` varchar(20) NOT NULL,
  `title` longtext NOT NULL,
  `content` longtext NOT NULL,
  `content_data` longtext DEFAULT NULL,
  `status` varchar(200) NOT NULL,
  `source` varchar(200) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT 0,
  `layout` varchar(20) NOT NULL DEFAULT '',
  `image` varchar(200) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `icon` varchar(200) NOT NULL DEFAULT 'info',
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_admin_notes`
--

LOCK TABLES `wp_wc_admin_notes` WRITE;
/*!40000 ALTER TABLE `wp_wc_admin_notes` DISABLE KEYS */;
INSERT INTO `wp_wc_admin_notes` VALUES
(1,'wc-refund-returns-page','info','en_US','Setup a Refund and Returns Policy page to boost your store\'s credibility.','We have created a sample draft Refund and Returns Policy page for you. Please have a look and update it to fit your store.','{}','unactioned','woocommerce-core','2026-06-01 13:49:38',NULL,0,'plain','',0,0,'info');
/*!40000 ALTER TABLE `wp_wc_admin_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_category_lookup`
--

DROP TABLE IF EXISTS `wp_wc_category_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_category_lookup` (
  `category_tree_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`category_tree_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_category_lookup`
--

LOCK TABLES `wp_wc_category_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_category_lookup` DISABLE KEYS */;
INSERT INTO `wp_wc_category_lookup` VALUES
(16,16),
(17,17),
(18,18),
(19,19),
(20,20);
/*!40000 ALTER TABLE `wp_wc_category_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_customer_lookup`
--

DROP TABLE IF EXISTS `wp_wc_customer_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_customer_lookup` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(60) NOT NULL DEFAULT '',
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) NOT NULL DEFAULT '',
  `postcode` varchar(20) NOT NULL DEFAULT '',
  `city` varchar(100) NOT NULL DEFAULT '',
  `state` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_customer_lookup`
--

LOCK TABLES `wp_wc_customer_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_customer_lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_customer_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_download_log`
--

DROP TABLE IF EXISTS `wp_wc_download_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_download_log`
--

LOCK TABLES `wp_wc_download_log` WRITE;
/*!40000 ALTER TABLE `wp_wc_download_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_download_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_order_addresses`
--

DROP TABLE IF EXISTS `wp_wc_order_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_order_addresses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `address_type` varchar(20) DEFAULT NULL,
  `first_name` text DEFAULT NULL,
  `last_name` text DEFAULT NULL,
  `company` text DEFAULT NULL,
  `address_1` text DEFAULT NULL,
  `address_2` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `postcode` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  `email` varchar(320) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address_type_order_id` (`address_type`,`order_id`),
  KEY `order_id` (`order_id`),
  KEY `email` (`email`(191)),
  KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_order_addresses`
--

LOCK TABLES `wp_wc_order_addresses` WRITE;
/*!40000 ALTER TABLE `wp_wc_order_addresses` DISABLE KEYS */;
INSERT INTO `wp_wc_order_addresses` VALUES
(3,441,'billing','Luca','Honegger',NULL,'Bechherwerg','1','Zurich','ZH','8001','CH','tes@test.ch','012345789'),
(4,450,'billing','Martina','Mayer','sinnhaft','dfdfs','dfsf','Zürich','ZH','8001','CH','mm@sinnhaft.ch','879879879');
/*!40000 ALTER TABLE `wp_wc_order_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_order_coupon_lookup`
--

DROP TABLE IF EXISTS `wp_wc_order_coupon_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_order_coupon_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_id`,`coupon_id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_order_coupon_lookup`
--

LOCK TABLES `wp_wc_order_coupon_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_order_coupon_lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_order_coupon_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_order_operational_data`
--

DROP TABLE IF EXISTS `wp_wc_order_operational_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_order_operational_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `created_via` varchar(100) DEFAULT NULL,
  `woocommerce_version` varchar(20) DEFAULT NULL,
  `prices_include_tax` tinyint(1) DEFAULT NULL,
  `coupon_usages_are_counted` tinyint(1) DEFAULT NULL,
  `download_permission_granted` tinyint(1) DEFAULT NULL,
  `cart_hash` varchar(100) DEFAULT NULL,
  `new_order_email_sent` tinyint(1) DEFAULT NULL,
  `order_key` varchar(100) DEFAULT NULL,
  `order_stock_reduced` tinyint(1) DEFAULT NULL,
  `date_paid_gmt` datetime DEFAULT NULL,
  `date_completed_gmt` datetime DEFAULT NULL,
  `shipping_tax_amount` decimal(26,8) DEFAULT NULL,
  `shipping_total_amount` decimal(26,8) DEFAULT NULL,
  `discount_tax_amount` decimal(26,8) DEFAULT NULL,
  `discount_total_amount` decimal(26,8) DEFAULT NULL,
  `recorded_sales` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_id` (`order_id`),
  KEY `order_key` (`order_key`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_order_operational_data`
--

LOCK TABLES `wp_wc_order_operational_data` WRITE;
/*!40000 ALTER TABLE `wp_wc_order_operational_data` DISABLE KEYS */;
INSERT INTO `wp_wc_order_operational_data` VALUES
(18,441,'checkout','9.5.1',0,1,1,'ae83ff0abf9ba2956a31786aed529a2a',0,'wc_order_NLVt2fTROdRAf',1,'2026-06-02 06:04:14',NULL,0.00000000,0.00000000,0.00000000,0.00000000,1),
(24,450,'checkout','9.5.1',0,1,1,'ae83ff0abf9ba2956a31786aed529a2a',0,'wc_order_kdr51FcpuJlib',1,'2026-06-02 09:24:15',NULL,0.00000000,0.00000000,0.00000000,0.00000000,1);
/*!40000 ALTER TABLE `wp_wc_order_operational_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_order_product_lookup`
--

DROP TABLE IF EXISTS `wp_wc_order_product_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_order_product_lookup` (
  `order_item_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variation_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT 0,
  `product_gross_revenue` double NOT NULL DEFAULT 0,
  `coupon_amount` double NOT NULL DEFAULT 0,
  `tax_amount` double NOT NULL DEFAULT 0,
  `shipping_amount` double NOT NULL DEFAULT 0,
  `shipping_tax_amount` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_order_product_lookup`
--

LOCK TABLES `wp_wc_order_product_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_order_product_lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_order_product_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_order_stats`
--

DROP TABLE IF EXISTS `wp_wc_order_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_order_stats` (
  `order_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_paid` datetime DEFAULT '0000-00-00 00:00:00',
  `date_completed` datetime DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT 0,
  `total_sales` double NOT NULL DEFAULT 0,
  `tax_total` double NOT NULL DEFAULT 0,
  `shipping_total` double NOT NULL DEFAULT 0,
  `net_total` double NOT NULL DEFAULT 0,
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_order_stats`
--

LOCK TABLES `wp_wc_order_stats` WRITE;
/*!40000 ALTER TABLE `wp_wc_order_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_order_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_order_tax_lookup`
--

DROP TABLE IF EXISTS `wp_wc_order_tax_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_order_tax_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT 0,
  `order_tax` double NOT NULL DEFAULT 0,
  `total_tax` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_id`,`tax_rate_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_order_tax_lookup`
--

LOCK TABLES `wp_wc_order_tax_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_order_tax_lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_order_tax_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_orders`
--

DROP TABLE IF EXISTS `wp_wc_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_orders` (
  `id` bigint(20) unsigned NOT NULL,
  `status` varchar(20) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `tax_amount` decimal(26,8) DEFAULT NULL,
  `total_amount` decimal(26,8) DEFAULT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `billing_email` varchar(320) DEFAULT NULL,
  `date_created_gmt` datetime DEFAULT NULL,
  `date_updated_gmt` datetime DEFAULT NULL,
  `parent_order_id` bigint(20) unsigned DEFAULT NULL,
  `payment_method` varchar(100) DEFAULT NULL,
  `payment_method_title` text DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `ip_address` varchar(100) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `customer_note` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `date_created` (`date_created_gmt`),
  KEY `customer_id_billing_email` (`customer_id`,`billing_email`(171)),
  KEY `billing_email` (`billing_email`(191)),
  KEY `type_status_date` (`type`,`status`,`date_created_gmt`),
  KEY `parent_order_id` (`parent_order_id`),
  KEY `date_updated` (`date_updated_gmt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_orders`
--

LOCK TABLES `wp_wc_orders` WRITE;
/*!40000 ALTER TABLE `wp_wc_orders` DISABLE KEYS */;
INSERT INTO `wp_wc_orders` VALUES
(441,'wc-processing','CHF','shop_order',0.00000000,24.00000000,0,'tes@test.ch','2026-06-02 06:04:14','2026-06-02 06:04:15',0,'m392_twint','TWINT (Test)','','192.168.65.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36',''),
(450,'wc-processing','CHF','shop_order',0.00000000,24.00000000,0,'mm@sinnhaft.ch','2026-06-02 09:24:15','2026-06-02 09:24:15',0,'m392_twint','TWINT (Test)','','172.66.159.250','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','');
/*!40000 ALTER TABLE `wp_wc_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_orders_meta`
--

DROP TABLE IF EXISTS `wp_wc_orders_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_orders_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meta_key_value` (`meta_key`(100),`meta_value`(82)),
  KEY `order_id_meta_key_meta_value` (`order_id`,`meta_key`(100),`meta_value`(82))
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_orders_meta`
--

LOCK TABLES `wp_wc_orders_meta` WRITE;
/*!40000 ALTER TABLE `wp_wc_orders_meta` DISABLE KEYS */;
INSERT INTO `wp_wc_orders_meta` VALUES
(7,441,'is_vat_exempt','no'),
(8,441,'_billing_address_index','Luca Honegger  Bechherwerg 1 Zurich ZH 8001 CH tes@test.ch 012345789'),
(9,441,'_shipping_address_index','         '),
(10,441,'_wc_order_attribution_source_type','typein'),
(11,441,'_wc_order_attribution_utm_source','(direct)'),
(12,441,'_wc_order_attribution_session_entry','http://localhost:8090/'),
(13,441,'_wc_order_attribution_session_start_time','2026-06-01 13:13:13'),
(14,441,'_wc_order_attribution_session_pages','6'),
(15,441,'_wc_order_attribution_session_count','5'),
(16,441,'_wc_order_attribution_user_agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'),
(17,441,'_wc_order_attribution_device_type','Desktop'),
(18,450,'is_vat_exempt','no'),
(19,450,'_billing_address_index','Martina Mayer sinnhaft dfdfs dfsf Zürich ZH 8001 CH mm@sinnhaft.ch 879879879'),
(20,450,'_shipping_address_index','         '),
(21,450,'_wc_order_attribution_source_type','typein'),
(22,450,'_wc_order_attribution_utm_source','(direct)'),
(23,450,'_wc_order_attribution_session_entry','http://localhost:8090/'),
(24,450,'_wc_order_attribution_session_start_time','2026-06-01 13:13:13'),
(25,450,'_wc_order_attribution_session_pages','7'),
(26,450,'_wc_order_attribution_session_count','6'),
(27,450,'_wc_order_attribution_user_agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'),
(28,450,'_wc_order_attribution_device_type','Desktop');
/*!40000 ALTER TABLE `wp_wc_orders_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_product_attributes_lookup`
--

DROP TABLE IF EXISTS `wp_wc_product_attributes_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_product_attributes_lookup` (
  `product_id` bigint(20) NOT NULL,
  `product_or_parent_id` bigint(20) NOT NULL,
  `taxonomy` varchar(32) NOT NULL,
  `term_id` bigint(20) NOT NULL,
  `is_variation_attribute` tinyint(1) NOT NULL,
  `in_stock` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_or_parent_id`,`term_id`,`product_id`,`taxonomy`),
  KEY `is_variation_attribute_term_id` (`is_variation_attribute`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_product_attributes_lookup`
--

LOCK TABLES `wp_wc_product_attributes_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_product_attributes_lookup` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_product_attributes_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_product_download_directories`
--

DROP TABLE IF EXISTS `wp_wc_product_download_directories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_product_download_directories` (
  `url_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(256) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`url_id`),
  KEY `url` (`url`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_product_download_directories`
--

LOCK TABLES `wp_wc_product_download_directories` WRITE;
/*!40000 ALTER TABLE `wp_wc_product_download_directories` DISABLE KEYS */;
INSERT INTO `wp_wc_product_download_directories` VALUES
(1,'file:///var/www/html/wp-content/uploads/woocommerce_uploads/',1),
(2,'http://localhost:8090/wp-content/uploads/woocommerce_uploads/',1);
/*!40000 ALTER TABLE `wp_wc_product_download_directories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_product_meta_lookup`
--

DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) DEFAULT '',
  `global_unique_id` varchar(100) DEFAULT '',
  `virtual` tinyint(1) DEFAULT 0,
  `downloadable` tinyint(1) DEFAULT 0,
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT 0,
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `total_sales` bigint(20) DEFAULT 0,
  `tax_status` varchar(100) DEFAULT 'taxable',
  `tax_class` varchar(100) DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`),
  KEY `sku` (`sku`(50))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_product_meta_lookup`
--

LOCK TABLES `wp_wc_product_meta_lookup` WRITE;
/*!40000 ALTER TABLE `wp_wc_product_meta_lookup` DISABLE KEYS */;
INSERT INTO `wp_wc_product_meta_lookup` VALUES
(10,'TS-001','',0,0,29.9000,29.9000,0,NULL,'instock',0,0.00,0,'taxable',''),
(11,'HD-002','',0,0,69.0000,69.0000,0,NULL,'instock',0,0.00,0,'taxable',''),
(12,'CAP-003','',0,0,24.5000,24.5000,0,NULL,'instock',0,0.00,0,'taxable',''),
(13,'BAG-004','',0,0,49.9000,49.9000,0,NULL,'instock',0,0.00,0,'taxable',''),
(14,'MUG-005','',0,0,14.5000,14.5000,0,NULL,'instock',0,0.00,0,'taxable',''),
(15,'BTL-006','',0,0,27.9000,27.9000,0,NULL,'instock',0,0.00,0,'taxable',''),
(16,'CDL-007','',0,0,18.0000,18.0000,0,NULL,'instock',0,0.00,0,'taxable',''),
(17,'EAR-008','',0,0,89.0000,89.0000,0,NULL,'instock',0,0.00,0,'taxable',''),
(18,'CHG-009','',0,0,34.9000,34.9000,0,NULL,'instock',0,0.00,0,'taxable',''),
(19,'PWR-010','',0,0,39.9000,39.9000,0,NULL,'instock',0,0.00,0,'taxable',''),
(31,'','',0,0,14.0000,14.0000,0,NULL,'instock',35,4.46,142,'taxable',''),
(40,'','',0,0,18.0000,18.0000,1,NULL,'instock',34,4.71,168,'taxable',''),
(42,'','',0,0,14.0000,14.0000,0,NULL,'instock',31,4.68,121,'taxable',''),
(93,'','',0,0,14.0000,14.0000,0,NULL,'instock',15,4.47,53,'taxable',''),
(94,'','',0,0,14.0000,14.0000,0,NULL,'instock',32,4.63,130,'taxable',''),
(95,'','',0,0,21.0000,21.0000,0,NULL,'instock',20,4.80,64,'taxable',''),
(96,'','',0,0,14.0000,14.0000,0,NULL,'instock',19,4.68,98,'taxable',''),
(97,'','',0,0,12.0000,12.0000,1,NULL,'instock',15,4.27,110,'taxable','');
/*!40000 ALTER TABLE `wp_wc_product_meta_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_rate_limits`
--

DROP TABLE IF EXISTS `wp_wc_rate_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_rate_limits` (
  `rate_limit_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rate_limit_key` varchar(200) NOT NULL,
  `rate_limit_expiry` bigint(20) unsigned NOT NULL,
  `rate_limit_remaining` smallint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`rate_limit_id`),
  UNIQUE KEY `rate_limit_key` (`rate_limit_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_rate_limits`
--

LOCK TABLES `wp_wc_rate_limits` WRITE;
/*!40000 ALTER TABLE `wp_wc_rate_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_rate_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_reserved_stock`
--

DROP TABLE IF EXISTS `wp_wc_reserved_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_reserved_stock` (
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT 0,
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_reserved_stock`
--

LOCK TABLES `wp_wc_reserved_stock` WRITE;
/*!40000 ALTER TABLE `wp_wc_reserved_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_reserved_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_tax_rate_classes`
--

DROP TABLE IF EXISTS `wp_wc_tax_rate_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_tax_rate_classes`
--

LOCK TABLES `wp_wc_tax_rate_classes` WRITE;
/*!40000 ALTER TABLE `wp_wc_tax_rate_classes` DISABLE KEYS */;
INSERT INTO `wp_wc_tax_rate_classes` VALUES
(1,'Reduced rate','reduced-rate'),
(2,'Zero rate','zero-rate');
/*!40000 ALTER TABLE `wp_wc_tax_rate_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wc_webhooks`
--

DROP TABLE IF EXISTS `wp_wc_webhooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) NOT NULL,
  `name` text NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text NOT NULL,
  `secret` text NOT NULL,
  `topic` varchar(200) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT 0,
  `pending_delivery` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wc_webhooks`
--

LOCK TABLES `wp_wc_webhooks` WRITE;
/*!40000 ALTER TABLE `wp_wc_webhooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wc_webhooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_api_keys`
--

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `permissions` varchar(10) NOT NULL,
  `consumer_key` char(64) NOT NULL,
  `consumer_secret` char(43) NOT NULL,
  `nonces` longtext DEFAULT NULL,
  `truncated_key` char(7) NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_api_keys`
--

LOCK TABLES `wp_woocommerce_api_keys` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_api_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_attribute_taxonomies`
--

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) NOT NULL,
  `attribute_label` varchar(200) DEFAULT NULL,
  `attribute_type` varchar(20) NOT NULL,
  `attribute_orderby` varchar(20) NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_attribute_taxonomies`
--

LOCK TABLES `wp_woocommerce_attribute_taxonomies` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_attribute_taxonomies` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_attribute_taxonomies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_downloadable_product_permissions`
--

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `order_key` varchar(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`),
  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_downloadable_product_permissions`
--

LOCK TABLES `wp_woocommerce_downloadable_product_permissions` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_downloadable_product_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_downloadable_product_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_log`
--

DROP TABLE IF EXISTS `wp_woocommerce_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) NOT NULL,
  `message` longtext NOT NULL,
  `context` longtext DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_log`
--

LOCK TABLES `wp_woocommerce_log` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_order_itemmeta`
--

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_order_itemmeta`
--

LOCK TABLES `wp_woocommerce_order_itemmeta` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_order_itemmeta` DISABLE KEYS */;
INSERT INTO `wp_woocommerce_order_itemmeta` VALUES
(10,2,'_product_id','97'),
(11,2,'_variation_id','0'),
(12,2,'_qty','2'),
(13,2,'_tax_class',''),
(14,2,'_line_subtotal','24'),
(15,2,'_line_subtotal_tax','0'),
(16,2,'_line_total','24'),
(17,2,'_line_tax','0'),
(18,2,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(19,3,'_product_id','97'),
(20,3,'_variation_id','0'),
(21,3,'_qty','2'),
(22,3,'_tax_class',''),
(23,3,'_line_subtotal','24'),
(24,3,'_line_subtotal_tax','0'),
(25,3,'_line_total','24'),
(26,3,'_line_tax','0'),
(27,3,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}');
/*!40000 ALTER TABLE `wp_woocommerce_order_itemmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_order_items`
--

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text NOT NULL,
  `order_item_type` varchar(200) NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_order_items`
--

LOCK TABLES `wp_woocommerce_order_items` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_order_items` DISABLE KEYS */;
INSERT INTO `wp_woocommerce_order_items` VALUES
(2,'Eternal Sunset Collection Lip and Cheek','line_item',441),
(3,'Eternal Sunset Collection Lip and Cheek','line_item',450);
/*!40000 ALTER TABLE `wp_woocommerce_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_payment_tokenmeta`
--

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_payment_tokenmeta`
--

LOCK TABLES `wp_woocommerce_payment_tokenmeta` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_payment_tokenmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_payment_tokenmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_payment_tokens`
--

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) NOT NULL,
  `token` text NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `type` varchar(200) NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_payment_tokens`
--

LOCK TABLES `wp_woocommerce_payment_tokens` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_payment_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_payment_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_sessions`
--

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) NOT NULL,
  `session_value` longtext NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_sessions`
--

LOCK TABLES `wp_woocommerce_sessions` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_sessions` DISABLE KEYS */;
INSERT INTO `wp_woocommerce_sessions` VALUES
(3,'t_0d5fd694e0527c887e23855da8ad6f','a:10:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:867:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:4:\"Luca\";s:9:\"last_name\";s:8:\"Honegger\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:9:\"012345789\";s:5:\"email\";s:11:\"tes@test.ch\";s:7:\"address\";s:11:\"Bechherwerg\";s:9:\"address_1\";s:11:\"Bechherwerg\";s:9:\"address_2\";s:1:\"1\";s:4:\"city\";s:6:\"Zurich\";s:5:\"state\";s:2:\"ZH\";s:8:\"postcode\";s:4:\"8001\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:4:\"Luca\";s:18:\"shipping_last_name\";s:8:\"Honegger\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:9:\"012345789\";s:16:\"shipping_address\";s:11:\"Bechherwerg\";s:18:\"shipping_address_1\";s:11:\"Bechherwerg\";s:18:\"shipping_address_2\";s:1:\"1\";s:13:\"shipping_city\";s:6:\"Zurich\";s:14:\"shipping_state\";s:2:\"ZH\";s:17:\"shipping_postcode\";s:4:\"8001\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:1:\"1\";s:9:\"meta_data\";a:0:{}}\";s:21:\"chosen_payment_method\";s:10:\"m392_twint\";s:22:\"order_awaiting_payment\";N;}',1780501431),
(17,'t_9fedbe328e00d26a5988229965afa6','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555105),
(18,'t_827ca7fd5fb96e0f3f6e872ba392d1','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555550),
(19,'t_915d3ded64e24882a372912540962b','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555551),
(20,'t_1612a70cd999dc74be436b5a7d84e0','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555612),
(21,'t_da129b5ec785ef9de7f0398a64e25c','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555616),
(22,'t_4c28afc4408d84ad1245a08cc8834d','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555620),
(23,'t_402dcab1b7bd60fb4ce4f0843aa6e4','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555623),
(24,'t_41d0e1f91291fc680e4b720b527710','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555628),
(25,'t_ad9589b70bd4f08a97896b7e4a6fc1','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555628),
(26,'t_12088f2de8059fe1037bbbc56afd54','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555660),
(27,'t_ab3b2817ae46fd5ad47bc56090f5f1','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555666),
(28,'t_de845f76e039dda83f38fcc3cf20ec','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555679),
(29,'t_9de4ffd10787ce5e45ef0a627e2f82','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555706),
(30,'t_2a9b027920988eeb17a825d397dab5','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555720),
(31,'t_88c51827127d41253b35aa16fb155e','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555746),
(32,'t_66ea78d44e2a95c83e17984eaebece','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555753),
(33,'t_1a3f1a58d78ca8f42fabcb2334b7e3','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555758),
(34,'t_52e8a1e735ecc701b10fcbd39e066f','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555763),
(35,'t_b0fe7cba5ef7160d1a0f73fda40351','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555766),
(36,'1','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:784:\"a:28:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2026-06-02T06:35:45+00:00\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:17:\"admin@example.com\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780555907),
(37,'t_3643827eb663a74cf500fbd6e1e484','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556563),
(38,'t_8e4275e73f803cbed68fed280d9d1e','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556572),
(39,'t_c7a98c676349ee71bb3162f5ee10cc','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556575),
(40,'t_e51874f0eff1a0c922fd8e97500396','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556581),
(41,'t_7044a3f0d08de178e201abbca60388','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556590),
(42,'t_21788486a7d5d6fa437a728d882d84','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556714),
(43,'t_aae232b1cf2fde4f144b9acabfb0fc','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556826),
(44,'t_3e9c38473b2613bbf35ed82dec215a','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556859),
(45,'t_cb6e903cb0fd677f0c48cdbb847877','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556859),
(46,'t_80067a7d11460e75227b945c32aaf8','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556863),
(47,'t_8b690eab285823f8826e4bab13888f','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556865),
(48,'t_72260f07b2f3eeeb79768828fef752','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556872),
(49,'t_ead0c86ff50eeaee4f786c8de70997','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556873),
(50,'t_dbe4a371a8c1ac22ef0856b35c7730','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556874),
(51,'t_31023b8554dd42760e44161514d910','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556922),
(52,'t_359a2a7f59ed93c296398a0381d7af','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556927),
(53,'t_7f4c9fbdff9cfb13167f3c3ef5f0c2','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556935),
(54,'t_f93ccb6933dac0d61700bbbf3f6d8b','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556936),
(55,'t_dd11e65e040b3fe141042a014f55a3','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556983),
(56,'t_238ae245757e99c5392cb3bce0bc7b','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780556984),
(57,'t_20e3414de9a9ba4ad153845ec438e6','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557030),
(58,'t_91c76036bc1ca1bdf6a6a189d9075a','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557030),
(59,'t_1d2158d018c7bddb770594d80f7338','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557031),
(60,'t_976b79eb0183b90830132fe256c6cb','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557034),
(61,'t_bef379ca660c7d60a66942d56864e4','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557061),
(62,'t_3da7c63e9a5670a87da0cabfd3e02d','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557318),
(63,'t_6d9d1f238c2c66ccc31a8c1487a3e0','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557320),
(64,'t_3502e2e451218aceae2cc08aa7dceb','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557341),
(65,'t_4c7c09eabcdf612b20d9541951401e','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557345),
(66,'t_db0e9e68eae0fde3f9a1eb5608470e','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557346),
(67,'t_76d3757e067b70993180b95c53237b','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557418),
(68,'t_8829461177feb1a03b57ce350f59d2','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557420),
(69,'t_dd47502a996324c3dcbdc6cf1ce793','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557428),
(70,'t_793e33076fb077d94130f18c88cb58','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557429),
(71,'t_badcc99a0cd15525c4c042e9868b15','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557448),
(72,'t_79df0bc31dae0f1b9e1537f996ec0b','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557457),
(73,'t_7e37d06329226b289ee74928a4e0a0','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:1:\"*\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:1:\"*\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557461),
(74,'t_207e3535b5ddf89353e2a96d6296a9','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"ZH\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"ZH\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780557871),
(75,'t_10d6cb12dccf00c261b54c236af45a','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"ZH\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"ZH\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780565008),
(76,'t_6116c32708dbe7c58fb69bc4238509','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"ZH\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"ZH\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780565008),
(77,'t_5c1c4e382515e4a9f15237c28c8a65','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"ZH\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"ZH\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780565019),
(78,'t_4317053aa791e81e38f22627c713c6','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"ZH\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"ZH\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780565019),
(79,'t_6a46d4e6bbac64a71299c6951294f0','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"ZH\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"ZH\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780565020),
(80,'t_0131000f17f4336d80cb43cea7f58d','a:10:{s:4:\"cart\";s:410:\"a:1:{s:32:\"e2ef524fbf3d9fe611d5a8e90fefdc9c\";a:11:{s:3:\"key\";s:32:\"e2ef524fbf3d9fe611d5a8e90fefdc9c\";s:10:\"product_id\";i:97;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:12;s:17:\"line_subtotal_tax\";d:0;s:10:\"line_total\";d:12;s:8:\"line_tax\";d:0;}}\";s:11:\"cart_totals\";s:393:\"a:15:{s:8:\"subtotal\";s:2:\"12\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";d:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";d:0;s:12:\"discount_tax\";d:0;s:19:\"cart_contents_total\";s:2:\"12\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";d:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:5:\"12.00\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:10:\"wc_notices\";N;s:8:\"customer\";s:866:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:7:\"Martina\";s:9:\"last_name\";s:5:\"Mayer\";s:7:\"company\";s:8:\"sinnhaft\";s:5:\"phone\";s:9:\"879879879\";s:5:\"email\";s:14:\"mm@sinnhaft.ch\";s:7:\"address\";s:5:\"dfdfs\";s:9:\"address_1\";s:5:\"dfdfs\";s:9:\"address_2\";s:4:\"dfsf\";s:4:\"city\";s:7:\"Zürich\";s:5:\"state\";s:2:\"ZH\";s:8:\"postcode\";s:4:\"8001\";s:7:\"country\";s:2:\"CH\";s:19:\"shipping_first_name\";s:7:\"Martina\";s:18:\"shipping_last_name\";s:5:\"Mayer\";s:16:\"shipping_company\";s:8:\"sinnhaft\";s:14:\"shipping_phone\";s:9:\"879879879\";s:16:\"shipping_address\";s:5:\"dfdfs\";s:18:\"shipping_address_1\";s:5:\"dfdfs\";s:18:\"shipping_address_2\";s:4:\"dfsf\";s:13:\"shipping_city\";s:7:\"Zürich\";s:14:\"shipping_state\";s:2:\"ZH\";s:17:\"shipping_postcode\";s:4:\"8001\";s:16:\"shipping_country\";s:2:\"CH\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:1:\"1\";s:9:\"meta_data\";a:0:{}}\";s:21:\"chosen_payment_method\";s:10:\"m392_twint\";s:22:\"order_awaiting_payment\";N;}',1780565024),
(89,'t_cc9ccf7456229f3cb8b004d3811f3c','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780565804),
(90,'t_ee712f836028c55e076cff7ea83477','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780565804),
(91,'t_e88380fbea9ce63c7eb4f12e3e7fb5','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780565804),
(92,'t_93f7b4ee439421d1fae7d28d341215','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780565804),
(93,'t_3b2cb475bd99909f8bc2b7cbe1911c','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780565804),
(94,'t_52bcdeb877f0b99bc2f248d3c03d17','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780565804),
(95,'t_32c5d959f2c1d11e4cc9d615076411','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780566163),
(96,'t_15b14768ad37d3d1619bc0aaf3dc05','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780566163),
(97,'t_dd59c1d76e0d9a9b0791b65ac0a08e','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780566163),
(98,'t_36573af0901561576aacfeb537e4ab','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780566169),
(99,'t_1366785dc687c0061e29d6bef86496','a:8:{s:4:\"cart\";s:410:\"a:1:{s:32:\"98dce83da57b0395e163467c9dae521b\";a:11:{s:3:\"key\";s:32:\"98dce83da57b0395e163467c9dae521b\";s:10:\"product_id\";i:93;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:14;s:17:\"line_subtotal_tax\";d:0;s:10:\"line_total\";d:14;s:8:\"line_tax\";d:0;}}\";s:11:\"cart_totals\";s:393:\"a:15:{s:8:\"subtotal\";s:2:\"14\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";d:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";d:0;s:12:\"discount_tax\";d:0;s:19:\"cart_contents_total\";s:2:\"14\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";d:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:5:\"14.00\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:740:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";s:21:\"chosen_payment_method\";s:12:\"m392_invoice\";}',1780566173),
(102,'t_33070579db23bf2981a1a8b2ba086c','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780568768),
(103,'t_21e471cf769b14e9738142c0e65d11','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780568768),
(104,'t_42c89ed62fe0e37546433280dea93a','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780568769),
(105,'t_85ce5b16dca46c290f394551ed8631','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780568769),
(106,'t_30ca5b897bf001c576b1e2e8c93d81','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780568769),
(107,'t_f53641c182be10c0b08cc8786de7e3','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780568769),
(108,'t_49698279a84f12787139b6feef9c15','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780568769),
(109,'t_6fbe55e8ba89d5e33bc3e2dbd8ce18','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780568769),
(110,'t_e7f3bd6f9ef97a4a2f055215f20131','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780568789),
(111,'t_60e06a02f127e6a252e19150214ce1','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780568789),
(112,'t_6a83e7c69fe47f4b7d2147a041fefd','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780568797),
(113,'t_1fd4e2cca9328109f44a3f8cf75351','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780568797),
(114,'t_af9c2cc03182595bed47ec2473e7c8','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780568805),
(115,'t_770aad4659086ae15e6f2efaf16c34','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570005),
(116,'t_3191e9ead4122674e0f14538fc333f','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570005),
(117,'t_13b3272674de7304fef504049c663e','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570007),
(118,'t_237071895ae9ea4d21d8197ae28809','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570007),
(119,'t_031edc3b3a5d054a14ffa7928320dd','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570007),
(120,'t_43a8c6bd84ab55d46e7726370cf156','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570010),
(121,'t_feb86b3cf10d607255ebc0f70c5ac7','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570155),
(122,'t_0d3cdc70f50c65c3ee1f7fb19125b1','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570182),
(123,'t_f7d064af4988c3192c75182856f813','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570185),
(124,'t_d9f8cf0fc9ac012fc547fe8f458411','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570205),
(125,'t_849fa0c85ee62e999a3d5216b1dd34','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570208),
(126,'t_759a9061afdf04c64ad7fd1f3c50a2','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570209),
(127,'t_f23f8e301fb47087d892662ca0b5f7','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570210),
(128,'t_82484aeaf3232260672a029467ce01','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570231),
(129,'t_e4108b6835672dd5f86a074970b9a3','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570235),
(130,'t_29e881c6b7c92ccec2cb0f2a7f3edb','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570239),
(131,'t_c55267901b45b87d89d3e951e0b6e9','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570240),
(132,'t_6aa23b2b528dfbc198a232b449c53a','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570287),
(133,'t_3a683fa75523aa1f70ba1e7115c551','a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:742:\"a:28:{s:2:\"id\";s:1:\"0\";s:13:\"date_modified\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:5:\"state\";s:2:\"BE\";s:8:\"postcode\";s:0:\"\";s:7:\"country\";s:2:\"DE\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";s:14:\"shipping_phone\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:14:\"shipping_state\";s:2:\"BE\";s:17:\"shipping_postcode\";s:0:\"\";s:16:\"shipping_country\";s:2:\"DE\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:9:\"meta_data\";a:0:{}}\";}',1780570466);
/*!40000 ALTER TABLE `wp_woocommerce_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_shipping_zone_locations`
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) NOT NULL,
  `location_type` varchar(40) NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `zone_id` (`zone_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_shipping_zone_locations`
--

LOCK TABLES `wp_woocommerce_shipping_zone_locations` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_shipping_zone_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_shipping_zone_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_shipping_zone_methods`
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_shipping_zone_methods`
--

LOCK TABLES `wp_woocommerce_shipping_zone_methods` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_shipping_zone_methods` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_shipping_zone_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_shipping_zones`
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_shipping_zones`
--

LOCK TABLES `wp_woocommerce_shipping_zones` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_shipping_zones` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_shipping_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_tax_rate_locations`
--

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_tax_rate_locations`
--

LOCK TABLES `wp_woocommerce_tax_rate_locations` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_tax_rate_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_tax_rate_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_woocommerce_tax_rates`
--

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) NOT NULL DEFAULT '',
  `tax_rate` varchar(8) NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT 0,
  `tax_rate_shipping` int(1) NOT NULL DEFAULT 1,
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_woocommerce_tax_rates`
--

LOCK TABLES `wp_woocommerce_tax_rates` WRITE;
/*!40000 ALTER TABLE `wp_woocommerce_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_woocommerce_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wpforms_logs`
--

DROP TABLE IF EXISTS `wp_wpforms_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wpforms_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `message` longtext NOT NULL,
  `types` varchar(255) NOT NULL,
  `create_at` datetime NOT NULL,
  `form_id` bigint(20) DEFAULT NULL,
  `entry_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wpforms_logs`
--

LOCK TABLES `wp_wpforms_logs` WRITE;
/*!40000 ALTER TABLE `wp_wpforms_logs` DISABLE KEYS */;
INSERT INTO `wp_wpforms_logs` VALUES
(1,'Migration','Migration of WPForms to 1.5.9 started.','log','2026-06-01 14:05:29',0,0,1),
(2,'Migration','Migration of WPForms to 1.5.9 completed.','log','2026-06-01 14:05:29',0,0,1),
(3,'Migration','Migration of WPForms to 1.6.7.2 started.','log','2026-06-01 14:05:29',0,0,1),
(4,'Migration','Migration of WPForms to 1.6.7.2 completed.','log','2026-06-01 14:05:29',0,0,1),
(5,'Migration','Migration of WPForms to 1.6.8 started.','log','2026-06-01 14:05:29',0,0,1),
(6,'Migration','Migration of WPForms to 1.6.8 completed.','log','2026-06-01 14:05:29',0,0,1),
(7,'Migration','Migration of WPForms to 1.7.5 started.','log','2026-06-01 14:05:29',0,0,1),
(8,'Migration','Migration of WPForms to 1.7.5 completed.','log','2026-06-01 14:05:29',0,0,1),
(9,'Migration','Migration of WPForms to 1.7.5.1 started.','log','2026-06-01 14:05:29',0,0,1),
(10,'Migration','Migration of WPForms to 1.7.5.1 completed.','log','2026-06-01 14:05:29',0,0,1),
(11,'Migration','Migration of WPForms to 1.7.7 started.','log','2026-06-01 14:05:29',0,0,1),
(12,'Migration','Migration of WPForms to 1.7.7 completed.','log','2026-06-01 14:05:29',0,0,1),
(13,'Migration','Migration of WPForms to 1.8.2 started.','log','2026-06-01 14:05:29',0,0,1),
(14,'Migration','Migration of WPForms to 1.8.2 completed.','log','2026-06-01 14:05:29',0,0,1),
(15,'Migration','Migration of WPForms to 1.8.3 started.','log','2026-06-01 14:05:29',0,0,1),
(16,'Migration','Migration of WPForms to 1.8.4 started.','log','2026-06-01 14:05:29',0,0,1),
(17,'Migration','Migration of WPForms to 1.8.6 started.','log','2026-06-01 14:05:29',0,0,1),
(18,'Migration','Migration of WPForms to 1.8.7 started.','log','2026-06-01 14:05:29',0,0,1),
(19,'Migration','Migration of WPForms to 1.9.1 started.','log','2026-06-01 14:05:29',0,0,1),
(20,'Migration','Migration of WPForms to 1.9.1 completed.','log','2026-06-01 14:05:29',0,0,1),
(21,'Migration','Migration of WPForms to 1.9.2 started.','log','2026-06-01 14:05:29',0,0,1),
(22,'Migration','Migration of WPForms to 1.9.7 started.','log','2026-06-01 14:05:29',0,0,1),
(23,'Migration','Migration of WPForms to 1.9.7 completed.','log','2026-06-01 14:05:29',0,0,1),
(24,'Migration','Migration of WPForms to 1.9.8.6 started.','log','2026-06-01 14:05:29',0,0,1),
(25,'Migration','Migration of WPForms to 1.9.8.6 completed.','log','2026-06-01 14:05:29',0,0,1);
/*!40000 ALTER TABLE `wp_wpforms_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wpforms_payment_meta`
--

DROP TABLE IF EXISTS `wp_wpforms_payment_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wpforms_payment_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payment_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_id` (`payment_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `meta_value` (`meta_value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wpforms_payment_meta`
--

LOCK TABLES `wp_wpforms_payment_meta` WRITE;
/*!40000 ALTER TABLE `wp_wpforms_payment_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wpforms_payment_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wpforms_payments`
--

DROP TABLE IF EXISTS `wp_wpforms_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wpforms_payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT '',
  `subtotal_amount` decimal(26,8) NOT NULL DEFAULT 0.00000000,
  `discount_amount` decimal(26,8) NOT NULL DEFAULT 0.00000000,
  `total_amount` decimal(26,8) NOT NULL DEFAULT 0.00000000,
  `currency` varchar(3) NOT NULL DEFAULT '',
  `entry_id` bigint(20) NOT NULL DEFAULT 0,
  `gateway` varchar(20) NOT NULL DEFAULT '',
  `type` varchar(12) NOT NULL DEFAULT '',
  `mode` varchar(4) NOT NULL DEFAULT '',
  `transaction_id` varchar(40) NOT NULL DEFAULT '',
  `customer_id` varchar(40) NOT NULL DEFAULT '',
  `subscription_id` varchar(40) NOT NULL DEFAULT '',
  `subscription_status` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `date_created_gmt` datetime NOT NULL,
  `date_updated_gmt` datetime NOT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`(8)),
  KEY `total_amount` (`total_amount`),
  KEY `type` (`type`(8)),
  KEY `transaction_id` (`transaction_id`(32)),
  KEY `customer_id` (`customer_id`(32)),
  KEY `subscription_id` (`subscription_id`(32)),
  KEY `subscription_status` (`subscription_status`(8)),
  KEY `title` (`title`(64))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wpforms_payments`
--

LOCK TABLES `wp_wpforms_payments` WRITE;
/*!40000 ALTER TABLE `wp_wpforms_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wpforms_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wpforms_tasks_meta`
--

DROP TABLE IF EXISTS `wp_wpforms_tasks_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_wpforms_tasks_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `data` longtext NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wpforms_tasks_meta`
--

LOCK TABLES `wp_wpforms_tasks_meta` WRITE;
/*!40000 ALTER TABLE `wp_wpforms_tasks_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wpforms_tasks_meta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-06-02 10:56:48
